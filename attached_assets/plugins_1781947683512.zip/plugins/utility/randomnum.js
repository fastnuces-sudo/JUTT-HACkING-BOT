// ============================================
// AA MD Bot - Random Number Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["random", "rng", "rand"],
  description: "Generate a random number",
  category: "Utility",
  usage: ".random <min> <max>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    const min = parseInt(args[0]) || 1;
    const max = parseInt(args[1]) || 100;

    if (min >= max) {
      return sock.sendMessage(from, { text: "⚠️ Min must be less than max." });
    }

    const result = Math.floor(Math.random() * (max - min + 1)) + min;
    await sock.sendMessage(from, {
      text: `🎲 *Random Number*\n\n📊 Range: ${min} - ${max}\n✅ Result: *${result}*`,
    });
  },
};
