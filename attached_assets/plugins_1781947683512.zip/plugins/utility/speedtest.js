// ============================================
// AA MD Bot - Speed Test Plugin
// Developer: Ahsan Ali | AA Mods
// Tests download speed by timing a download
// ============================================

const axios = require("axios");

module.exports = {
  command: ["speedtest", "speed2", "netspeed"],
  description: "Test bot internet speed",
  category: "Utility",
  usage: ".speedtest",
  cooldown: 30000,
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;
    await sock.sendMessage(from, { text: "🌐 Running speed test, please wait..." });

    try {
      const testUrl = "https://speed.cloudflare.com/__down?bytes=10000000"; // 10MB
      const start = Date.now();
      const res = await axios.get(testUrl, {
        responseType: "arraybuffer",
        timeout: 30000,
      });
      const elapsed = (Date.now() - start) / 1000;
      const bytes = res.data.byteLength;
      const mbps = ((bytes * 8) / elapsed / 1000000).toFixed(2);
      const mbytes = (bytes / 1024 / 1024).toFixed(2);

      await sock.sendMessage(from, {
        text: `⚡ *Speed Test Results*\n\n` +
          `📥 *Download Speed:* ${mbps} Mbps\n` +
          `📦 *Data Downloaded:* ${mbytes} MB\n` +
          `⏱️ *Time:* ${elapsed.toFixed(2)}s\n\n` +
          `_Powered by Cloudflare | AA MD Bot_`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Speed test failed: ${err.message}` });
    }
  },
};
