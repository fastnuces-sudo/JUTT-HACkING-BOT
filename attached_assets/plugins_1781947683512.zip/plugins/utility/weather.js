// ============================================
// AA MD Bot - Weather Plugin
// Developer: Ahsan Ali | AA Mods
// Uses Open-Meteo (free, no key) + Nominatim geocoding
// Current weather + next 24-hour hourly forecast
// ============================================

const axios = require("axios");

const WMO_CODES = {
  0: "☀️ Clear Sky", 1: "🌤️ Mainly Clear", 2: "⛅ Partly Cloudy", 3: "☁️ Overcast",
  45: "🌫️ Foggy", 48: "🌫️ Icy Fog",
  51: "🌦️ Light Drizzle", 53: "🌦️ Moderate Drizzle", 55: "🌧️ Heavy Drizzle",
  61: "🌧️ Light Rain", 63: "🌧️ Moderate Rain", 65: "🌧️ Heavy Rain",
  71: "🌨️ Light Snow", 73: "🌨️ Moderate Snow", 75: "❄️ Heavy Snow",
  77: "🌨️ Snow Grains",
  80: "🌦️ Light Showers", 81: "🌧️ Moderate Showers", 82: "⛈️ Violent Showers",
  85: "🌨️ Light Snow Showers", 86: "❄️ Heavy Snow Showers",
  95: "⛈️ Thunderstorm", 96: "⛈️ Thunderstorm + Hail", 99: "⛈️ Heavy Thunderstorm + Hail",
};

const WMO_EMOJI = {
  0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️",
  45: "🌫️", 48: "🌫️",
  51: "🌦️", 53: "🌦️", 55: "🌧️",
  61: "🌧️", 63: "🌧️", 65: "🌧️",
  71: "🌨️", 73: "🌨️", 75: "❄️", 77: "🌨️",
  80: "🌦️", 81: "🌧️", 82: "⛈️",
  85: "🌨️", 86: "❄️",
  95: "⛈️", 96: "⛈️", 99: "⛈️",
};

function getWindDir(deg) {
  const dirs = ["N","NE","E","SE","S","SW","W","NW"];
  return dirs[Math.round(deg / 45) % 8];
}

function fmt12h(isoTime) {
  const d = new Date(isoTime);
  const h = d.getHours();
  const ampm = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;
  return `${h12}${ampm}`;
}

module.exports = {
  command: ["weather", "w"],
  description: "Get weather + next 24-hour forecast for any city",
  category: "Utility",
  usage: ".weather <city>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .weather <city>\nExample: .weather Dera Ghazi Khan",
      });
    }

    const city = args.join(" ");
    await sock.sendMessage(from, { text: `🌤️ Fetching weather for *${city}*...` });

    try {
      // Step 1: Geocode city using Nominatim (OSM)
      const geoRes = await axios.get(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)}&format=json&limit=1&addressdetails=1`,
        {
          timeout: 12000,
          headers: { "User-Agent": "AA-MD-Bot/1.0 (WhatsApp Bot)" },
        }
      );

      if (!geoRes.data || !geoRes.data.length) {
        return sock.sendMessage(from, {
          text: `❌ City not found: *${city}*\nPlease check the spelling and try again.`,
        });
      }

      const place = geoRes.data[0];
      const lat = parseFloat(place.lat);
      const lon = parseFloat(place.lon);
      const addr = place.address || {};
      const displayCity = addr.city || addr.town || addr.village || addr.county || place.display_name.split(",")[0];
      const country = addr.country || "";
      const state = addr.state || "";
      const locationStr = [displayCity, state, country].filter(Boolean).join(", ");

      // Step 2: Get current weather + 24h hourly from Open-Meteo
      const weatherRes = await axios.get(
        `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
        `&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,` +
        `wind_speed_10m,wind_direction_10m,surface_pressure,visibility,uv_index` +
        `&hourly=temperature_2m,precipitation_probability,weather_code,wind_speed_10m` +
        `&forecast_hours=24` +
        `&wind_speed_unit=kmh&temperature_unit=celsius&timezone=auto`,
        { timeout: 12000 }
      );

      const cur = weatherRes.data.current;
      const hrly = weatherRes.data.hourly;
      const condition = WMO_CODES[cur.weather_code] || "🌡️ Unknown";
      const tempC = Math.round(cur.temperature_2m);
      const tempF = Math.round(tempC * 9 / 5 + 32);
      const feelsC = Math.round(cur.apparent_temperature);
      const humidity = cur.relative_humidity_2m;
      const windKmph = Math.round(cur.wind_speed_10m);
      const windDir = getWindDir(cur.wind_direction_10m || 0);
      const visKm = cur.visibility ? (cur.visibility / 1000).toFixed(1) : "N/A";
      const uv = cur.uv_index ?? "N/A";

      // ── Build 24-hour hourly forecast (show every 3 hours) ────────
      let forecastLine = "";
      if (hrly && hrly.time && hrly.time.length >= 8) {
        const step = 3;
        const rows = [];
        for (let i = 0; i < Math.min(hrly.time.length, 24); i += step) {
          const timeLabel = fmt12h(hrly.time[i]);
          const t = Math.round(hrly.temperature_2m[i]);
          const pop = hrly.precipitation_probability[i] ?? 0;
          const emoji = WMO_EMOJI[hrly.weather_code[i]] || "🌡️";
          rows.push(`  ${timeLabel.padEnd(5)} ${emoji} ${String(t).padStart(2)}°C  💧${pop}%`);
        }
        forecastLine = `\n📊 *Next 24 Hours*\n${rows.join("\n")}\n`;
      }

      const text =
        `🌍 *Weather Report*\n📍 *${locationStr}*\n\n` +
        `${condition}\n` +
        `🌡️ *Temperature:* ${tempC}°C / ${tempF}°F\n` +
        `🤔 *Feels Like:* ${feelsC}°C\n` +
        `💧 *Humidity:* ${humidity}%\n` +
        `💨 *Wind:* ${windKmph} km/h ${windDir}\n` +
        `👁️ *Visibility:* ${visKm} km\n` +
        `☀️ *UV Index:* ${uv}\n` +
        forecastLine +
        `\n_Powered by Open-Meteo | AA MD Bot_`;

      await sock.sendMessage(from, { text });

    } catch (err) {
      await sock.sendMessage(from, {
        text: `❌ Couldn't get weather for *${city}*.\nPlease try again in a moment.\n_Error: ${err.message}_`,
      });
    }
  },
};
