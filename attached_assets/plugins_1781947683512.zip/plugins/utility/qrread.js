// ============================================
// AA MD Bot - QR Code Reader Plugin
// Developer: Ahsan Ali | AA Mods
// Uses api.qrserver.com (free, no key needed)
// ============================================

const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs-extra");
const { downloadMediaToFile } = require("../../lib/utils");

module.exports = {
  command: ["qrread", "readqr", "scanqr"],
  description: "Read/decode a QR code from an image",
  category: "Utility",
  usage: ".qrread (reply to image with QR code)",
  cooldown: 5000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let imgMsg = null;
    if (messageType === "imageMessage") {
      imgMsg = message.imageMessage;
    } else if (quoted?.message?.imageMessage) {
      imgMsg = quoted.message.imageMessage;
    }

    if (!imgMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Please send or reply to an *image containing a QR code* with .qrread",
      });
    }

    await sock.sendMessage(from, { text: "🔍 Reading QR code..." });

    let tmpFile = null;
    try {
      tmpFile = await downloadMediaToFile(imgMsg, "image", "jpg");

      const form = new FormData();
      form.append("file", fs.createReadStream(tmpFile), "qr.jpg");

      const res = await axios.post(
        "https://api.qrserver.com/v1/read-qr-code/",
        form,
        { headers: form.getHeaders(), timeout: 15000 }
      );

      const result = res.data?.[0]?.symbol?.[0]?.data;
      if (!result) {
        return sock.sendMessage(from, { text: "❌ No QR code found in the image." });
      }

      await sock.sendMessage(from, {
        text: `✅ *QR Code Decoded!*\n\n📝 Content:\n${result}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ QR reading failed: ${err.message}` });
    } finally {
      if (tmpFile) await fs.remove(tmpFile).catch(() => {});
    }
  },
};
