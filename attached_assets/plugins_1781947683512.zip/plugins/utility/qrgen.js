// ============================================
// AA MD Bot - QR Code Generator Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const axios = require("axios");

module.exports = {
  command: ["qr", "qrcode", "qrgen"],
  description: "Generate a QR code from text or URL",
  category: "Utility",
  usage: ".qr <text or URL>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .qr <text or URL>\nExample: .qr https://google.com",
      });
    }

    const data = args.join(" ");
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(data)}`;

    try {
      const res = await axios.get(qrUrl, { responseType: "arraybuffer", timeout: 10000 });
      await sock.sendMessage(from, {
        image: Buffer.from(res.data),
        caption: `📱 *QR Code Generated*\n\n📝 Data: ${data.length > 50 ? data.slice(0, 47) + "..." : data}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ QR generation failed: ${err.message}` });
    }
  },
};
