// ============================================
// AA MD Bot - Currency Converter Plugin
// Developer: Ahsan Ali | AA Mods
// Uses Frankfurter.app (free, no key) + fallback
// ============================================

const axios = require("axios");

module.exports = {
  command: ["currency", "convert", "rate"],
  description: "Convert currency (e.g. .currency 100 USD PKR)",
  category: "Utility",
  usage: ".currency <amount> <from> <to>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (args.length < 3) {
      return sock.sendMessage(from, {
        text:
          "⚠️ Usage: .currency <amount> <from> <to>\n\n" +
          "Examples:\n" +
          "• .currency 100 USD PKR\n" +
          "• .currency 50 EUR GBP\n" +
          "• .currency 1 BTC USD",
      });
    }

    const amount = parseFloat(args[0]);
    const fromCurr = args[1].toUpperCase();
    const toCurr = args[2].toUpperCase();

    if (isNaN(amount) || amount <= 0) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid positive amount." });
    }

    // ── Try 1: Frankfurter.app (free, reliable, no key) ──────────
    try {
      const res = await axios.get(
        `https://api.frankfurter.app/latest?from=${fromCurr}&to=${toCurr}`,
        { timeout: 10000 }
      );
      const rate = res.data?.rates?.[toCurr];
      if (rate) {
        const converted = (amount * rate).toFixed(4);
        return await sock.sendMessage(from, {
          text:
            `💱 *Currency Conversion*\n\n` +
            `💰 *${amount} ${fromCurr}* = *${converted} ${toCurr}*\n` +
            `📊 Rate: 1 ${fromCurr} = ${rate} ${toCurr}\n` +
            `📅 Date: ${res.data?.date || "Today"}\n\n` +
            `_Powered by Frankfurter | AA MD Bot_`,
        });
      }
    } catch (e) {
      console.warn("[Currency] Frankfurter failed:", e.message.slice(0, 60));
    }

    // ── Try 2: exchangerate-api.com open tier ─────────────────────
    try {
      const res = await axios.get(
        `https://open.er-api.com/v6/latest/${fromCurr}`,
        { timeout: 10000 }
      );
      const data = res.data;
      if (data.result === "success") {
        const rate = data.rates[toCurr];
        if (!rate) {
          return sock.sendMessage(from, { text: `❌ Invalid currency code: *${toCurr}*` });
        }
        const converted = (amount * rate).toFixed(4);
        return await sock.sendMessage(from, {
          text:
            `💱 *Currency Conversion*\n\n` +
            `💰 *${amount} ${fromCurr}* = *${converted} ${toCurr}*\n` +
            `📊 Rate: 1 ${fromCurr} = ${rate.toFixed(6)} ${toCurr}\n\n` +
            `_Powered by ExchangeRate-API | AA MD Bot_`,
        });
      }
    } catch (e) {
      console.warn("[Currency] ExchangeRate-API failed:", e.message.slice(0, 60));
    }

    // ── Try 3: coinconvert API ────────────────────────────────────
    try {
      const res = await axios.get(
        `https://api.coinconvert.net/convert/${fromCurr.toLowerCase()}/${toCurr.toLowerCase()}?amount=${amount}`,
        { timeout: 10000 }
      );
      const result = res.data;
      if (result?.status === "success") {
        const converted = Object.values(result).find((v) => typeof v === "number" && v !== amount);
        if (converted) {
          return await sock.sendMessage(from, {
            text:
              `💱 *Currency Conversion*\n\n` +
              `💰 *${amount} ${fromCurr}* = *${converted} ${toCurr}*\n\n` +
              `_Powered by CoinConvert | AA MD Bot_`,
          });
        }
      }
    } catch (e) {
      console.warn("[Currency] CoinConvert failed:", e.message.slice(0, 60));
    }

    await sock.sendMessage(from, {
      text:
        `❌ Currency conversion failed.\n\n` +
        `Please check:\n` +
        `• Currency codes are correct (e.g. USD, PKR, EUR)\n` +
        `• Note: Crypto (BTC/ETH) may not be supported on all APIs`,
    });
  },
};
