// ============================================
// AA MD Bot - URL Shortener Plugin
// Developer: Ahsan Ali | AA Mods
// Uses TinyURL free API
// ============================================

const axios = require("axios");

module.exports = {
  command: ["shorten", "shorturl", "tinyurl"],
  description: "Shorten a long URL",
  category: "Utility",
  usage: ".shorten <URL>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .shorten <URL>\nExample: .shorten https://example.com/very-long-url",
      });
    }

    let url = args[0];
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      url = "https://" + url;
    }

    try {
      const res = await axios.get(
        `https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`,
        { timeout: 10000 }
      );
      await sock.sendMessage(from, {
        text: `🔗 *URL Shortened!*\n\n📎 Original: ${url.length > 50 ? url.slice(0, 47) + "..." : url}\n✅ Short URL: ${res.data}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Shortening failed: ${err.message}` });
    }
  },
};
