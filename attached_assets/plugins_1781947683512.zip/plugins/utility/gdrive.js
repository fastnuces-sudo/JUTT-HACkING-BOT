// ============================================
// AA MD Bot - Google Drive Info Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const axios = require("axios");

module.exports = {
  command: ["gdrive", "gdl", "gdinfo"],
  description: "Get info/direct link for a Google Drive file",
  category: "Utility",
  usage: ".gdrive <Google Drive link>",
  cooldown: 10000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .gdrive <Google Drive link>" });
    }

    const url = args[0];
    const idMatch = url.match(/[-\w]{25,}/);
    if (!url.includes("drive.google.com") || !idMatch) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid Google Drive link." });
    }

    const fileId = idMatch[0];
    const directLink = `https://drive.google.com/uc?export=download&id=${fileId}`;
    const viewLink = `https://drive.google.com/file/d/${fileId}/view`;

    await sock.sendMessage(from, {
      text: `📁 *Google Drive File*\n\n` +
        `🆔 File ID: ${fileId}\n` +
        `🔗 *View Link:*\n${viewLink}\n\n` +
        `⬇️ *Direct Download:*\n${directLink}\n\n` +
        `_Note: Direct download only works for files without sharing restrictions_`,
    });
  },
};
