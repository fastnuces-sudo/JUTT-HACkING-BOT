// ============================================
// AA MD Bot - Calculator Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["calc", "calculate", "math"],
  description: "Evaluate mathematical expressions",
  category: "Utility",
  usage: ".calc <expression>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .calc <expression>\nExample: .calc 15 * 24 + 100 / 5",
      });
    }

    const expr = args.join(" ");

    // Safe evaluation: only allow numbers and math operators
    const safe = expr.replace(/[^0-9+\-*/%^.()\s]/g, "");
    if (!safe.trim()) {
      return sock.sendMessage(from, { text: "❌ Invalid expression." });
    }

    try {
      // Use Function constructor for controlled eval
      // eslint-disable-next-line no-new-func
      const result = new Function(`"use strict"; return (${safe})`)();
      if (typeof result !== "number" || !isFinite(result)) {
        return sock.sendMessage(from, { text: "❌ Invalid calculation." });
      }
      await sock.sendMessage(from, {
        text: `🧮 *Calculator*\n\n📝 Expression: \`${expr}\`\n✅ Result: *${result}*`,
      });
    } catch {
      await sock.sendMessage(from, { text: "❌ Could not evaluate the expression." });
    }
  },
};
