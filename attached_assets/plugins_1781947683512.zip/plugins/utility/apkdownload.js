// ============================================
// AA MD Bot - APK Search Plugin
// Developer: Ahsan Ali | AA Mods
// Searches Google Play Store + APKPure
// ============================================

const axios = require("axios");

module.exports = {
  command: ["apk", "apkdownload"],
  description: "Search for an Android APK",
  category: "Utility",
  usage: ".apk <app name>",
  cooldown: 10000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .apk <app name>\nExample: .apk WhatsApp",
      });
    }

    const query = args.join(" ");
    await sock.sendMessage(from, { text: `🔍 Searching APK for: *${query}*...` });

    // ── Try: APKPure API (JSON endpoint) ─────────────────────────
    try {
      const res = await axios.get(
        `https://apkpure.com/api/v1/search_suggestion_new?key=${encodeURIComponent(query)}&limit=1&country=us&lang=en`,
        {
          timeout: 12000,
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            Accept: "application/json",
          },
        }
      );
      const apps = res.data;
      if (Array.isArray(apps) && apps.length > 0) {
        const app = apps[0];
        const text =
          `📱 *${app.title || query}*\n\n` +
          `📦 *Package:* ${app.package_name || "N/A"}\n` +
          `⭐ *Rating:* ${app.score ? `${parseFloat(app.score).toFixed(1)}/5` : "N/A"}\n` +
          `📥 *Downloads:* ${app.download || "N/A"}\n\n` +
          `🔗 *APKPure:*\nhttps://apkpure.com/${encodeURIComponent((app.title || query).toLowerCase().replace(/\s+/g, "-"))}/${app.package_name || ""}\n\n` +
          `🔗 *Google Play:*\nhttps://play.google.com/store/apps/details?id=${app.package_name || ""}\n\n` +
          `_Search result from APKPure_`;

        if (app.icon) {
          return await sock.sendMessage(from, {
            image: { url: app.icon },
            caption: text,
          });
        }
        return await sock.sendMessage(from, { text });
      }
    } catch (e) {
      console.warn("[APK] APKPure API failed:", e.message.slice(0, 60));
    }

    // ── Fallback: provide search links ────────────────────────────
    const encodedQuery = encodeURIComponent(query);
    await sock.sendMessage(from, {
      text:
        `📱 *APK Search: ${query}*\n\n` +
        `Search on these sites:\n\n` +
        `🔗 *Google Play Store:*\nhttps://play.google.com/store/search?q=${encodedQuery}&c=apps\n\n` +
        `🔗 *APKPure:*\nhttps://apkpure.com/search?q=${encodedQuery}\n\n` +
        `🔗 *APKMirror:*\nhttps://www.apkmirror.com/?post_type=app_release&searchtype=apk&s=${encodedQuery}\n\n` +
        `_AA MD Bot_`,
    });
  },
};
