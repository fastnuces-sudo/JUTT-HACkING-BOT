// ============================================
// AA MD Bot - Timezone Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const moment = require("moment-timezone");

const timezones = {
  pk: "Asia/Karachi",
  us: "America/New_York",
  uk: "Europe/London",
  in: "Asia/Kolkata",
  ae: "Asia/Dubai",
  sa: "Asia/Riyadh",
  cn: "Asia/Shanghai",
  jp: "Asia/Tokyo",
  au: "Australia/Sydney",
  ca: "America/Toronto",
  de: "Europe/Berlin",
  fr: "Europe/Paris",
  br: "America/Sao_Paulo",
  ru: "Europe/Moscow",
  eg: "Africa/Cairo",
  tr: "Europe/Istanbul",
  bd: "Asia/Dhaka",
  ng: "Africa/Lagos",
  id: "Asia/Jakarta",
  my: "Asia/Kuala_Lumpur",
};

module.exports = {
  command: ["time", "timezone", "tz"],
  description: "Get current time for a country/timezone",
  category: "Utility",
  usage: ".time <country code> | .time pk",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      const list = Object.entries(timezones)
        .map(([code, tz]) => `• ${code.toUpperCase()} - ${tz}`)
        .join("\n");
      return sock.sendMessage(from, {
        text: `⚠️ Usage: .time <country code>\n\n🌍 Available:\n${list}`,
      });
    }

    const code = args[0].toLowerCase();
    const tz = timezones[code] || args.join(" ");

    try {
      const time = moment.tz(tz);
      if (!time.isValid()) {
        return sock.sendMessage(from, { text: `❌ Invalid timezone: ${tz}` });
      }

      await sock.sendMessage(from, {
        text:
          `🕐 *Time for ${tz}*\n\n` +
          `📅 *Date:* ${time.format("dddd, MMMM Do YYYY")}\n` +
          `⏰ *Time:* ${time.format("hh:mm:ss A")}\n` +
          `🌍 *UTC Offset:* ${time.format("Z")}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Error: ${err.message}` });
    }
  },
};
