// ============================================
// AA MD Bot - Islamic Commands Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const config = require("../../config");
const LINK = config.channelLink || "https://aa-mods.vercel.app/";

// ── Helpers ──────────────────────────────────────────────────────
function card(title, body) {
  return `┌─────────────────────────┐\n${title}\n└─────────────────────────┘\n\n${body}\n\n━━━━━━━━━━━━━━━━━━━━\n🌐 ${LINK}`;
}

// ── Duas ─────────────────────────────────────────────────────────
const DUAS = {
  dua_forgiveness: {
    title: "🤲 Dua for Forgiveness",
    arabic: "رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",
    trans: "Rabbana zalamna anfusana wa-in lam taghfir lana wa-tarhamna lana kunan minal-khasirin",
    meaning: "Our Lord! We have wronged ourselves. If You forgive us not and have no mercy on us, surely we are of the lost!",
    ref: "📖 Surah Al-A'raf 7:23",
  },
  dua_rizq: {
    title: "💰 Dua for Rizq (Provision)",
    arabic: "اللَّهُمَّ اكْفِنِي بِحَلَالِكَ عَنْ حَرَامِكَ وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ",
    trans: "Allahumm-akfini bi-halalika 'an haramika wa-aghni bi-fadlika 'amman siwak",
    meaning: "O Allah! Suffice me with what You have allowed instead of what You have forbidden, and make me independent of all others besides You.",
    ref: "📖 Tirmidhi",
  },
  dua_guidance: {
    title: "🌟 Dua for Guidance",
    arabic: "اللَّهُمَّ اهْدِنِي وَسَدِّدْنِي",
    trans: "Allahumm-ahdini wa saddidni",
    meaning: "O Allah, guide me and keep me on the straight path.",
    ref: "📖 Muslim",
  },
  dua_health: {
    title: "❤️ Dua for Good Health",
    arabic: "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي",
    trans: "Allahumma 'afini fi badani, Allahumma 'afini fi sam'i, Allahumma 'afini fi basari",
    meaning: "O Allah, grant me health in my body. O Allah, grant me health in my hearing. O Allah, grant me health in my sight.",
    ref: "📖 Abu Dawud",
  },
  dua_morning: {
    title: "🌅 Dua for Morning",
    arabic: "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
    trans: "Allahumma bika asbahnaa, wa bika amseynaa, wa bika nahyaa, wa bika namuutu, wa ilaikan-nushuur",
    meaning: "O Allah, by You we have entered the morning, and by You we reach the evening, and by You we live and by You we die, and to You is the resurrection.",
    ref: "📖 Abu Dawud & Tirmidhi",
  },
  dua_evening: {
    title: "🌙 Dua for Evening",
    arabic: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
    trans: "Allahumma bika amseynaa, wa bika asbahnaa, wa bika nahyaa, wa bika namuutu, wa ilaykal-maseer",
    meaning: "O Allah, by You we reach the evening, by You we enter the morning, by You we live, by You we die, and to You is our return.",
    ref: "📖 Abu Dawud & Tirmidhi",
  },
  dua_sleep: {
    title: "😴 Dua Before Sleep",
    arabic: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
    trans: "Bismika Allahumma amutu wa ahyaa",
    meaning: "In Your name, O Allah, I die and I live.",
    ref: "📖 Bukhari",
  },
  dua_travel: {
    title: "✈️ Dua for Travel",
    arabic: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنقَلِبُونَ",
    trans: "Subhaanal-lathee sakhkhara lanaa haathaa wa maa kunnaa lahu muqrineen, wa innaa ilaa rabbinaa lamunqaliboon",
    meaning: "Glory be to Him Who has subjected this to us, and we could never have it (by our efforts). And verily, to Our Lord we indeed are to return!",
    ref: "📖 Surah Az-Zukhruf 43:13-14",
  },
  dua_food: {
    title: "🍽️ Dua Before Eating",
    arabic: "بِسْمِ اللهِ وَعَلَى بَرَكَةِ اللهِ",
    trans: "Bismillahi wa 'alaa barakatillah",
    meaning: "In the name of Allah and with the blessings of Allah.",
    ref: "📖 Abu Dawud",
  },
  dua_after_food: {
    title: "✅ Dua After Eating",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ",
    trans: "Alhamdulillahil-lathee at'amanaa wa saqaanaa wa ja'alanaa muslimeen",
    meaning: "All praise is for Allah Who has given us food and drink and made us Muslims.",
    ref: "📖 Abu Dawud & Tirmidhi",
  },
  dua_exam: {
    title: "📚 Dua for Studies / Exam",
    arabic: "رَّبِّ زِدْنِي عِلْمًا",
    trans: "Rabbi zidni 'ilma",
    meaning: "My Lord, increase me in knowledge.",
    ref: "📖 Surah Ta-Ha 20:114",
  },
  dua_anxiety: {
    title: "😰 Dua for Anxiety & Stress",
    arabic: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْبُخْلِ وَالْجُبْنِ، وَضَلَعِ الدَّيْنِ، وَغَلَبَةِ الرِّجَالِ",
    trans: "Allahumma inni a'udhu bika minal-hammi wal-hazani, wal-'ajzi wal-kasali, wal-bukhli wal-jubni, wa dala'id-dayni, wa ghalabatir-rijaal",
    meaning: "O Allah, I seek refuge in You from worry and grief, from incapacity and laziness, from miserliness and cowardice, from being heavily in debt and from being overpowered by others.",
    ref: "📖 Bukhari",
  },
  dua_parents: {
    title: "💚 Dua for Parents",
    arabic: "رَّبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا",
    trans: "Rabbir-hamhumaa kamaa rabbayaani sagheeraa",
    meaning: "My Lord, have mercy on them (my parents) as they raised me when I was small.",
    ref: "📖 Surah Al-Isra 17:24",
  },
};

// ── Zikr ─────────────────────────────────────────────────────────
const ZIKR = {
  zikr_astaghfirullah: {
    title: "🌿 Astaghfirullah",
    arabic: "أَسْتَغْفِرُ اللهَ",
    trans: "Astaghfirullah",
    meaning: "I seek forgiveness from Allah",
    fadilat: "💎 Whoever recites this 100 times a day, his sins will be forgiven even if they are as much as the foam of the sea. (Bukhari)",
  },
  zikr_alhamdulillah: {
    title: "🌸 Alhamdulillah",
    arabic: "الْحَمْدُ لِلَّهِ",
    trans: "Alhamdulillah",
    meaning: "All praise is due to Allah",
    fadilat: "💎 It fills the scales of deeds. (Muslim)",
  },
  zikr_subhanallah: {
    title: "✨ Subhanallah",
    arabic: "سُبْحَانَ اللَّهِ",
    trans: "SubhanAllah",
    meaning: "Glory be to Allah",
    fadilat: "💎 Saying SubhanAllah 100 times, 100 good deeds are written. (Muslim)",
  },
  zikr_allahuakbar: {
    title: "🔱 Allahu Akbar",
    arabic: "اللَّهُ أَكْبَرُ",
    trans: "Allahu Akbar",
    meaning: "Allah is the Greatest",
    fadilat: "💎 The most beloved words to Allah are: SubhanAllah, Alhamdulillah, La ilaha illallah, Allahu Akbar. (Muslim)",
  },
  zikr_lailahaillallah: {
    title: "☪️ La Ilaha Illallah",
    arabic: "لَا إِلَٰهَ إِلَّا اللَّهُ",
    trans: "La ilaha illallah",
    meaning: "There is no god but Allah",
    fadilat: "💎 The best dhikr is La ilaha illallah. (Tirmidhi)",
  },
  zikr_lahawla: {
    title: "🌙 La Hawla Wa La Quwwata",
    arabic: "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
    trans: "La hawla wa la quwwata illa billah",
    meaning: "There is no power and no might except with Allah",
    fadilat: "💎 It is a treasure from the treasures of Jannah. (Bukhari & Muslim)",
  },
  zikr_bismillah: {
    title: "🌟 Bismillah",
    arabic: "بِسْمِ اللهِ الرَّحْمَنِ الرَّحِيمِ",
    trans: "Bismillahir-rahmanir-raheem",
    meaning: "In the name of Allah, the Most Gracious, the Most Merciful",
    fadilat: "💎 Begin every good deed with Bismillah. (Ibn Majah)",
  },
  zikr_hasbunallah: {
    title: "🛡️ Hasbunallah",
    arabic: "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ",
    trans: "Hasbunallahu wa ni'mal-wakeel",
    meaning: "Allah is sufficient for us, and He is the best Disposer of affairs.",
    fadilat: "💎 Ibrahim ﷺ said this when thrown into fire, and the fire became cool for him. (Bukhari)",
  },
};

// ── Hadiths ───────────────────────────────────────────────────────
const HADITHS = {
  hadith_good_morals: {
    title: "📜 Hadith — Good Morals",
    arabic: "أَكْمَلُ الْمُؤْمِنِينَ إِيمَانًا أَحْسَنُهُمْ خُلُقًا",
    text: "The most complete of believers in faith is the one with the best character.",
    ref: "📖 Abu Dawud & Tirmidhi",
  },
  hadith_cleanliness: {
    title: "🧼 Hadith — Cleanliness",
    arabic: "الطَّهُورُ شَطْرُ الْإِيمَانِ",
    text: "Cleanliness is half of faith.",
    ref: "📖 Muslim",
  },
  hadith_truth: {
    title: "✅ Hadith — Truth",
    arabic: "عَلَيْكُمْ بِالصِّدْقِ فَإِنَّ الصِّدْقَ يَهْدِي إِلَى الْبِرِّ",
    text: "Truthfulness leads to righteousness and righteousness leads to Paradise. A man keeps telling the truth until he is recorded as truthful with Allah. Lying leads to wickedness and wickedness leads to Hellfire.",
    ref: "📖 Bukhari & Muslim",
  },
  hadith_patience: {
    title: "⏳ Hadith — Patience (Sabr)",
    arabic: "مَا يُصِيبُ الْمُسْلِمَ مِنْ نَصَبٍ وَلَا وَصَبٍ",
    text: "No person suffers any anxiety or grief, fatigue or disease, harm or sorrow — not even a thorn that pricks him — except that Allah will expiate some of his sins for that.",
    ref: "📖 Bukhari",
  },
  hadith_smile: {
    title: "😊 Hadith — Smiling is Sadaqah",
    arabic: "تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ",
    text: "Your smile in the face of your brother is charity (sadaqah).",
    ref: "📖 Tirmidhi",
  },
  hadith_knowledge: {
    title: "📚 Hadith — Seeking Knowledge",
    arabic: "طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ",
    text: "Seeking knowledge is an obligation upon every Muslim.",
    ref: "📖 Ibn Majah",
  },
  hadith_neighbour: {
    title: "🏠 Hadith — Good Neighbour",
    arabic: "مَنْ كَانَ يُؤْمِنُ بِاللهِ وَالْيَوْمِ الْآخِرِ فَلْيُكْرِمْ جَارَهُ",
    text: "Whoever believes in Allah and the Last Day should be kind to his neighbor.",
    ref: "📖 Bukhari & Muslim",
  },
};

// ── Specials ──────────────────────────────────────────────────────
const SPECIALS = {
  darood_sharif: {
    title: "💚 Darood Ibrahim (Durood Sharif)",
    arabic: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ\nاللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ",
    trans: "Allahumma salli 'alaa Muhammadin wa 'alaa aali Muhammadin...",
    meaning: "O Allah, send Your mercy on Muhammad ﷺ and on the family of Muhammad ﷺ, as You sent Your mercy on Ibrahim and the family of Ibrahim. Indeed, You are Praiseworthy and Glorious.\nO Allah, bless Muhammad ﷺ and the family of Muhammad ﷺ, as You blessed Ibrahim and the family of Ibrahim. Indeed, You are Praiseworthy and Glorious.",
    fadilat: "💎 Whoever sends Darood on me once, Allah sends 10 mercies upon him. (Muslim)",
  },
  kalima_tayyiba: {
    title: "☪️ 1st Kalima — Tayyiba",
    arabic: "لَا إِلَٰهَ إِلَّا اللهُ مُحَمَّدٌ رَّسُولُ اللهِ",
    trans: "La ilaha illallahu Muhammadur Rasulullah",
    meaning: "There is no God but Allah, Muhammad ﷺ is the Messenger of Allah",
    fadilat: "💎 It is the key to Paradise. (Ahmad)",
  },
  kalima_shahadat: {
    title: "☪️ 2nd Kalima — Shahadat",
    arabic: "أَشْهَدُ أَنْ لَّا إِلٰهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
    trans: "Ashhadu an laa ilaaha illallahu wahdahu laa shareeka lahu wa ashhadu anna Muhammadan 'abduhu wa rasooluh",
    meaning: "I bear witness that there is no god but Allah, alone without any partner, and I bear witness that Muhammad ﷺ is His servant and Messenger.",
    fadilat: "💎 Whoever dies knowing La ilaha illallah will enter Jannah. (Muslim)",
  },
  kalima_tamjeed: {
    title: "🌟 3rd Kalima — Tamjeed",
    arabic: "سُبْحَانَ اللهِ وَالْحَمْدُ لِلهِ وَلَا إِلٰهَ إِلَّا اللهُ وَاللهُ أَكْبَرُ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللهِ الْعَلِيِّ الْعَظِيمِ",
    trans: "SubhanAllahi walhamdulillahi wa laa ilaaha illallahu wallahu akbar wa laa hawla wa laa quwwata illa billahil 'aliyyil 'azeem",
    meaning: "Glory be to Allah, all praise is for Allah, there is no god but Allah, Allah is the Greatest, there is no might nor power except with Allah, the Most High, the Most Great.",
    fadilat: "💎 A treasure from the treasures of Jannah. (Bukhari & Muslim)",
  },
  kalima_tauheed: {
    title: "☝️ 4th Kalima — Tauheed",
    arabic: "لَا إِلٰهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ يُحْيِيْ وَيُمِيتُ وَهُوَ حَيٌّ لَّا يَمُوتُ بِيَدِهِ الْخَيْرُ وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيرٌ",
    trans: "Laa ilaaha illallahu wahdahu laa shareeka lahu lahul-mulku wa lahul-hamdu yuhyee wa yumeetu wa huwa hayyun laa yamuotu biyadihil-khayru wa huwa 'alaa kulli shay'in qadeer",
    meaning: "There is no god but Allah, alone without any partner. To Him belongs the kingdom and all praise. He gives life and causes death. He is Ever-Living and never dies. In His Hand is all good and He is Powerful over everything.",
    fadilat: "💎 Whoever recites this 10 times after Fajr, Allah grants him 10 rewards. (Tirmidhi)",
  },
  kalima_astaghfar: {
    title: "🤲 5th Kalima — Astaghfar",
    arabic: "أَسْتَغْفِرُ اللهَ رَبِّيْ مِنْ كُلِّ ذَنْبٍ أَذْنَبْتُهُ عَمَدًا أَوْ خَطَاءً سِرًّا أَوْ عَلَانِيَةً وَأَتُوبُ إِلَيْهِ مِنَ الذَّنْبِ الَّذِيْ أَعْلَمُ وَمِنَ الذَّنْبِ الَّذِيْ لَا أَعْلَمُ إِنَّكَ أَنْتَ عَلَّامُ الْغُيُوبِ",
    trans: "Astaghfirullaaha rabbee min kulli dhambin adhnabtuhu 'amadan aw khata'an sirran aw 'alaaniyatan wa atoobu ilayhi minadh-dhambil-ladhee a'lamu wa minadh-dhambil-ladhee laa a'lamu innaka anta 'allaamul-ghuyoob",
    meaning: "I seek forgiveness from Allah, my Lord, from every sin I committed knowingly or unknowingly, secretly or openly, and I turn towards Him from every sin that I know about and every sin that I do not know about. Indeed You are the Knower of the unseen.",
    fadilat: "💎 Sincere repentance erases all sins. (Quran 39:53)",
  },
  kalima_radde_kufr: {
    title: "🛡️ 6th Kalima — Radde Kufr",
    arabic: "اللَّهُمَّ إِنِّيْ أَعُوذُ بِكَ مِنْ أَنْ أُشْرِكَ بِكَ شَيْئًا وَّأَنَا أَعْلَمُ بِهِ وَأَسْتَغْفِرُكَ لِمَا لَا أَعْلَمُ بِهِ تُبْتُ عَنْهُ وَتَبَرَّأْتُ مِنَ الْكُفْرِ وَالشِّرْكِ وَالْكِذْبِ وَالْغِيبَةِ وَالْبِدْعَةِ وَالنَّمِيمَةِ وَالْفَوَاحِشِ وَالْبُهْتَانِ وَالْمَعَاصِيْ كُلِّهَا",
    trans: "Allahumma inni a'udhu bika min an ushrika bika shay'an wa ana a'lamu bihi wa astaghfiruka limaa laa a'lamu bihi tubtu 'anhu wa tabarra'tu minal-kufri wash-shirki wal-kadhibi wal-gheebati wal-bid'ati wan-nameemati wal-fawaahishi wal-buhtaani wal-ma'aasi kullihaa",
    meaning: "O Allah! I seek refuge in You from knowingly committing shirk with You and I seek Your forgiveness for sins I do not know about. I repent from them and I reject disbelief, idolatry, lying, backbiting, innovation, slander, shameful deeds, false accusation and all other sins.",
    fadilat: "💎 This kalima protects from kufr and shirk.",
  },
};

// ── Morning Adhkar ────────────────────────────────────────────────
const MORNING_ADHKAR = [
  { arabic: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ", trans: "Asbahnaa wa asbahal mulku lillah, walhamdulillah, laa ilaaha illallahu wahdahu laa shareeka lah", count: "1×" },
  { arabic: "اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ", trans: "Allahumma bika asbahnaa wa bika amseynaa wa bika nahyaa wa bika namuutu wa ilaykan-nushoor", count: "1×" },
  { arabic: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ", trans: "Allahumma anta rabbee laa ilaaha illaa ant, khalaqtani wa ana 'abduk, wa ana 'alaa 'ahdika wa wa'dika mas-tata't (Sayyidul-Istigfar)", count: "1×" },
  { arabic: "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nاللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ... (آية الكرسي)", trans: "Ayatul Kursi — Surah Al-Baqarah 2:255", count: "1×" },
  { arabic: "سُبْحَانَ اللهِ وَبِحَمْدِهِ", trans: "SubhanAllahi wa bihamdihi", count: "100×" },
];

// ── Evening Adhkar ────────────────────────────────────────────────
const EVENING_ADHKAR = [
  { arabic: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ", trans: "Amseynaa wa amsal mulku lillah, walhamdulillah, laa ilaaha illallahu wahdahu laa shareeka lah", count: "1×" },
  { arabic: "اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ", trans: "Allahumma bika amseynaa wa bika asbahnaa wa bika nahyaa wa bika namuutu wa ilaykal-maseer", count: "1×" },
  { arabic: "اللَّهُمَّ إِنِّي أَمْسَيْتُ أُشْهِدُكَ وَأُشْهِدُ حَمَلَةَ عَرْشِكَ وَمَلَائِكَتَكَ وَجَمِيعَ خَلْقِكَ أَنَّكَ أَنْتَ اللَّهُ لَا إِلَهَ إِلَّا أَنْتَ وَحْدَكَ لَا شَرِيكَ لَكَ وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ", trans: "Allahumma inni amseetu ushhhiduka... (4×)", count: "4×" },
  { arabic: "بِسْمِ اللهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", trans: "Bismillahil-lathee laa yadurru ma'as-mihi shay'un fil-ardi wa laa fis-samaa'i wa huwas-samee'ul-'aleem", count: "3×" },
  { arabic: "أَعُوذُ بِكَلِمَاتِ اللهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", trans: "A'udhu bi kalimatillahit-taammaati min sharri maa khalaq", count: "3×" },
];

// ── 99 Names (sample) ─────────────────────────────────────────────
const NAMES_99 = [
  "1. اَلرَّحْمٰنُ — Ar-Rahman — The Most Gracious",
  "2. اَلرَّحِيْمُ — Ar-Raheem — The Most Merciful",
  "3. اَلْمَلِكُ — Al-Malik — The King",
  "4. اَلْقُدُّوْسُ — Al-Quddus — The Most Pure",
  "5. اَلسَّلَامُ — As-Salaam — The Source of Peace",
  "6. اَلْمُؤْمِنُ — Al-Mu'min — The Granter of Security",
  "7. اَلْمُهَيْمِنُ — Al-Muhaymin — The Protector",
  "8. اَلْعَزِيْزُ — Al-'Aziz — The Almighty",
  "9. اَلْجَبَّارُ — Al-Jabbar — The Compeller",
  "10. اَلْمُتَكَبِّرُ — Al-Mutakabbir — The Supreme",
  "11. اَلْخَالِقُ — Al-Khaliq — The Creator",
  "12. اَلْبَارِئُ — Al-Bari' — The Evolver",
  "13. اَلْمُصَوِّرُ — Al-Musawwir — The Shaper",
  "14. اَلْغَفَّارُ — Al-Ghaffar — The Repeatedly Forgiving",
  "15. اَلْقَهَّارُ — Al-Qahhar — The Subduer",
  "16. اَلْوَهَّابُ — Al-Wahhab — The Bestower",
  "17. اَلرَّزَّاقُ — Ar-Razzaq — The Provider",
  "18. اَلْفَتَّاحُ — Al-Fattah — The Opener",
  "19. اَلْعَلِيْمُ — Al-'Aleem — The All-Knowing",
  "20. اَلْقَابِضُ — Al-Qabid — The Withholder",
  "21-30. اَلْبَاسِطُ · اَلْخَافِضُ · اَلرَّافِعُ · اَلْمُعِزُّ · اَلْمُذِلُّ · اَلسَّمِيعُ · اَلْبَصِيرُ · اَلْحَكَمُ · اَلْعَدْلُ · اَللَّطِيفُ",
  "31-40. اَلْخَبِيرُ · اَلْحَلِيمُ · اَلْعَظِيمُ · اَلْغَفُورُ · اَلشَّكُورُ · اَلْعَلِيُّ · اَلْكَبِيرُ · اَلْحَفِيظُ · اَلْمُقِيتُ · اَلْحَسِيبُ",
  "41-50. اَلْجَلِيلُ · اَلْكَرِيمُ · اَلرَّقِيبُ · اَلْمُجِيبُ · اَلْوَاسِعُ · اَلْحَكِيمُ · اَلْوَدُودُ · اَلْمَجِيدُ · اَلْبَاعِثُ · اَلشَّهِيدُ",
  "51-60. اَلْحَقُّ · اَلْوَكِيلُ · اَلْقَوِيُّ · اَلْمَتِينُ · اَلْوَلِيُّ · اَلْحَمِيدُ · اَلْمُحْصِي · اَلْمُبْدِئُ · اَلْمُعِيدُ · اَلْمُحْيِي",
  "61-70. اَلْمُمِيتُ · اَلْحَيُّ · اَلْقَيُّومُ · اَلْوَاجِدُ · اَلْمَاجِدُ · اَلْوَاحِدُ · اَلْأَحَدُ · اَلصَّمَدُ · اَلْقَادِرُ · اَلْمُقْتَدِرُ",
  "71-80. اَلْمُقَدِّمُ · اَلْمُؤَخِّرُ · اَلْأَوَّلُ · اَلْآخِرُ · اَلظَّاهِرُ · اَلْبَاطِنُ · اَلْوَالِي · اَلْمُتَعَالِ · اَلْبَرُّ · اَلتَّوَّابُ",
  "81-90. اَلْمُنْتَقِمُ · اَلْعَفُوُّ · اَلرَّؤُوفُ · مَالِكُ الْمُلْكِ · ذُو الْجَلَالِ وَالْإِكْرَامِ · اَلْمُقْسِطُ · اَلْجَامِعُ · اَلْغَنِيُّ · اَلْمُغْنِي · اَلْمَانِعُ",
  "91-99. اَلضَّارُّ · اَلنَّافِعُ · اَلنُّورُ · اَلْهَادِي · اَلْبَدِيعُ · اَلْبَاقِي · اَلْوَارِثُ · اَلرَّشِيدُ · اَلصَّبُورُ",
];

// ── Facts ─────────────────────────────────────────────────────────
const FACTS = [
  "🕌 The word 'Islam' means peace and submission to the will of Allah.",
  "📖 The Quran has 114 Surahs (chapters) and 6,236 Ayat (verses).",
  "🌙 The Islamic calendar is based on the lunar cycle, not the solar cycle.",
  "🕋 The Kaaba in Makkah is considered the house of Allah and the most sacred place in Islam.",
  "📿 The 99 Names of Allah (Al-Asma Al-Husna) describe His attributes.",
  "🌍 Islam is the world's second-largest religion with nearly 2 billion followers.",
  "🤲 Muslims pray five times a day: Fajr, Zuhr, Asr, Maghrib, Isha.",
  "✨ Zakat (charity) is one of the Five Pillars — 2.5% of savings given annually.",
  "🌺 Friday (Jumu'ah) is the holiest day of the week in Islam.",
  "💚 The Prophet Muhammad ﷺ said: 'The best of you are those who have the best manners.'",
  "📿 SubhanAllah — AlHamdulillah — Allahu Akbar said 33 times each after every prayer is Sunnah.",
  "🌙 Ramadan is the 9th month of the Islamic calendar — the month of fasting and blessings.",
  "🕌 The Five Pillars of Islam are: Shahadah, Salah, Zakat, Sawm (fasting), and Hajj.",
  "📖 The Quran was revealed to Prophet Muhammad ﷺ over 23 years.",
  "🌟 Surah Al-Fatiha (The Opening) is recited in every unit (rak'ah) of every prayer.",
  "⭐ Laylatul Qadr (Night of Power) is better than 1000 months — in the last 10 nights of Ramadan.",
  "🕌 Makkah, Madinah, and Jerusalem are the three holiest cities in Islam.",
  "💎 Jannah (Paradise) has 8 gates, and Jahannam (Hell) has 7 gates.",
];

const REMINDERS = [
  "🌟 *Daily Reminder*\n\nDon't forget your 5 daily prayers! Each Salah is a direct conversation with Allah.",
  "📖 *Daily Reminder*\n\nRecite at least 1 page of Quran today. Even small deeds done consistently are beloved to Allah.",
  "🤲 *Daily Reminder*\n\nStart your morning with Fajr prayer and say Bismillah before every task.",
  "💚 *Daily Reminder*\n\n'Whoever is grateful, I will surely increase him in favor.' — Quran 14:7\nBe grateful for every blessing today!",
  "🌺 *Daily Reminder*\n\nSend Darood on the Prophet ﷺ today. Every salawat brings 10 blessings.",
  "⏳ *Daily Reminder*\n\nSabr (patience) is a virtue. Whatever trial you face today, trust Allah's plan.",
  "🕌 *Daily Reminder*\n\nIf you haven't prayed yet, do it now. Prayer is the pillar of Deen.",
  "🌙 *Daily Reminder*\n\nBefore sleeping, say Bismika Allahumma amutu wa ahya — In Your name, O Allah, I die and I live.",
  "🌿 *Daily Reminder*\n\nSay Astaghfirullah 100 times today. Allah loves those who seek His forgiveness.",
  "💛 *Daily Reminder*\n\nSmile at your family, help someone in need — even a smile is sadaqah!",
];

// ── Prayers Info ──────────────────────────────────────────────────
const PRAYERS_INFO =
  `🕌 *Five Daily Prayers (Salah)*\n\n` +
  `1️⃣ *Fajr* (Dawn) — Before sunrise\n` +
  `   • 2 Sunnah + 2 Fard\n\n` +
  `2️⃣ *Zuhr* (Midday) — After sun passes zenith\n` +
  `   • 4 Sunnah + 4 Fard + 2 Sunnah + 2 Nafl\n\n` +
  `3️⃣ *Asr* (Afternoon) — Mid-afternoon\n` +
  `   • 4 Sunnah (Ghair Mu'akkadah) + 4 Fard\n\n` +
  `4️⃣ *Maghrib* (Sunset) — Just after sunset\n` +
  `   • 3 Fard + 2 Sunnah + 2 Nafl\n\n` +
  `5️⃣ *Isha* (Night) — After twilight disappears\n` +
  `   • 4 Sunnah + 4 Fard + 2 Sunnah + 2 Nafl + 3 Witr\n\n` +
  `🌟 *Friday Jumu'ah:* 2 Sunnah + 2 Fard (replaces Zuhr)\n\n` +
  `━━━━━━━━━━━━━━━━━━━━\n` +
  `💡 Use a local prayer times app for exact times in your city.\n` +
  `🌐 ${LINK}`;

// ── Fikra-e-Jaffery (Shia / Ahl al-Bayt ع) ───────────────────────
const JAFFERY = {
  dua_kumayl: {
    title: "🌙 Dua Kumayl — دعاء كميل",
    arabic:
      "اللَّهُمَّ إِنِّي أَسْأَلُكَ بِرَحْمَتِكَ الَّتِي وَسِعَتْ كُلَّ شَيْءٍ\n" +
      "وَبِقُوَّتِكَ الَّتِي قَهَرْتَ بِهَا كُلَّ شَيْءٍ\n" +
      "وَخَضَعَ لَهَا كُلُّ شَيْءٍ وَذَلَّ لَهَا كُلُّ شَيْءٍ\n" +
      "وَبِجَبَرُوتِكَ الَّتِي غَلَبْتَ بِهَا كُلَّ شَيْءٍ\n" +
      "اللَّهُمَّ اغْفِرْ لِيَ الذُّنُوبَ الَّتِي تَهْتِكُ الْعِصَمَ\n" +
      "اللَّهُمَّ اغْفِرْ لِيَ الذُّنُوبَ الَّتِي تُنْزِلُ النِّقَمَ\n" +
      "اللَّهُمَّ اغْفِرْ لِيَ الذُّنُوبَ الَّتِي تُغَيِّرُ النِّعَمَ\n" +
      "اللَّهُمَّ اغْفِرْ لِيَ الذُّنُوبَ الَّتِي تَحْبِسُ الدُّعَاءَ\n" +
      "اللَّهُمَّ اغْفِرْ لِيَ الذُّنُوبَ الَّتِي تَقْطَعُ الرَّجَاءَ",
    trans:
      "O Allah, I beseech You by Your mercy which encompasses all things,\n" +
      "and by Your power by which You dominate all things,\n" +
      "O Allah, forgive me those sins which tear away safeguards,\n" +
      "O Allah, forgive me those sins which bring down calamities,\n" +
      "O Allah, forgive me those sins which change blessings,\n" +
      "O Allah, forgive me those sins which hold back prayer.",
    note:
      "📖 *Dua Kumayl* — Taught by Imam Ali ع to his companion Kumayl ibn Ziyad.\n" +
      "Recited every Thursday night or the night before Jumu'ah.\n" +
      "_(This is the opening portion — full dua is very long.)_",
    ref: "📚 Source: Bihar al-Anwar, Vol. 94",
  },
  dua_arafah: {
    title: "🕋 Dua Arafah — Imam Husain ع",
    arabic:
      "الْحَمْدُ لِلَّهِ الَّذِي لَيْسَ لِقَضَائِهِ دَافِعٌ\n" +
      "وَلَا لِعَطَائِهِ مَانِعٌ وَلَا كَصُنْعِهِ صُنْعُ صَانِعٍ\n" +
      "وَهُوَ الْجَوَادُ الْوَاسِعُ\n\n" +
      "إِلَهِي أَنَا الْفَقِيرُ فِي غِنَايَ فَكَيْفَ لَا أَكُونُ فَقِيرًا فِي فَقْرِي\n" +
      "إِلَهِي أَنَا الْجَاهِلُ فِي عِلْمِي فَكَيْفَ لَا أَكُونُ جَهُولًا فِي جَهْلِي\n" +
      "إِلَهِي إِنَّ اخْتِلَافَ تَدْبِيرِكَ وَسُرْعَةَ طَوَاءِ مَقَادِيرِكَ\n" +
      "مَنَعَا عِبَادَكَ الْعَارِفِينَ بِكَ عَنِ السُّكُونِ إِلَى عَطَاءٍ\n" +
      "وَالْيَأْسِ مِنْكَ فِي بَلَاءٍ",
    trans:
      "All praise is for Allah whose decrees none can repel,\n" +
      "whose gifts none can withhold, whose work is like no other.\n\n" +
      "My God, I am the poor one despite my (seeming) richness —\n" +
      "so how can I not be poor in my poverty?\n" +
      "My God, I am the ignorant one despite my knowledge —\n" +
      "so how can I not be ignorant in my ignorance?",
    note:
      "📖 *Dua Arafah* — Recited by Imam Husain ع on the Day of Arafah (9th Dhul Hijjah).\n" +
      "One of the most profound supplications in Islamic tradition.\n" +
      "_(Opening portion — full dua is extensive.)_",
    ref: "📚 Source: Mafatih al-Jinan — Sheikh Abbas Qummi",
  },
  dua_tawassul: {
    title: "💚 Dua Tawassul — دعاء التوسل",
    arabic:
      "اللَّهُمَّ إِنِّي أَسْأَلُكَ وَأَتَوَجَّهُ إِلَيْكَ بِنَبِيِّكَ\n" +
      "نَبِيِّ الرَّحْمَةِ مُحَمَّدٍ صَلَّى اللهُ عَلَيْهِ وَآلِهِ\n" +
      "يَا مُحَمَّدُ يَا رَسُولَ اللهِ\n" +
      "إِنِّي أَتَوَجَّهُ بِكَ إِلَى اللهِ رَبِّكَ وَرَبِّي\n" +
      "لِيَقْضِيَ حَاجَتِي\n\n" +
      "يَا عَلِيُّ يَا أَمِيرَ الْمُؤْمِنِينَ\n" +
      "يَا فَاطِمَةُ يَا بِنْتَ مُحَمَّدٍ\n" +
      "يَا حَسَنُ يَا حُسَيْنُ\n" +
      "يَا أَئِمَّةَ الْهُدَى عَلَيْكُمُ السَّلَامُ\n" +
      "اشْفَعُوا لَنَا عِنْدَ اللهِ",
    trans:
      "O Allah, I ask You and turn to You through Your Prophet,\n" +
      "the Prophet of Mercy, Muhammad ﷺ,\n" +
      "O Muhammad, O Messenger of Allah,\n" +
      "I turn to Allah through you — my Lord and yours — to fulfill my need.\n\n" +
      "O Ali, O Commander of the Faithful,\n" +
      "O Fatimah, daughter of Muhammad ﷺ,\n" +
      "O Hasan, O Husain,\n" +
      "O Imams of guidance, peace be upon you all — intercede for us with Allah.",
    note: "📖 Recited when seeking intercession (tawassul) through the Ahl al-Bayt ع.",
    ref: "📚 Source: Mafatih al-Jinan",
  },
  ziyarat_ashura: {
    title: "🌹 Ziyarat Ashura — زيارة عاشوراء",
    arabic:
      "السَّلَامُ عَلَيْكَ يَا أَبَا عَبْدِ اللهِ\n" +
      "السَّلَامُ عَلَيْكَ يَا ابْنَ رَسُولِ اللهِ\n" +
      "السَّلَامُ عَلَيْكَ يَا ابْنَ أَمِيرِ الْمُؤْمِنِينَ\n" +
      "وَابْنَ سَيِّدِ الْوَصِيِّينَ\n" +
      "السَّلَامُ عَلَيْكَ يَا ابْنَ فَاطِمَةَ سَيِّدَةِ نِسَاءِ الْعَالَمِينَ\n\n" +
      "السَّلَامُ عَلَيْكَ يَا ثَارَ اللهِ وَابْنَ ثَارِهِ وَالْوِتْرَ الْمَوْتُورَ\n\n" +
      "بِأَبِي أَنْتَ وَأُمِّي يَا أَبَا عَبْدِ اللهِ\n" +
      "لَقَدْ عَظُمَتِ الرَّزِيَّةُ وَجَلَّتِ الْمُصِيبَةُ بِكَ عَلَيْنَا",
    trans:
      "Peace be upon you, O Aba Abdillah (Imam Husain ع).\n" +
      "Peace be upon you, O son of the Messenger of Allah.\n" +
      "Peace be upon you, O son of the Commander of the Faithful,\n" +
      "and son of the master of all successors.\n" +
      "Peace be upon you, O son of Fatimah — Mistress of the Women of the Worlds.\n\n" +
      "Peace be upon you, O avenger of Allah and son of His avenger,\n" +
      "O the one who was wronged and whose revenge remains.\n\n" +
      "My father and mother be your ransom, O Aba Abdillah —\n" +
      "truly the tragedy was immense and the calamity was great upon us.",
    note:
      "📖 *Ziyarat Ashura* — Narrated from Imam Baqir ع.\n" +
      "Recited especially on the 10th of Muharram (Ashura) and throughout Muharram.\n" +
      "_(Opening portion — full ziyarat includes la'n and salam sections.)_",
    ref: "📚 Source: Kamil al-Ziyarat — Ibn Qulawayh; Misbah al-Mutahajjid",
  },
  salawat_aal: {
    title: "💚 Salawat Aal-e-Muhammad — اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّدٍ",
    arabic:
      "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّدٍ\n" +
      "وَعَجِّلْ فَرَجَهُمْ\n\n" +
      "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَآلِ مُحَمَّدٍ\n" +
      "الطَّيِّبِينَ الطَّاهِرِينَ الْمَعْصُومِينَ\n" +
      "وَاجْعَلْنَا مَعَهُمْ وَلَا تُفَرِّقْ بَيْنَنَا وَبَيْنَهُمْ\n\n" +
      "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ بَيْتِهِ الطَّاهِرِينَ\n" +
      "وَاللَّعْنَةُ الدَّائِمَةُ عَلَى أَعْدَائِهِمْ أَجْمَعِينَ",
    trans:
      "O Allah, send Your blessings upon Muhammad and the family of Muhammad,\n" +
      "and hasten their relief (Imam Mahdi ع).\n\n" +
      "O Allah, send Your blessings upon Muhammad and the family of Muhammad,\n" +
      "the pure, the purified, the infallible —\n" +
      "and keep us with them, and do not separate us from them.",
    note:
      "📖 Recited frequently in Shia tradition. The phrase *وَعَجِّلْ فَرَجَهُمْ* (hasten their relief)\n" +
      "refers to the reappearance of Imam Mahdi ع (the 12th Imam).\n" +
      "Sending salawat on Aal-e-Muhammad is obligatory in prayer.",
    ref: "📚 Quran 33:56 | Mafatih al-Jinan",
  },
  masoomeen14: {
    title: "✨ 14 Masoomeen — چودہ معصومین",
    arabic: "",
    trans: "",
    note:
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `   ✨ 14 MASOOMEEN (ع)\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `1️⃣  *Prophet Muhammad ﷺ* — سیدنا محمد مصطفی\n` +
      `2️⃣  *Bibi Fatimah Zahra ع* — فاطمہ زہرا\n` +
      `3️⃣  *Imam Ali ع* — علی ابن ابی طالب\n` +
      `4️⃣  *Imam Hasan ع* — حسن المجتبیٰ\n` +
      `5️⃣  *Imam Husain ع* — حسین بن علی (شہید کربلا)\n` +
      `6️⃣  *Imam Zain-ul-Abideen ع* — علی بن حسین\n` +
      `7️⃣  *Imam Muhammad Baqir ع* — محمد الباقر\n` +
      `8️⃣  *Imam Jafar Sadiq ع* — جعفر الصادق\n` +
      `9️⃣  *Imam Musa Kazim ع* — موسی الکاظم\n` +
      `🔟  *Imam Ali Raza ع* — علی الرضا\n` +
      `1️⃣1️⃣ *Imam Muhammad Taqi ع* — محمد الجواد\n` +
      `1️⃣2️⃣ *Imam Ali Naqi ع* — علی الہادی\n` +
      `1️⃣3️⃣ *Imam Hasan Askari ع* — حسن العسکری\n` +
      `1️⃣4️⃣ *Imam Mahdi ع* — محمد المہدی (منتظَر)\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `💚 *Imam Jafar Sadiq ع* — 8th Imam is the founder of Jafari Fiqh\n` +
      `🌟 Imam Mahdi ع is in occultation (Ghaybat) and will reappear before Qiyamah.`,
    ref: "📚 Fikra-e-Jaffery | Madrasah-e-Ahl al-Bayt",
  },
  dua_imam_zaman: {
    title: "🌟 Dua for Imam Mahdi ع — Imam-e-Zaman",
    arabic:
      "اللَّهُمَّ كُنْ لِوَلِيِّكَ الْحُجَّةِ ابْنِ الْحَسَنِ\n" +
      "صَلَوَاتُكَ عَلَيْهِ وَعَلَى آبَائِهِ\n" +
      "فِي هَذِهِ السَّاعَةِ وَفِي كُلِّ سَاعَةٍ\n" +
      "وَلِيًّا وَحَافِظًا وَقَائِدًا وَنَاصِرًا وَدَلِيلًا وَعَيْنًا\n" +
      "حَتَّى تُسْكِنَهُ أَرْضَكَ طَوْعًا\n" +
      "وَتُمَتِّعَهُ فِيهَا طَوِيلًا",
    trans:
      "O Allah, be for Your Wali — Al-Hujjah, son of Al-Hasan,\n" +
      "Your blessings be upon him and his forefathers —\n" +
      "in this hour and in every hour:\n" +
      "a guardian, a keeper, a leader, a helper, a guide and a watchful eye.\n" +
      "Until You settle him in Your earth willingly,\n" +
      "and grant him long enjoyment therein.",
    note:
      "📖 Dua for the safety and reappearance of *Imam Mahdi ع* (12th Imam).\n" +
      "Recited daily — especially after Fajr and Isha prayers in Shia tradition.",
    ref: "📚 Source: Mafatih al-Jinan",
  },
  nohay_karbala: {
    title: "🌹 Karbala — یاد کربلا",
    arabic:
      "لَبَّيْكَ يَا حُسَيْنُ\n" +
      "السَّلَامُ عَلَيْكَ يَا أَبَا عَبْدِ اللهِ\n" +
      "السَّلَامُ عَلَيْكَ يَا شَهِيدَ كَرْبَلَاءَ\n" +
      "السَّلَامُ عَلَيْكَ يَا مَظْلُومَ يَا مَقْتُولَ\n\n" +
      "هَلْ مِنْ نَاصِرٍ يَنْصُرُنِي؟\n" +
      "— Imam Husain ع, Day of Ashura, Karbala 61 AH",
    trans:
      "Here I am, O Husain!\n" +
      "Peace be upon you, O Aba Abdillah!\n" +
      "Peace be upon you, O Martyr of Karbala!\n" +
      "Peace be upon you, O oppressed one, O the slain!\n\n" +
      "'Is there anyone to help me?' — Imam Husain ع",
    note:
      "📖 *Karbala Tragedy* — 10th Muharram, 61 AH (680 CE)\n\n" +
      "Imam Husain ع, grandson of Prophet Muhammad ﷺ,\n" +
      "rose against the tyranny of Yazid ibn Muawiya to uphold justice.\n" +
      "He was martyred with 72 companions in Karbala (modern Iraq).\n\n" +
      "🌹 *Shia Muslims worldwide observe Muharram and Ashura in his memory.*\n" +
      "💧 *Ya Husain ع — the symbol of justice over oppression.*",
    ref: "📚 History: Tarikh al-Tabari | Maqtal al-Husain",
  },
};

// ── Pillar commands ───────────────────────────────────────────────
// islamic_menu first so it appears as the representative entry in .menu
const ALL_COMMANDS = [
  "islamic_menu",
  ...Object.keys(DUAS),
  ...Object.keys(ZIKR),
  ...Object.keys(HADITHS),
  ...Object.keys(SPECIALS),
  ...Object.keys(JAFFERY),
  "jaffery_menu",
  "islam_fact", "quran_reminder",
  "morning_adhkar", "evening_adhkar",
  "prayers_info", "salah_info",
  "asmaul_husna", "99names",
];

module.exports = {
  command: ALL_COMMANDS,
  description: "Islamic duas, zikr, hadiths, kalimas, adhkar & reminders",
  category: "Islamic",
  usage: ".islamic_menu for full list",

  async execute({ sock, ctx }) {
    const { from, body } = ctx;
    if (!body) return;
    const cmd = body.split(" ")[0].replace(/[.!/#]/g, "").toLowerCase();

    // ── Duas ──────────────────────────────────────────────────────
    if (DUAS[cmd]) {
      const d = DUAS[cmd];
      return sock.sendMessage(from, {
        text: card(d.title,
          `🔤 *Arabic:*\n${d.arabic}\n\n` +
          `🗣️ *Transliteration:*\n_${d.trans}_\n\n` +
          `🌐 *Translation:*\n${d.meaning}\n\n` +
          (d.ref ? d.ref : "")
        ),
      });
    }

    // ── Zikr ──────────────────────────────────────────────────────
    if (ZIKR[cmd]) {
      const z = ZIKR[cmd];
      return sock.sendMessage(from, {
        text: card(z.title,
          `🔤 *Arabic:*\n${z.arabic}\n\n` +
          `🗣️ *Transliteration:*\n_${z.trans}_\n\n` +
          `🌐 *Meaning:*\n${z.meaning}\n\n` +
          (z.fadilat || "")
        ),
      });
    }

    // ── Hadiths ───────────────────────────────────────────────────
    if (HADITHS[cmd]) {
      const h = HADITHS[cmd];
      return sock.sendMessage(from, {
        text: card(h.title,
          `🔤 *Arabic:*\n${h.arabic}\n\n` +
          `💬 *Meaning:*\n"${h.text}"\n\n` +
          h.ref
        ),
      });
    }

    // ── Specials (Kalimas, Darood) ────────────────────────────────
    if (SPECIALS[cmd]) {
      const s = SPECIALS[cmd];
      let body2 = `🔤 *Arabic:*\n${s.arabic}\n\n`;
      if (s.trans) body2 += `🗣️ *Transliteration:*\n_${s.trans}_\n\n`;
      body2 += `🌐 *Translation:*\n${s.meaning}\n\n${s.fadilat || ""}`;
      return sock.sendMessage(from, { text: card(s.title, body2) });
    }

    // ── Morning Adhkar ────────────────────────────────────────────
    if (cmd === "morning_adhkar") {
      let text = `☀️ *Morning Adhkar*\n_(Recite after Fajr)_\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;
      MORNING_ADHKAR.forEach((a, i) => {
        text += `*${i + 1}.* ${a.count}\n${a.arabic}\n_${a.trans}_\n\n`;
      });
      text += `━━━━━━━━━━━━━━━━━━━━\n🌐 ${LINK}`;
      return sock.sendMessage(from, { text });
    }

    // ── Evening Adhkar ────────────────────────────────────────────
    if (cmd === "evening_adhkar") {
      let text = `🌙 *Evening Adhkar*\n_(Recite after Asr)_\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;
      EVENING_ADHKAR.forEach((a, i) => {
        text += `*${i + 1}.* ${a.count}\n${a.arabic}\n_${a.trans}_\n\n`;
      });
      text += `━━━━━━━━━━━━━━━━━━━━\n🌐 ${LINK}`;
      return sock.sendMessage(from, { text });
    }

    // ── 99 Names ──────────────────────────────────────────────────
    if (cmd === "asmaul_husna" || cmd === "99names") {
      let text = `📿 *Asmaul Husna — 99 Names of Allah*\n\n━━━━━━━━━━━━━━━━━━━━\n\n`;
      text += NAMES_99.join("\n") + `\n\n━━━━━━━━━━━━━━━━━━━━\n💎 Whoever memorizes them will enter Jannah. (Bukhari)\n🌐 ${LINK}`;
      return sock.sendMessage(from, { text });
    }

    // ── Prayer info ───────────────────────────────────────────────
    if (cmd === "prayers_info" || cmd === "salah_info") {
      return sock.sendMessage(from, { text: PRAYERS_INFO });
    }

    // ── Random fact ───────────────────────────────────────────────
    if (cmd === "islam_fact") {
      const fact = FACTS[Math.floor(Math.random() * FACTS.length)];
      return sock.sendMessage(from, {
        text: `📚 *Islamic Fact*\n\n${fact}\n\n━━━━━━━━━━━━━━━━━━━━\n🌐 ${LINK}`,
      });
    }

    // ── Random reminder ───────────────────────────────────────────
    if (cmd === "quran_reminder") {
      const reminder = REMINDERS[Math.floor(Math.random() * REMINDERS.length)];
      return sock.sendMessage(from, {
        text: `${reminder}\n\n━━━━━━━━━━━━━━━━━━━━\n🌐 ${LINK}`,
      });
    }

    // ── Fikra-e-Jaffery / Ahl al-Bayt ع ──────────────────────────
    if (JAFFERY[cmd]) {
      const j = JAFFERY[cmd];
      // masoomeen14 uses a pre-built note instead of arabic/trans
      if (cmd === "masoomeen14") {
        return sock.sendMessage(from, {
          text: `${j.note}\n\n━━━━━━━━━━━━━━━━━━━━\n${j.ref}\n🌐 ${LINK}`,
        });
      }
      let body2 = "";
      if (j.arabic) body2 += `🔤 *Arabic:*\n${j.arabic}\n\n`;
      if (j.trans)  body2 += `🌐 *Translation:*\n${j.trans}\n\n`;
      if (j.note)   body2 += `${j.note}\n\n`;
      body2 += j.ref || "";
      return sock.sendMessage(from, { text: card(j.title, body2) });
    }

    // ── Jaffery Menu ──────────────────────────────────────────────
    if (cmd === "jaffery_menu") {
      const pref = config.prefix;
      return sock.sendMessage(from, {
        text:
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `  🌹 *FIKRA-E-JAFFERY MENU*\n` +
          `     Ahl al-Bayt ع Commands\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `🤲 *DUAS (AHL AL-BAYT ع)*\n` +
          `  • ${pref}dua_kumayl      🌙 Dua Kumayl\n` +
          `  • ${pref}dua_arafah      🕋 Imam Husain ع (Arafah)\n` +
          `  • ${pref}dua_tawassul    💚 Dua Tawassul\n` +
          `  • ${pref}dua_imam_zaman  🌟 Dua for Imam Mahdi ع\n\n` +
          `🌹 *ZIYARAT*\n` +
          `  • ${pref}ziyarat_ashura  Ziyarat Ashura (Imam Husain ع)\n\n` +
          `💚 *SALAWAT & TASBIH*\n` +
          `  • ${pref}salawat_aal     Salawat Aal-e-Muhammad\n\n` +
          `✨ *MASOOMEEN & HISTORY*\n` +
          `  • ${pref}masoomeen14     14 Masoomeen (ع) Names\n` +
          `  • ${pref}nohay_karbala   🌹 Karbala — Ya Husain ع\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `💡 *Fikra-e-Jaffery* follows the Jafari Fiqh\n` +
          `   of Imam Jafar Sadiq ع (6th Imam).\n` +
          `🌐 ${LINK}`,
      });
    }

    // ── Islamic Menu ──────────────────────────────────────────────
    if (cmd === "islamic_menu") {
      const pref = config.prefix;
      return sock.sendMessage(from, {
        text:
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `   ☪️  *ISLAMIC COMMANDS*\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `🤲 *DUAS*\n` +
          `  • ${pref}dua_forgiveness  • ${pref}dua_rizq\n` +
          `  • ${pref}dua_guidance     • ${pref}dua_health\n` +
          `  • ${pref}dua_morning      • ${pref}dua_evening\n` +
          `  • ${pref}dua_sleep        • ${pref}dua_travel\n` +
          `  • ${pref}dua_food         • ${pref}dua_after_food\n` +
          `  • ${pref}dua_exam         • ${pref}dua_anxiety\n` +
          `  • ${pref}dua_parents\n\n` +
          `📿 *ZIKR*\n` +
          `  • ${pref}zikr_astaghfirullah  • ${pref}zikr_alhamdulillah\n` +
          `  • ${pref}zikr_subhanallah     • ${pref}zikr_allahuakbar\n` +
          `  • ${pref}zikr_lailahaillallah • ${pref}zikr_lahawla\n` +
          `  • ${pref}zikr_bismillah       • ${pref}zikr_hasbunallah\n\n` +
          `📜 *HADITHS*\n` +
          `  • ${pref}hadith_good_morals  • ${pref}hadith_cleanliness\n` +
          `  • ${pref}hadith_truth        • ${pref}hadith_patience\n` +
          `  • ${pref}hadith_smile        • ${pref}hadith_knowledge\n` +
          `  • ${pref}hadith_neighbour\n\n` +
          `☪️ *6 KALIMAS*\n` +
          `  • ${pref}kalima_tayyiba   (1st)\n` +
          `  • ${pref}kalima_shahadat  (2nd)\n` +
          `  • ${pref}kalima_tamjeed   (3rd)\n` +
          `  • ${pref}kalima_tauheed   (4th)\n` +
          `  • ${pref}kalima_astaghfar (5th)\n` +
          `  • ${pref}kalima_radde_kufr(6th)\n\n` +
          `💚 *SPECIALS*\n` +
          `  • ${pref}darood_sharif    (Durood Ibrahim)\n\n` +
          `🌅 *ADHKAR*\n` +
          `  • ${pref}morning_adhkar   • ${pref}evening_adhkar\n\n` +
          `🕌 *INFO*\n` +
          `  • ${pref}prayers_info     (5 daily prayers)\n` +
          `  • ${pref}asmaul_husna     (99 Names of Allah)\n` +
          `  • ${pref}islam_fact       (Random fact)\n` +
          `  • ${pref}quran_reminder   (Daily reminder)\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `🌹 *FIKRA-E-JAFFERY (Ahl al-Bayt ع)*\n` +
          `  Type *${pref}jaffery_menu* for full Shia\n` +
          `  Duas, Ziyarat, Salawat & Masoomeen\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `🌐 ${LINK}`,
      });
    }
  },
};
