// ============================================
// AA MD Bot - Report & Support Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const config = require("../../config");
const LINK = config.channelLink || "https://aa-mods.vercel.app/";

function getOwnerJid() {
  const num = (config.ownerNumber[0] || "").replace(/\D/g, "");
  return num ? `${num}@s.whatsapp.net` : null;
}

module.exports = {
  command: ["report", "bug", "contact", "feedback", "support"],
  description: "Report an issue or contact the owner",
  category: "General",
  usage: ".report <message> | <your phone number (optional)>",

  async execute({ sock, ctx, args }) {
    const { from, pushName, sender } = ctx;
    const cmd = ctx.body.split(" ")[0].replace(/[.!/#]/g, "").toLowerCase();
    const ownerJid = getOwnerJid();
    const pref = config.prefix;

    // ── .contact / .support — show owner contact info ────────────
    if (cmd === "contact" || cmd === "support") {
      const ownerNum = config.ownerNumber[0] || "Not set";
      return sock.sendMessage(from, {
        text:
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `   📞  *CONTACT / SUPPORT*\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `👨‍💻 *Owner:* ${config.ownerName}\n` +
          `📱 *WhatsApp:* +${ownerNum}\n` +
          `🤖 *Bot:* ${config.botName}\n\n` +
          `💬 *Commands:*\n` +
          `  • *${pref}report <message>* — Report an issue\n` +
          `  • *${pref}bug <description>* — Report a bug\n` +
          `  • *${pref}feedback <message>* — Send feedback\n\n` +
          `📌 *To add your contact number:*\n` +
          `  ${pref}report .play not working | 03001234567\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `🌐 ${LINK}`,
      });
    }

    // ── .report / .bug / .feedback — forward to owner ────────────
    const rawInput = args.join(" ").trim();

    if (!rawInput) {
      const examples = {
        report:   `${pref}report .play is not working | 03001234567`,
        bug:      `${pref}bug Sticker command crashes`,
        feedback: `${pref}feedback Love the bot!`,
      };
      return sock.sendMessage(from, {
        text:
          `⚠️ *Please include your message.*\n\n` +
          `📌 *Usage:*\n` +
          `  *${examples[cmd] || `${pref}${cmd} <message>`}*\n\n` +
          `💡 Add your phone number after *|* so the owner can contact you:\n` +
          `  *${pref}report .removebg gave broken image | 03001234567*`,
      });
    }

    // Parse message and optional contact number (separated by |)
    const pipeIdx = rawInput.indexOf("|");
    let msg = rawInput;
    let contactNum = "";

    if (pipeIdx !== -1) {
      msg = rawInput.slice(0, pipeIdx).trim();
      contactNum = rawInput.slice(pipeIdx + 1).trim().replace(/\D/g, "");
    }

    if (!msg) {
      return sock.sendMessage(from, {
        text: `⚠️ Please include a message before the | symbol.`,
      });
    }

    const typeMap = {
      report:   { emoji: "🚨", label: "Report" },
      bug:      { emoji: "🐛", label: "Bug Report" },
      feedback: { emoji: "💬", label: "Feedback" },
    };
    const { emoji, label } = typeMap[cmd] || { emoji: "📩", label: "Message" };
    const senderNum = sender.split("@")[0];
    const now = new Date().toLocaleString("en-PK", { timeZone: "Asia/Karachi" });
    const displayContact = contactNum || senderNum;

    // ── Confirm to sender ─────────────────────────────────────────
    await sock.sendMessage(from, {
      text:
        `✅ *${label} Sent!*\n\n` +
        `${emoji} Your message has been forwarded to the owner.\n\n` +
        `📝 *Your message:*\n_"${msg}"_\n` +
        (contactNum ? `📱 *Contact shared:* +${contactNum}\n` : "") +
        `\n⏳ The owner will get back to you soon.\n\n` +
        `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
        `🌐 ${LINK}`,
    });

    // ── Forward to owner ──────────────────────────────────────────
    if (ownerJid) {
      try {
        await sock.sendMessage(ownerJid, {
          text:
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `  ${emoji}  *${label.toUpperCase()} RECEIVED*\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `👤 *Name:* ${pushName || "Unknown"}\n` +
            `📱 *WA Number:* +${senderNum}\n` +
            (contactNum ? `☎️ *Contact Number:* +${contactNum} ⬅️\n` : "") +
            `🕐 *Time:* ${now}\n\n` +
            `💬 *Message:*\n_"${msg}"_\n\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `💡 Reply to this to contact them directly.`,
        });
      } catch (_) {}
    }
  },
};
