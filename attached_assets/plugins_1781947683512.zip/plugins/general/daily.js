// ============================================
// AA MD Bot - Daily Bonus Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getUser, updateUser, addBalance, addXP } = require("../../lib/database");
const { formatNumber } = require("../../lib/utils");
const config = require("../../config");

const DAILY_COOLDOWN = 24 * 60 * 60 * 1000; // 24 hours

module.exports = {
  command: ["daily", "claim"],
  description: "Claim your daily bonus",
  category: "General",
  usage: ".daily",

  async execute({ sock, ctx }) {
    const { from, sender } = ctx;
    const user = getUser(sender);
    const now = Date.now();
    const lastClaim = user.dailyLastClaimed || 0;
    const timePassed = now - lastClaim;

    if (timePassed < DAILY_COOLDOWN) {
      const remaining = DAILY_COOLDOWN - timePassed;
      const hours = Math.floor(remaining / 3600000);
      const mins = Math.floor((remaining % 3600000) / 60000);
      return sock.sendMessage(from, {
        text: `⏰ Already claimed today!\n\nNext claim in: *${hours}h ${mins}m*`,
      });
    }

    const bonus = config.dailyBonus;
    const xpBonus = 50;
    addBalance(sender, bonus);
    addXP(sender, xpBonus);
    updateUser(sender, { dailyLastClaimed: now });

    await sock.sendMessage(from, {
      text: `🎁 *Daily Bonus Claimed!*\n\n💵 Coins: +${formatNumber(bonus)}\n⭐ XP: +${xpBonus}\n\n💰 New Balance: ${formatNumber(getUser(sender).balance)}\n\nCome back tomorrow for more!`,
    });
  },
};
