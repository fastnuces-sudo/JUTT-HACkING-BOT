// ============================================
// AA MD Bot - Ping / Alive Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const fs = require("fs");
const path = require("path");
const { formatTime } = require("../../lib/utils");
const BANNER = path.join(__dirname, "../../assets/banner.jpg");

module.exports = {
  command: ["ping", "alive", "speed"],
  description: "Check if bot is online, ping speed, memory & uptime",
  category: "General",
  usage: ".alive",

  async execute({ sock, ctx }) {
    const { from } = ctx;

    // Send a first message and measure round-trip time for real ping
    const start = Date.now();
    const tempMsg = await sock.sendMessage(from, { text: "🏓 Pinging..." });
    const ping = Date.now() - start;

    const uptime = formatTime(process.uptime() * 1000);
    const mem = process.memoryUsage();
    const heapMB = Math.round(mem.heapUsed / 1024 / 1024);
    const rssMB  = Math.round(mem.rss / 1024 / 1024);

    const pingEmoji = ping < 300 ? "🟢" : ping < 800 ? "🟡" : "🔴";

    const text =
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `   🤖  *AA MD BOT*  🟢 Online\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `${pingEmoji} *Ping:*    ${ping}ms\n` +
      `⏱️ *Uptime:*  ${uptime}\n` +
      `💾 *Heap:*   ${heapMB} MB\n` +
      `📦 *RSS:*    ${rssMB} MB\n` +
      `🔑 *Prefix:* .\n\n` +
      `_AA MD Bot by Ahsan Ali | AA Mods_`;

    try {
      if (fs.existsSync(BANNER)) {
        await sock.sendMessage(from, {
          image: fs.readFileSync(BANNER),
          caption: text,
          mimetype: "image/jpeg",
        });
      } else {
        await sock.sendMessage(from, { text });
      }
    } catch {
      await sock.sendMessage(from, { text });
    }
  },
};
