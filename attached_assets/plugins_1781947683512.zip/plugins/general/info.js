// ============================================
// AA MD Bot - Bot Info Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================
const config = require("../../config");
const { formatTime, formatBytes } = require("../../lib/utils");
const os = require("os");
const fs = require("fs");
const path = require("path");
const BANNER = path.join(__dirname, "../../assets/banner.jpg");

module.exports = {
  command: ["info", "botinfo"],
  description: "Show detailed bot information",
  category: "General",
  usage: ".info",
  async execute({ sock, ctx }) {
    const { from } = ctx;
    const uptime = formatTime(process.uptime() * 1000);
    const mem = process.memoryUsage();
    const text =
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `       🤖  *BOT INFO*\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🏷️ *Name:* ${config.botName}\n` +
      `📦 *Version:* ${config.botVersion}\n` +
      `👨‍💻 *Developer:* ${config.developer}\n` +
      `🏢 *Brand:* ${config.brand}\n` +
      `🔑 *Prefix:* ${config.prefix}\n` +
      `🤖 *AI:* Gemini 2.5 Flash\n\n` +
      `⚙️ *System:*\n` +
      `  • Platform: ${os.platform()} ${os.arch()}\n` +
      `  • Node.js: ${process.version}\n` +
      `  • Uptime: ${uptime}\n\n` +
      `💾 *Memory:*\n` +
      `  • Used: ${formatBytes(mem.heapUsed)}\n` +
      `  • Total: ${formatBytes(os.totalmem())}\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `_AA Mods | Ahsan Ali_`;
    try {
      if (fs.existsSync(BANNER)) {
        await sock.sendMessage(from, { image: fs.readFileSync(BANNER), caption: text, mimetype: "image/jpeg" });
      } else {
        await sock.sendMessage(from, { text });
      }
    } catch {
      await sock.sendMessage(from, { text });
    }
  },
};
