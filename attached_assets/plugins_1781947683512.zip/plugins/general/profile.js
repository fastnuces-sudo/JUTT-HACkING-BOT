// ============================================
// AA MD Bot - User Profile Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getUser } = require("../../lib/database");
const { generateProgressBar, formatNumber, cleanJid } = require("../../lib/utils");
const config = require("../../config");

module.exports = {
  command: ["profile", "me", "stats"],
  description: "View your bot profile and stats",
  category: "General",
  usage: ".profile",

  async execute({ sock, ctx }) {
    const { from, sender, pushName } = ctx;
    const user = getUser(sender);
    const xpForNextLevel = config.levelUpXp;
    const currentXP = user.xp % xpForNextLevel;
    const bar = generateProgressBar(currentXP, xpForNextLevel, 12);

    const text = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
     👤  *YOUR PROFILE*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 *Name:* ${user.name || pushName}
🆔 *ID:* ${cleanJid(sender)}

📊 *Stats:*
• Level: ${user.level} ⭐
• XP: ${formatNumber(user.xp)}
• [${bar}] ${currentXP}/${xpForNextLevel}

💰 *Economy:*
• Balance: ${formatNumber(user.balance)} 💵
• Commands Used: ${user.commandsUsed}

🏅 *Status:* ${user.premium ? "⭐ Premium" : "🆓 Free"}${user.banned ? " | 🚫 Banned" : ""}`;

    await sock.sendMessage(from, { text });
  },
};
