// ============================================
// AA MD Bot - Menu Plugin (Clean Redesign)
// Developer: Ahsan Ali | AA Mods
// ============================================

const config  = require("../../config");
const { formatTime } = require("../../lib/utils");
const { getSetting }  = require("../../lib/database");
const fs   = require("fs");
const path = require("path");
const os   = require("os");

const BANNER_PATH = path.join(__dirname, "../../assets/banner.jpg");

const catEmoji = {
  General:  "📋",
  Islamic:  "☪️",
  AI:       "🤖",
  Download: "📥",
  Media:    "🎬",
  Search:   "🔍",
  Fun:      "🎉",
  Utility:  "🔧",
  Tools:    "🛠️",
  Group:    "👥",
  Admin:    "🛡️",
  Settings: "⚙️",
  Owner:    "👑",
  Support:  "📞",
};

// Islamic always first, then the rest in logical order, Owner/Support last
const CAT_ORDER = {
  Islamic: 0, General: 1, AI: 2, Download: 3, Media: 4,
  Search: 5, Fun: 6, Utility: 7, Tools: 8, Group: 9,
  Admin: 10, Settings: 11, Owner: 90, Support: 99,
};

const OWNER_CATS = new Set(["Owner"]);
const SKIP_CATS  = new Set(["Settings"]);

module.exports = {
  command: ["menu", "help"],
  description: "Show all available commands",
  category: "General",
  usage: ".menu",

  async execute({ sock, ctx, plugins }) {
    const { from, pushName, isOwner } = ctx;

    const upSec   = Math.floor(process.uptime());
    const upH     = Math.floor(upSec / 3600);
    const upM     = Math.floor((upSec % 3600) / 60);
    const upS     = upSec % 60;
    const uptime  = upH > 0
      ? `${upH}h ${upM}m ${upS}s`
      : upM > 0 ? `${upM}m ${upS}s` : `${upS}s`;

    const usedMB  = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
    const totalMB = Math.round(os.totalmem() / 1024 / 1024);
    const pref    = getSetting("prefix")   ?? config.prefix   ?? ".";
    const altPref = (config.altPrefixes || []).join("  ");
    const mode    = (getSetting("botMode") ?? config.botMode  ?? "public").toUpperCase();
    const role    = isOwner ? "Owner 👑" : "User";

    // ── Deduplicate plugins by file path ─────────────────────────
    const seen       = new Set();
    const categories = {};
    for (const plugin of Object.values(plugins)) {
      if (seen.has(plugin.file)) continue;
      seen.add(plugin.file);
      const cat  = plugin.category || "General";
      const cmds = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
      const main = cmds[0];
      const short = cmds.slice(1).find(a => a.length <= 3 && a !== main) || cmds[1] || null;
      const desc  = (plugin.description || "").slice(0, 35);
      if (!categories[cat]) categories[cat] = [];
      categories[cat].push({ main, short, desc });
    }

    const totalCmds = seen.size;

    // ── Header ────────────────────────────────────────────────────
    const greeting = isOwner
      ? `👋 *Assalamualaikum Owner!*`
      : `👋 *Assalamualaikum ${pushName}!*`;

    let menu =
      `${greeting}\n\n` +
      `━━━━━━ 📊 *Bot Status* ━━━━━━\n` +
      `🟢 Status    : Online\n` +
      `⏱️ Uptime    : ${uptime}\n` +
      `💾 RAM       : ${usedMB} MB / ${totalMB} MB\n` +
      `📦 Commands  : ${totalCmds}+\n` +
      `🔑 Prefix    : ${pref}${altPref ? `  |  Alt: ${altPref}` : ""}\n` +
      `🤖 Mode      : ${mode}\n` +
      `👑 Role      : ${role}\n`;

    // ── Categories ────────────────────────────────────────────────
    const sorted = Object.entries(categories).sort(([a], [b]) => {
      return (CAT_ORDER[a] ?? 50) - (CAT_ORDER[b] ?? 50) || a.localeCompare(b);
    });

    for (const [cat, cmds] of sorted) {
      if (SKIP_CATS.has(cat)) continue;
      if (OWNER_CATS.has(cat) && !isOwner) continue;

      const emoji = catEmoji[cat] || "📌";
      menu += `\n━━━━━━━━━━━━━━━━━━\n`;
      menu += `${emoji} *${cat.toUpperCase()}*\n`;

      for (const { main, short, desc } of cmds) {
        const label = short ? `*${pref}${main}* / *${pref}${short}*` : `*${pref}${main}*`;
        menu += `  ${label}${desc ? ` — ${desc}` : ""}\n`;
      }
    }

    // ── Quick Settings (owner only) ───────────────────────────────
    if (isOwner) {
      menu +=
        `\n━━━━━━━━━━━━━━━━━━\n` +
        `⚙️ *QUICK SETTINGS*\n` +
        `  *${pref}bs*              — Full settings panel\n` +
        `  *${pref}mode* public/private\n` +
        `  *${pref}anticall* on/off\n` +
        `  *${pref}antidelete* on/off\n` +
        `  *${pref}antiviewonce* on/off\n` +
        `  *${pref}statusview* on/off\n` +
        `  *${pref}statusreact* on/off\n` +
        `  *${pref}savestatus* on/off\n` +
        `  *${pref}welcomenew* on/off\n` +
        `  *${pref}recording* on/off\n` +
        `  *${pref}setprefix* <symbol>\n`;
    }

    // ── Footer ────────────────────────────────────────────────────
    menu += `\n━━━━━━━━━━━━━━━━━━\n`;
    menu += `🌐 ${config.channelLink || "https://aa-mods.vercel.app/"}`;

    const { getSetting: _gs } = require("../../lib/database");
    console.log(`[DBG-menu] execute called: from=${from} isOwner=${isOwner}`);
    try {
      if (fs.existsSync(BANNER_PATH)) {
        console.log(`[DBG-menu] sending image to ${from}`);
        await sock.sendMessage(from, {
          image: fs.readFileSync(BANNER_PATH),
          caption: menu,
          mimetype: "image/jpeg",
        });
        console.log(`[DBG-menu] image sent OK to ${from}`);
      } else {
        console.log(`[DBG-menu] sending text to ${from}`);
        await sock.sendMessage(from, { text: menu });
        console.log(`[DBG-menu] text sent OK to ${from}`);
      }
    } catch (e) {
      console.error(`[DBG-menu] sendMessage failed: ${e.message}`);
      await sock.sendMessage(from, { text: menu });
    }
  },
};
