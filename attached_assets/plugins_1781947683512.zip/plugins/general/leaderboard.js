// ============================================
// AA MD Bot - Leaderboard Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getLeaderboard } = require("../../lib/database");
const { formatNumber, cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["leaderboard", "top", "lb"],
  description: "Show XP leaderboard",
  category: "General",
  usage: ".leaderboard",

  async execute({ sock, ctx }) {
    const { from } = ctx;
    const leaders = getLeaderboard(10);
    const medals = ["🥇", "🥈", "🥉"];

    let text = `🏆 *XP LEADERBOARD*\n\n`;
    leaders.forEach((user, i) => {
      const medal = medals[i] || `${i + 1}.`;
      const name = user.name || cleanJid(user.id);
      text += `${medal} *${name}*\n   Level ${user.level} • ${formatNumber(user.xp)} XP\n\n`;
    });

    if (!leaders.length) {
      text += "No users yet. Start using commands to earn XP!";
    }

    await sock.sendMessage(from, { text });
  },
};
