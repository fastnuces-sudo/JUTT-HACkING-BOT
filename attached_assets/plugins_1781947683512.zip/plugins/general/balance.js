// ============================================
// AA MD Bot - Balance Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getUser } = require("../../lib/database");
const { formatNumber, cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["balance", "bal", "coins", "wallet"],
  description: "Check your coin balance",
  category: "General",
  usage: ".balance",

  async execute({ sock, ctx }) {
    const { from, sender, mentions, quoted } = ctx;

    let target = sender;
    if (mentions?.[0]) target = mentions[0];
    else if (quoted?.sender) target = quoted.sender;

    const user = getUser(target);
    const name = user.name || cleanJid(target);

    await sock.sendMessage(from, {
      text: `💰 *Wallet*\n\n👤 User: ${name}\n💵 Balance: *${formatNumber(user.balance)} coins*\n⭐ Level: ${user.level}\n📦 Commands Used: ${user.commandsUsed}`,
    });
  },
};
