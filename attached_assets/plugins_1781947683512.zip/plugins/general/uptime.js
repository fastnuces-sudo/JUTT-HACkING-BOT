// ============================================
// AA MD Bot - Uptime Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { formatTime } = require("../../lib/utils");

module.exports = {
  command: ["uptime", "runtime"],
  description: "Show bot uptime",
  category: "Utility",
  usage: ".uptime",

  async execute({ sock, ctx }) {
    const { from } = ctx;
    const uptime = formatTime(process.uptime() * 1000);
    await sock.sendMessage(from, {
      text: `⏱️ *Bot Uptime*\n\n🟢 Running for: *${uptime}*`,
    });
  },
};
