// ============================================
// AA MD Bot - Restart Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["restart", "reboot"],
  description: "Restart the bot",
  category: "Owner",
  usage: ".restart",
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;
    await sock.sendMessage(from, { text: "🔄 *Restarting AA MD Bot...*" });
    setTimeout(() => process.exit(0), 1000);
  },
};
