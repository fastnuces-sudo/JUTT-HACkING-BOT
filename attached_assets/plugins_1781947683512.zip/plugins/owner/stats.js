// ============================================
// AA MD Bot - Bot Stats Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getAllUsers, getAllSettings } = require("../../lib/database");
const { formatTime, formatBytes } = require("../../lib/utils");
const os = require("os");

module.exports = {
  command: ["stats", "botstats"],
  description: "View bot statistics",
  category: "Owner",
  usage: ".stats",
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;

    const users = getAllUsers();
    const totalUsers = Object.keys(users).length;
    const bannedUsers = Object.values(users).filter((u) => u.banned).length;
    const premiumUsers = Object.values(users).filter((u) => u.premium).length;
    const totalCommands = Object.values(users).reduce(
      (sum, u) => sum + (u.commandsUsed || 0),
      0
    );

    const mem = process.memoryUsage();
    const uptime = formatTime(process.uptime() * 1000);
    const cpuLoad = os.loadavg()[0].toFixed(2);

    const text = `📊 *AA MD Bot Statistics*\n\n` +
      `👥 *Users:* ${totalUsers}\n` +
      `⭐ *Premium:* ${premiumUsers}\n` +
      `🚫 *Banned:* ${bannedUsers}\n` +
      `💬 *Total Commands:* ${totalCommands}\n\n` +
      `💻 *System:*\n` +
      `• CPU Load: ${cpuLoad}%\n` +
      `• Heap Used: ${formatBytes(mem.heapUsed)}\n` +
      `• Uptime: ${uptime}\n` +
      `• Node.js: ${process.version}\n` +
      `• Platform: ${os.platform()} ${os.arch()}`;

    await sock.sendMessage(from, { text });
  },
};
