// ============================================
// AA MD Bot - Owner Info Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const config = require("../../config");

module.exports = {
  command: ["owner", "developer", "dev"],
  description: "Show bot owner/developer info",
  category: "Owner",
  usage: ".owner",

  async execute({ sock, ctx }) {
    const { from } = ctx;

    const text = `👑 *Bot Owner / Developer*\n\n` +
      `👤 *Name:* ${config.developer}\n` +
      `🏢 *Brand:* ${config.brand}\n` +
      `📱 *WhatsApp:* wa.me/${config.ownerNumber[0]}\n` +
      `🤖 *Bot:* ${config.botName}\n\n` +
      `💬 Contact the owner for support, features, or custom bots!`;

    await sock.sendMessage(from, {
      text,
      contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
      },
    });
  },
};
