// ============================================
// AA MD Bot - Premium System Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getUser, updateUser } = require("../../lib/database");
const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["addpremium", "delpremium", "premium"],
  description: "Manage premium users",
  category: "Owner",
  usage: ".addpremium @mention | .delpremium @mention",
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from, mentions, quoted, body } = ctx;
    const cmd = body.split(" ")[0].replace(/[.!/#]/g, "");

    if (cmd === "premium") {
      const user = getUser(ctx.sender);
      const isPremium = user.premium;
      return sock.sendMessage(from, {
        text: `⭐ Your premium status: *${isPremium ? "Premium ⭐" : "Free 🆓"}*`,
      });
    }

    let target = mentions?.[0] || quoted?.sender;
    if (!target) {
      return sock.sendMessage(from, { text: "⚠️ Please mention or reply to a user." });
    }

    const isAdd = cmd === "addpremium";
    updateUser(target, { premium: isAdd });
    await sock.sendMessage(from, {
      text: `${isAdd ? "⭐" : "🆓"} @${cleanJid(target)} is now *${isAdd ? "Premium" : "Free"}*!`,
      mentions: [target],
    });
  },
};
