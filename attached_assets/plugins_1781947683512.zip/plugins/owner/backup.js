// ============================================
// AA MD Bot - Backup Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const fs = require("fs-extra");
const path = require("path");
const config = require("../../config");

module.exports = {
  command: ["backup", "backupdb"],
  description: "Backup the database files",
  category: "Owner",
  usage: ".backup",
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const dbFiles = ["users.json", "groups.json", "settings.json"];
      let text = `💾 *Database Backup*\n\n`;

      for (const file of dbFiles) {
        const filePath = path.join(config.dbPath, file);
        if (fs.existsSync(filePath)) {
          const data = fs.readJSONSync(filePath);
          const count = Object.keys(data).length;
          text += `• ${file}: ${count} records\n`;

          // Send each DB file as document
          await sock.sendMessage(from, {
            document: fs.readFileSync(filePath),
            fileName: file,
            mimetype: "application/json",
            caption: `📁 ${file} backup`,
          });
        }
      }

      text += `\n✅ Backup complete!`;
      await sock.sendMessage(from, { text });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Backup failed: ${err.message}` });
    }
  },
};
