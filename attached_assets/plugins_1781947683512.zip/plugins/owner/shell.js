// ============================================
// AA MD Bot - Shell Plugin (Owner Only)
// Developer: Ahsan Ali | AA Mods
// ============================================

const { exec } = require("child_process");

module.exports = {
  command: ["shell", "$", "bash"],
  description: "Execute shell commands",
  category: "Owner",
  usage: ".shell <command>",
  ownerOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .shell <command>" });
    }

    const cmd = args.join(" ");
    await sock.sendMessage(from, { text: `⚙️ Running: \`${cmd}\`` });

    exec(cmd, { timeout: 15000 }, async (err, stdout, stderr) => {
      const output = (stdout || stderr || "No output").slice(0, 3000);
      await sock.sendMessage(from, {
        text: `${err ? "❌" : "✅"} *Shell Output:*\n\`\`\`\n${output}\n\`\`\``,
      });
    });
  },
};
