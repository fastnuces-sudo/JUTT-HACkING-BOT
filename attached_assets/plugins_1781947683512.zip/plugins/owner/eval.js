// ============================================
// AA MD Bot - Eval Plugin (Owner Only)
// Developer: Ahsan Ali | AA Mods
// WARNING: Dangerous command, owner only
// ============================================

const util = require("util");

module.exports = {
  command: ["eval", "=>", "js"],
  description: "Execute JavaScript code",
  category: "Owner",
  usage: ".eval <code>",
  ownerOnly: true,

  async execute({ sock, ctx, args, text }) {
    const { from } = ctx;

    if (!text.trim()) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .eval <JavaScript code>" });
    }

    try {
      // eslint-disable-next-line no-eval
      let result = eval(`(async () => { ${text} })()`);
      if (result instanceof Promise) result = await result;
      if (typeof result !== "string") result = util.inspect(result, { depth: 2 });

      await sock.sendMessage(from, {
        text: `✅ *Result:*\n\`\`\`\n${result}\n\`\`\``,
      });
    } catch (err) {
      await sock.sendMessage(from, {
        text: `❌ *Error:*\n\`\`\`\n${err.message}\n\`\`\``,
      });
    }
  },
};
