// ============================================
// AA MD Bot - Ban/Unban User Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getUser, updateUser } = require("../../lib/database");
const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["ban", "unban"],
  description: "Ban or unban a user from using the bot",
  category: "Owner",
  usage: ".ban @mention | .unban @mention",
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from, mentions, quoted, body } = ctx;
    const isBan = body.split(" ")[0].replace(/[.!/#]/g, "") === "ban";

    let target = mentions?.[0] || quoted?.sender;
    if (!target) {
      return sock.sendMessage(from, {
        text: `⚠️ Please mention or reply to a user to ${isBan ? "ban" : "unban"}.`,
      });
    }

    updateUser(target, { banned: isBan });
    await sock.sendMessage(from, {
      text: `${isBan ? "🚫" : "✅"} @${cleanJid(target)} has been *${isBan ? "banned" : "unbanned"}*!`,
      mentions: [target],
    });
  },
};
