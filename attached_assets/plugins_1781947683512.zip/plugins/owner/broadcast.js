// ============================================
// AA MD Bot - Broadcast Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getAllUsers } = require("../../lib/database");
const { sleep } = require("../../lib/utils");

module.exports = {
  command: ["broadcast", "bc"],
  description: "Broadcast a message to all users",
  category: "Owner",
  usage: ".broadcast <message>",
  ownerOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .broadcast <message>\nExample: .broadcast Hello everyone!",
      });
    }

    const message = args.join(" ");
    const users = getAllUsers();

    // Only valid @s.whatsapp.net JIDs, skip own number and banned
    const userJids = Object.keys(users).filter(
      (jid) =>
        jid &&
        jid.endsWith("@s.whatsapp.net") &&
        jid !== from &&
        !users[jid].banned
    );

    if (!userJids.length) {
      return sock.sendMessage(from, { text: "❌ No users found to broadcast to." });
    }

    await sock.sendMessage(from, {
      text: `📢 *Broadcasting to ${userJids.length} users...*\n_This may take a few minutes._`,
    });

    let success = 0;
    let failed = 0;

    for (const jid of userJids) {
      try {
        await sock.sendMessage(jid, {
          text: `📢 *Broadcast*\n\n${message}`,
        });
        success++;
        await sleep(700);
      } catch {
        failed++;
      }
    }

    await sock.sendMessage(from, {
      text: `✅ *Broadcast Complete!*\n\n📤 Sent: ${success}\n❌ Failed: ${failed}\n👥 Total: ${userJids.length}`,
    });
  },
};
