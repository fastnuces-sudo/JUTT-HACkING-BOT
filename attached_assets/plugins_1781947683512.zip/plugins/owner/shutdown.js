// ============================================
// AA MD Bot - Shutdown Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["shutdown", "stop", "off"],
  description: "Shutdown the bot",
  category: "Owner",
  usage: ".shutdown",
  ownerOnly: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;
    await sock.sendMessage(from, { text: "🛑 *Shutting down AA MD Bot...\nGoodbye!*" });
    setTimeout(() => process.exit(0), 1500);
  },
};
