// ============================================
// AA MD Bot - Steal Sticker (Add Pack Info) Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMedia } = require("../../lib/utils");
const config = require("../../config");

module.exports = {
  command: ["steal", "takesticker"],
  description: "Steal a sticker and add bot's pack info",
  category: "Media",
  usage: ".steal (reply to sticker)",

  async execute({ sock, ctx, args }) {
    const { from, quoted, message, messageType } = ctx;
    const packName = args.join(" ") || config.botName;

    let stickerMsg = null;
    if (messageType === "stickerMessage") {
      stickerMsg = message.stickerMessage;
    } else if (quoted?.message?.stickerMessage) {
      stickerMsg = quoted.message.stickerMessage;
    }

    if (!stickerMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Reply to a *sticker* with .steal",
      });
    }

    try {
      const buffer = await downloadMedia(stickerMsg, "sticker");
      await sock.sendMessage(from, {
        sticker: buffer,
        contextInfo: {
          externalAdReply: {
            title: packName,
            body: config.developer,
          },
        },
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed: ${err.message}` });
    }
  },
};
