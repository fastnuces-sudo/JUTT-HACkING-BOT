// ============================================
// AA MD Bot - Text to Speech Plugin
// Developer: Ahsan Ali | AA Mods
// Providers: Google TTS → TikTok TTS → StreamElements
// Mobile fix: converts to OGG Opus for universal WhatsApp compatibility
// ============================================

const axios = require("axios");
const fs    = require("fs");
const os    = require("os");
const path  = require("path");
const ffmpeg = require("fluent-ffmpeg");

const TIKTOK_VOICES = {
  en: "en_us_001", en_uk: "en_uk_001", en_au: "en_au_001",
  ar: "ar_001", de: "de_001", fr: "fr_001", es: "es_002",
  pt: "pt_br_001", it: "it_001", hi: "en_us_002",
  ja: "jp_001", ko: "kr_001", tr: "tr_001",
};

const SE_VOICES = {
  en: "Brian", ar: "Zeina", de: "Marlene", fr: "Celine",
  es: "Conchita", pt: "Ines", it: "Carla", nl: "Lotte",
  pl: "Ewa", sv: "Astrid", ru: "Tatyana", ja: "Mizuki",
  ko: "Seoyeon", zh: "Zhiyu",
};

const BROWSER = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
  "Accept-Language": "en-US,en;q=0.9",
  "Referer": "https://translate.google.com/",
};

// Convert any audio buffer to OGG Opus (required for PTT voice notes on WhatsApp mobile)
function convertToOpus(inputBuf) {
  return new Promise((resolve, reject) => {
    const tmpIn  = path.join(os.tmpdir(), `tts_in_${Date.now()}.mp3`);
    const tmpOut = path.join(os.tmpdir(), `tts_out_${Date.now()}.ogg`);
    fs.writeFileSync(tmpIn, inputBuf);
    ffmpeg(tmpIn)
      .audioCodec("libopus")
      .audioFrequency(48000)
      .audioChannels(1)
      .format("ogg")
      .on("end", () => {
        try {
          const buf = fs.readFileSync(tmpOut);
          fs.unlinkSync(tmpIn);
          fs.unlinkSync(tmpOut);
          resolve(buf);
        } catch (e) { reject(e); }
      })
      .on("error", (e) => {
        try { fs.unlinkSync(tmpIn); } catch {}
        try { fs.unlinkSync(tmpOut); } catch {}
        reject(e);
      })
      .save(tmpOut);
  });
}

module.exports = {
  command: ["tts", "speak", "voice"],
  description: "Convert text to speech",
  category: "Tools",
  usage: ".tts [lang] <text>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text:
          `🔊 *Text to Speech*\n\n` +
          `Usage: *.tts [lang] <text>*\n\n` +
          `Examples:\n` +
          `• *.tts en* Hello World\n` +
          `• *.tts ur* آپ کیسے ہیں\n` +
          `• *.tts hi* नमस्ते दुनिया\n` +
          `• *.tts ar* مرحبا بالعالم\n` +
          `• *.tts de* Hallo Welt\n` +
          `• *.tts fr* Bonjour le monde\n\n` +
          `🌍 Supported: en ur hi ar de fr es pt it ja ko tr zh ru`,
      });
    }

    let lang = "en";
    let text;
    if (/^[a-z]{2,5}$/i.test(args[0]) && args.length > 1) {
      lang = args[0].toLowerCase();
      text = args.slice(1).join(" ");
    } else {
      text = args.join(" ");
    }

    if (text.length > 200) {
      return sock.sendMessage(from, { text: "⚠️ Text too long. Max 200 characters." });
    }

    await sock.sendMessage(from, { text: "🔊 _Generating speech..._" });

    let rawBuf = null;

    // ── Try 1: Google Translate TTS (tw-ob client) ───────────────────
    if (!rawBuf) {
      try {
        const res = await axios.get(
          `https://translate.google.com/translate_tts` +
            `?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${lang}&client=tw-ob&ttsspeed=1`,
          { responseType: "arraybuffer", timeout: 12000, headers: BROWSER }
        );
        if (res.data && res.data.byteLength > 500) rawBuf = Buffer.from(res.data);
      } catch (e) {
        console.warn("[TTS] Google tw-ob failed:", e.message?.slice(0, 60));
      }
    }

    // ── Try 2: TikTok TTS Worker ─────────────────────────────────────
    if (!rawBuf) {
      try {
        const voice = TIKTOK_VOICES[lang] || TIKTOK_VOICES.en;
        const res = await axios.post(
          "https://tiktok-tts.weilnet.workers.dev/api/generation",
          { text, voice },
          { headers: { "Content-Type": "application/json" }, timeout: 12000 }
        );
        if (res.data?.success && res.data?.data) {
          const buf = Buffer.from(res.data.data, "base64");
          if (buf.byteLength > 500) rawBuf = buf;
        }
      } catch (e) {
        console.warn("[TTS] TikTok TTS failed:", e.message?.slice(0, 60));
      }
    }

    // ── Try 3: Google at-client ──────────────────────────────────────
    if (!rawBuf) {
      try {
        const res = await axios.get(
          `https://translate.google.com/translate_tts` +
            `?ie=UTF-8&q=${encodeURIComponent(text)}&tl=${lang}&client=at&ttsspeed=1`,
          { responseType: "arraybuffer", timeout: 12000, headers: BROWSER }
        );
        if (res.data && res.data.byteLength > 500) rawBuf = Buffer.from(res.data);
      } catch (e) {
        console.warn("[TTS] Google at-client failed:", e.message?.slice(0, 60));
      }
    }

    // ── Try 4: StreamElements ────────────────────────────────────────
    if (!rawBuf) {
      const seVoice = SE_VOICES[lang];
      if (seVoice) {
        try {
          const res = await axios.get(
            `https://api.streamelements.com/kappa/v2/speech?voice=${seVoice}&text=${encodeURIComponent(text)}`,
            { responseType: "arraybuffer", timeout: 12000, headers: { "User-Agent": "Mozilla/5.0" } }
          );
          if (res.data && res.data.byteLength > 500) rawBuf = Buffer.from(res.data);
        } catch (e) {
          console.warn("[TTS] StreamElements failed:", e.message?.slice(0, 60));
        }
      }
    }

    if (!rawBuf) {
      return sock.sendMessage(from, {
        text: "❌ *TTS temporarily unavailable.* Please try again in a moment.\n\nSupported languages: en, ur, hi, ar, de, fr, es, ja, ko",
      });
    }

    // ── Convert to OGG Opus so it plays on WhatsApp mobile as a voice note ──
    try {
      const opusBuf = await convertToOpus(rawBuf);
      return await sock.sendMessage(from, {
        audio: opusBuf,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
      });
    } catch (e) {
      console.warn("[TTS] ffmpeg conversion failed, sending as MP3:", e.message?.slice(0, 60));
      // Fallback: send as plain audio file (no PTT) — plays on both mobile & desktop
      return await sock.sendMessage(from, {
        audio: rawBuf,
        mimetype: "audio/mpeg",
        ptt: false,
      });
    }
  },
};
