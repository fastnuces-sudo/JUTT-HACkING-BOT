// ============================================
// AA MD Bot - Font Changer Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["font", "fonts"],
  description: "Change text to different Unicode fonts",
  category: "Tools",
  usage: ".font <number> <text>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: `⚠️ Usage: .font <number> <text>\n\nAvailable Fonts:\n1. 𝗕𝗼𝗹𝗱\n2. 𝘐𝘵𝘢𝘭𝘪𝘤\n3. 𝔉𝔯𝔞𝔨𝔱𝔲𝔯\n4. 𝒮𝒸𝓇𝒾𝓅𝓉\n5. ＦＵＬＬＷＩＤＴＨ\n6. Ｓᴍᴀʟʟ ᴄᴀᴘꜱ`,
      });
    }

    const num = parseInt(args[0]);
    if (isNaN(num)) {
      return sock.sendMessage(from, { text: "⚠️ Please provide a font number (1-6)." });
    }

    const text = args.slice(1).join(" ");
    if (!text) {
      return sock.sendMessage(from, { text: "⚠️ Please provide text after the font number." });
    }

    const fontFunctions = [
      (t) => convertFont(t, "bold"),
      (t) => convertFont(t, "italic"),
      (t) => convertFont(t, "fraktur"),
      (t) => convertFont(t, "script"),
      (t) => fullwidth(t),
      (t) => smallcaps(t),
    ];

    if (num < 1 || num > fontFunctions.length) {
      return sock.sendMessage(from, { text: `⚠️ Font number must be 1-${fontFunctions.length}` });
    }

    const converted = fontFunctions[num - 1](text);
    await sock.sendMessage(from, { text: `✨ Font #${num}:\n\n${converted}` });
  },
};

const FONTS = {
  bold: "𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭",
  italic: "𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡",
  fraktur: "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ",
  script: "𝒶𝒷𝒸𝒹𝑒𝒻𝑔𝒽𝒾𝒿𝓀𝓁𝓂𝓃𝑜𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏𝒜𝐵𝒞𝒟𝐸𝐹𝒢𝐻𝐼𝒥𝒦𝐿𝑀𝒩𝒪𝒫𝒬𝑅𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵",
};

function convertFont(text, fontName) {
  const map = FONTS[fontName].split("");
  const alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  return [...text].map((c) => {
    const i = alpha.indexOf(c);
    return i >= 0 ? map[i] : c;
  }).join("");
}

function fullwidth(text) {
  return [...text].map((c) => {
    const code = c.charCodeAt(0);
    if (code >= 33 && code <= 126) return String.fromCharCode(code + 0xFEE0);
    if (c === " ") return "　";
    return c;
  }).join("");
}

function smallcaps(text) {
  const m = { a:"ᴀ",b:"ʙ",c:"ᴄ",d:"ᴅ",e:"ᴇ",f:"ꜰ",g:"ɢ",h:"ʜ",i:"ɪ",j:"ᴊ",k:"ᴋ",l:"ʟ",m:"ᴍ",n:"ɴ",o:"ᴏ",p:"ᴘ",q:"Q",r:"ʀ",s:"s",t:"ᴛ",u:"ᴜ",v:"ᴠ",w:"ᴡ",x:"x",y:"ʏ",z:"ᴢ" };
  return [...text.toLowerCase()].map((c) => m[c] || c).join("");
}
