// ============================================
// AA MD Bot - Read More / Fake Blur Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["readmore", "fake"],
  description: "Create a 'read more' message with hidden text",
  category: "Tools",
  usage: ".readmore <visible text>\n<hidden text>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    const full = args.join(" ");
    const parts = full.split("|");

    if (parts.length < 2) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .readmore <visible> | <hidden>\nExample: .readmore Hello World! | This is the hidden part",
      });
    }

    const visible = parts[0].trim();
    const hidden = parts[1].trim();

    // Use invisible characters to push hidden text below fold
    const invisible = "\u200B".repeat(1500);

    await sock.sendMessage(from, {
      text: `${visible}${invisible}${hidden}`,
    });
  },
};
