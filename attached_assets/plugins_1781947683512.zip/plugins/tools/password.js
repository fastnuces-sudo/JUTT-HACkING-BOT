// ============================================
// AA MD Bot - Password Generator Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["password", "passgen", "genpass"],
  description: "Generate a secure random password",
  category: "Tools",
  usage: ".password [length]",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    const length = Math.min(64, Math.max(8, parseInt(args[0]) || 16));
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?";
    let password = "";

    for (let i = 0; i < length; i++) {
      password += charset[Math.floor(Math.random() * charset.length)];
    }

    // Ensure it has at least one of each type
    const hasUpper = /[A-Z]/.test(password);
    const hasLower = /[a-z]/.test(password);
    const hasNum = /[0-9]/.test(password);
    const hasSpecial = /[!@#$%^&*]/.test(password);
    const strength = [hasUpper, hasLower, hasNum, hasSpecial].filter(Boolean).length;
    const strengthLabel = ["Weak", "Fair", "Good", "Strong"][strength - 1] || "Strong";

    await sock.sendMessage(from, {
      text: `🔑 *Generated Password*\n\n\`${password}\`\n\n` +
        `📏 Length: ${length}\n` +
        `💪 Strength: ${strengthLabel} ${"⭐".repeat(strength)}\n\n` +
        `_⚠️ Save this password securely!_`,
    });
  },
};
