// ============================================
// AA MD Bot - Base64 Encode/Decode Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["base64", "b64encode", "b64decode"],
  description: "Encode or decode Base64",
  category: "Tools",
  usage: ".base64 encode <text> | .base64 decode <base64>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (args.length < 2) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage:\n• .base64 encode <text>\n• .base64 decode <base64string>",
      });
    }

    const action = args[0].toLowerCase();
    const input = args.slice(1).join(" ");

    try {
      if (action === "encode") {
        const encoded = Buffer.from(input, "utf-8").toString("base64");
        await sock.sendMessage(from, {
          text: `✅ *Base64 Encoded:*\n\n\`\`\`${encoded}\`\`\``,
        });
      } else if (action === "decode") {
        const decoded = Buffer.from(input, "base64").toString("utf-8");
        await sock.sendMessage(from, {
          text: `✅ *Base64 Decoded:*\n\n${decoded}`,
        });
      } else {
        await sock.sendMessage(from, { text: "❌ Invalid action. Use: encode or decode" });
      }
    } catch {
      await sock.sendMessage(from, { text: "❌ Invalid input for base64 operation." });
    }
  },
};
