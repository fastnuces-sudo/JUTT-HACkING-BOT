// ============================================
// AA MD Bot - File Uploader Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMedia } = require("../../lib/utils");
const axios = require("axios");
const FormData = require("form-data");

module.exports = {
  command: ["upload", "fileupload"],
  description: "Upload a file and get a direct link",
  category: "Tools",
  usage: ".upload (reply to any file/image/video)",
  cooldown: 10000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let mediaMsg = null;
    let mediaType = null;
    let ext = "bin";

    const typeMap = {
      imageMessage: { type: "image", ext: "jpg" },
      videoMessage: { type: "video", ext: "mp4" },
      audioMessage: { type: "audio", ext: "mp3" },
      documentMessage: { type: "document", ext: "bin" },
      stickerMessage: { type: "sticker", ext: "webp" },
    };

    const msgType = messageType;
    if (typeMap[msgType]) {
      mediaMsg = message[msgType];
      mediaType = typeMap[msgType].type;
      ext = typeMap[msgType].ext;
    } else if (quoted) {
      const qType = Object.keys(quoted.message)[0];
      if (typeMap[qType]) {
        mediaMsg = quoted.message[qType];
        mediaType = typeMap[qType].type;
        ext = typeMap[qType].ext;
      }
    }

    if (!mediaMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Please send or reply to a file with .upload",
      });
    }

    await sock.sendMessage(from, { text: "⬆️ Uploading file..." });

    try {
      const buffer = await downloadMedia(mediaMsg, mediaType);
      const form = new FormData();
      form.append("file", buffer, { filename: `upload.${ext}` });

      // Using catbox.moe free file hosting
      const res = await axios.post("https://catbox.moe/user/api.php", form, {
        headers: {
          ...form.getHeaders(),
          reqtype: "fileupload",
        },
        timeout: 30000,
      });

      const url = res.data;
      if (!url.startsWith("https://")) {
        throw new Error("Upload failed: " + url);
      }

      await sock.sendMessage(from, {
        text: `✅ *File Uploaded!*\n\n🔗 ${url}\n\n_Powered by catbox.moe_`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Upload failed: ${err.message}` });
    }
  },
};
