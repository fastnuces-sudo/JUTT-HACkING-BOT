// ============================================
// AA MD Bot - Text Style Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["textstyle", "style", "stylish"],
  description: "Convert text to stylish Unicode fonts",
  category: "Tools",
  usage: ".textstyle <text>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .textstyle <text>" });
    }

    const text = args.join(" ");

    const styles = {
      "𝗕𝗼𝗹𝗱": boldify(text),
      "𝘐𝘵𝘢𝘭𝘪𝘤": italicify(text),
      "𝑺𝒄𝒓𝒊𝒑𝒕": scriptify(text),
      "𝔉𝔯𝔞𝔨𝔱𝔲𝔯": frakturify(text),
      "ＷＩＤＥ": wideify(text),
      "ᴢᴇɴɪᴛʜ sᴍᴀʟʟ": smallcapsify(text),
      "uʍop-ǝpısdn": flipify(text),
    };

    let reply = `✨ *Text Styles for:* "${text}"\n\n`;
    for (const [name, styled] of Object.entries(styles)) {
      reply += `${name}:\n${styled}\n\n`;
    }

    await sock.sendMessage(from, { text: reply });
  },
};

function boldify(t) {
  const map = "𝗮𝗯𝗰𝗱𝗲𝗳𝗴𝗵𝗶𝗷𝗸𝗹𝗺𝗻𝗼𝗽𝗾𝗿𝘀𝘁𝘂𝘃𝘄𝘅𝘆𝘇𝗔𝗕𝗖𝗗𝗘𝗙𝗚𝗛𝗜𝗝𝗞𝗟𝗠𝗡𝗢𝗣𝗤𝗥𝗦𝗧𝗨𝗩𝗪𝗫𝗬𝗭".split("");
  return [...t].map((c) => {
    const i = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(c);
    return i >= 0 ? map[i] : c;
  }).join("");
}

function italicify(t) {
  const map = "𝘢𝘣𝘤𝘥𝘦𝘧𝘨𝘩𝘪𝘫𝘬𝘭𝘮𝘯𝘰𝘱𝘲𝘳𝘴𝘵𝘶𝘷𝘸𝘹𝘺𝘻𝘈𝘉𝘊𝘋𝘌𝘍𝘎𝘏𝘐𝘑𝘒𝘓𝘔𝘕𝘖𝘗𝘘𝘙𝘚𝘛𝘜𝘝𝘞𝘟𝘠𝘡".split("");
  return [...t].map((c) => {
    const i = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(c);
    return i >= 0 ? map[i] : c;
  }).join("");
}

function scriptify(t) {
  const map = "𝒶𝒷𝒸𝒹𝑒𝒻𝑔𝒽𝒾𝒿𝓀𝓁𝓂𝓃𝑜𝓅𝓆𝓇𝓈𝓉𝓊𝓋𝓌𝓍𝓎𝓏𝒜𝐵𝒞𝒟𝐸𝐹𝒢𝐻𝐼𝒥𝒦𝐿𝑀𝒩𝒪𝒫𝒬𝑅𝒮𝒯𝒰𝒱𝒲𝒳𝒴𝒵".split("");
  return [...t].map((c) => {
    const i = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(c);
    return i >= 0 ? map[i] : c;
  }).join("");
}

function frakturify(t) {
  const map = "𝔞𝔟𝔠𝔡𝔢𝔣𝔤𝔥𝔦𝔧𝔨𝔩𝔪𝔫𝔬𝔭𝔮𝔯𝔰𝔱𝔲𝔳𝔴𝔵𝔶𝔷𝔄𝔅ℭ𝔇𝔈𝔉𝔊ℌℑ𝔍𝔎𝔏𝔐𝔑𝔒𝔓𝔔ℜ𝔖𝔗𝔘𝔙𝔚𝔛𝔜ℨ".split("");
  return [...t].map((c) => {
    const i = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(c);
    return i >= 0 ? map[i] : c;
  }).join("");
}

function wideify(t) {
  return [...t].map((c) => {
    const code = c.charCodeAt(0);
    if (code >= 33 && code <= 126) return String.fromCharCode(code + 0xFEE0);
    if (c === " ") return "　";
    return c;
  }).join("");
}

function smallcapsify(t) {
  const map = { a:"ᴀ",b:"ʙ",c:"ᴄ",d:"ᴅ",e:"ᴇ",f:"ꜰ",g:"ɢ",h:"ʜ",i:"ɪ",j:"ᴊ",k:"ᴋ",l:"ʟ",m:"ᴍ",n:"ɴ",o:"ᴏ",p:"ᴘ",q:"Q",r:"ʀ",s:"s",t:"ᴛ",u:"ᴜ",v:"ᴠ",w:"ᴡ",x:"x",y:"ʏ",z:"ᴢ" };
  return [...t.toLowerCase()].map((c) => map[c] || c).join("");
}

function flipify(t) {
  const flip = { a:"ɐ",b:"q",c:"ɔ",d:"p",e:"ǝ",f:"ɟ",g:"ƃ",h:"ɥ",i:"ᴉ",j:"ɾ",k:"ʞ",l:"l",m:"ɯ",n:"u",o:"o",p:"d",q:"b",r:"ɹ",s:"s",t:"ʇ",u:"n",v:"ʌ",w:"ʍ",x:"x",y:"ʎ",z:"z" };
  return [...t.toLowerCase()].reverse().map((c) => flip[c] || c).join("");
}
