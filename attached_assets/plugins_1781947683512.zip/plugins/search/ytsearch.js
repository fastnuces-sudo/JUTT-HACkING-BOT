// ============================================
// AA MD Bot - YouTube Search Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const YouTube = require("youtube-sr").default;
const axios = require("axios");
const config = require("../../config");

module.exports = {
  command: ["ytsearch", "ytfind", "searchyt"],
  description: "Search YouTube for videos",
  category: "Search",
  usage: ".ytsearch <query>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .ytsearch <query>\nExample: .ytsearch Naruto OST",
      });
    }

    const query = args.join(" ");
    await sock.sendMessage(from, { text: `🎬 Searching YouTube for *${query}*...` });

    try {
      if (config.apiKeys.youtubeApi) {
        // Use YouTube Data API v3 if key is set
        const res = await axios.get("https://www.googleapis.com/youtube/v3/search", {
          params: {
            q: query,
            part: "snippet",
            maxResults: 5,
            type: "video",
            key: config.apiKeys.youtubeApi,
          },
          timeout: 10000,
        });

        const items = res.data.items;
        if (!items || items.length === 0) {
          return sock.sendMessage(from, { text: "❌ No results found." });
        }

        let text = `🎬 *YouTube Results: ${query}*\n\n`;
        items.forEach((item, i) => {
          const title = item.snippet.title;
          const channel = item.snippet.channelTitle;
          const url = `https://youtu.be/${item.id.videoId}`;
          text += `${i + 1}. *${title}*\n👤 ${channel}\n🔗 ${url}\n\n`;
        });

        await sock.sendMessage(from, { text: text.trim() });
      } else {
        // Fallback: youtube-sr scraper (no API key needed)
        const results = await YouTube.search(query, { limit: 5, type: "video" });

        if (!results || results.length === 0) {
          return sock.sendMessage(from, { text: "❌ No results found." });
        }

        let text = `🎬 *YouTube Results: ${query}*\n\n`;
        results.forEach((video, i) => {
          const dur = video.duration
            ? `${Math.floor(video.duration / 60000)}:${String(Math.floor((video.duration % 60000) / 1000)).padStart(2, "0")}`
            : "?:??";
          const views = video.views
            ? video.views >= 1e6
              ? (video.views / 1e6).toFixed(1) + "M"
              : video.views >= 1e3
              ? (video.views / 1e3).toFixed(1) + "K"
              : String(video.views)
            : "?";
          text += `${i + 1}. *${video.title}*\n👤 ${video.channel?.name || "?"} | ⏱️ ${dur} | 👁️ ${views}\n🔗 https://youtu.be/${video.id}\n\n`;
        });

        await sock.sendMessage(from, { text: text.trim() });
      }
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Search failed: ${err.message}` });
    }
  },
};
