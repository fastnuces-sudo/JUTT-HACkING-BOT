// ============================================
// AA MD Bot - Image Search Plugin
// Developer: Ahsan Ali | AA Mods
// Bing Images (scrape) + Unsplash fallback
// ============================================

const axios = require("axios");

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

// Bing image search — parse image URLs from HTML
async function bingImageSearch(query) {
  const res = await axios.get(
    `https://www.bing.com/images/search?q=${encodeURIComponent(query)}&form=HDRSC2&first=1&count=10`,
    {
      timeout: 15000,
      headers: { "User-Agent": UA, Accept: "text/html", "Accept-Language": "en-US,en;q=0.9" },
    }
  );
  const html = res.data;
  const matches = [];

  // Bing encodes URLs as &quot; in HTML: murl&quot;:&quot;URL&quot;
  const murlReg = /murl&quot;:&quot;(https?:[^&]+)&quot;/g;
  let m;
  while ((m = murlReg.exec(html)) !== null) {
    const u = decodeURIComponent(m[1]);
    if (u.match(/\.(jpg|jpeg|png|webp)/i) && u.startsWith("http")) matches.push(u);
    if (matches.length >= 8) break;
  }

  // Fallback: try unquoted format
  if (!matches.length) {
    const alt = /"murl":"(https?:[^"\\]+)"/g;
    while ((m = alt.exec(html)) !== null) {
      if (m[1].startsWith("http")) matches.push(m[1]);
      if (matches.length >= 8) break;
    }
  }

  return matches;
}

// Fetch an image buffer from URL with timeout
async function fetchImage(url, timeout = 12000) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout,
    headers: { "User-Agent": UA },
    maxRedirects: 5,
  });
  return Buffer.from(res.data);
}

module.exports = {
  command: ["img", "image", "imgsearch"],
  description: "Search for images",
  category: "Search",
  usage: ".img <query>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .img <query>\nExample: .img Pakistan mountain",
      });
    }

    const query = args.join(" ");
    await sock.sendMessage(from, { text: `🖼️ Searching image for *${query}*...` });

    // ── Try 1: Bing Images (real, relevant images) ────────────────
    try {
      const urls = await bingImageSearch(query);
      for (const imgUrl of urls.slice(0, 5)) {
        try {
          const buf = await fetchImage(imgUrl);
          if (buf.length > 3000) {
            return await sock.sendMessage(from, {
              image: buf,
              caption: `🖼️ *${query}*\n_AA MD Bot_`,
            });
          }
        } catch (_) {}
      }
    } catch (e) {
      console.warn("[ImgSearch] Bing failed:", e.message.slice(0, 60));
    }

    // ── Try 2: Unsplash Source (nature/general) ───────────────────
    try {
      const buf = await fetchImage(
        `https://source.unsplash.com/1280x720/?${encodeURIComponent(query)}`,
        20000
      );
      if (buf.length > 5000) {
        return await sock.sendMessage(from, {
          image: buf,
          caption: `🖼️ *${query}*\n_AA MD Bot_`,
        });
      }
    } catch (_) {}

    // ── Try 3: Picsum (always works, random) ─────────────────────
    try {
      const seed = query.replace(/\s+/g, "-").toLowerCase();
      const buf = await fetchImage(`https://picsum.photos/seed/${seed}/1280/720`, 15000);
      if (buf.length > 1000) {
        return await sock.sendMessage(from, {
          image: buf,
          caption: `🖼️ *${query}*\n_AA MD Bot_`,
        });
      }
    } catch (_) {}

    await sock.sendMessage(from, {
      text: `❌ Image search failed for: *${query}*\n\nTry a different keyword.`,
    });
  },
};
