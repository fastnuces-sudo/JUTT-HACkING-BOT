// ============================================
// AA MD Bot - Wikipedia Search Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const axios = require("axios");

const WIKI_HEADERS = {
  "User-Agent": "Mozilla/5.0 (compatible; AAMDBot/2.0; +https://github.com)",
  Accept: "application/json",
};

module.exports = {
  command: ["wiki", "wikipedia", "define"],
  description: "Search Wikipedia for information",
  category: "Search",
  usage: ".wiki <topic>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .wiki <topic>\nExample: .wiki Artificial Intelligence",
      });
    }

    const query = args.join(" ");
    await sock.sendMessage(from, { text: `🔍 Searching Wikipedia for *${query}*...` });

    // ── Try 1: Direct summary by title ───────────────────────────
    try {
      const res = await axios.get(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`,
        { timeout: 12000, headers: WIKI_HEADERS }
      );
      const data = res.data;
      if (data.type === "disambiguation") {
        return sock.sendMessage(from, {
          text: `📚 *${data.title}* has multiple meanings. Please be more specific.\n\n${data.extract || ""}`,
        });
      }
      if (data.extract) {
        const text =
          `📖 *${data.title}*\n\n${data.extract.slice(0, 600)}${data.extract.length > 600 ? "..." : ""}\n\n🔗 ${data.content_urls?.desktop?.page || ""}`;
        if (data.thumbnail?.source) {
          return sock.sendMessage(from, {
            image: { url: data.thumbnail.source },
            caption: text,
          });
        }
        return sock.sendMessage(from, { text });
      }
    } catch (_) {}

    // ── Try 2: Wikipedia OpenSearch (find matching article) ───────
    try {
      const search = await axios.get(
        `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(query)}&limit=1&format=json`,
        { timeout: 12000, headers: WIKI_HEADERS }
      );
      const [, titles,, urls] = search.data;
      if (titles?.[0]) {
        const summaryRes = await axios.get(
          `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(titles[0])}`,
          { timeout: 12000, headers: WIKI_HEADERS }
        );
        const data = summaryRes.data;
        if (data.extract) {
          const text =
            `📖 *${data.title}*\n\n${data.extract.slice(0, 600)}${data.extract.length > 600 ? "..." : ""}\n\n🔗 ${urls?.[0] || ""}`;
          if (data.thumbnail?.source) {
            return sock.sendMessage(from, {
              image: { url: data.thumbnail.source },
              caption: text,
            });
          }
          return sock.sendMessage(from, { text });
        }
      }
    } catch (_) {}

    await sock.sendMessage(from, {
      text:
        `❌ No Wikipedia article found for: *${query}*\n\n` +
        `🔗 Search manually: https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(query)}`,
    });
  },
};
