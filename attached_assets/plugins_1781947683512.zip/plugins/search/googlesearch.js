// ============================================
// AA MD Bot - Web Search Plugin
// Developer: Ahsan Ali | AA Mods
// DuckDuckGo Instant + HTML + Wikipedia
// ============================================

const axios = require("axios");

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

// ── DuckDuckGo HTML scraper ───────────────────────────────────────
async function ddgHtmlSearch(query) {
  const res = await axios.get(
    `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
    {
      timeout: 15000,
      headers: { "User-Agent": UA, Accept: "text/html", "Accept-Language": "en-US,en;q=0.9" },
    }
  );
  const html = res.data;
  const results = [];

  const blocks = html.match(/<div class="result[^"]*"[\s\S]*?<\/div>\s*<\/div>/g) || [];
  for (const block of blocks.slice(0, 5)) {
    const titleMatch = block.match(/class="result__a"[^>]*>([^<]+)<\/a>/);
    const snippetMatch = block.match(/class="result__snippet"[^>]*>([\s\S]*?)<\/a>/);
    const urlMatch = block.match(/class="result__url"[^>]*>\s*(https?:\/\/[^\s<]+)/);

    const title   = titleMatch   ? titleMatch[1].trim()   : "";
    const snippet = snippetMatch ? snippetMatch[1].replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&quot;/g, '"').trim() : "";
    const url     = urlMatch     ? urlMatch[1].trim()     : "";

    if (snippet && snippet.length > 15) {
      results.push({ title, snippet, url });
    }
  }

  return results;
}

// ── Wikipedia summary (great for factual queries) ─────────────────
async function wikiSearch(query) {
  const searchRes = await axios.get(
    `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query.replace(/\s+/g, "_"))}`,
    { timeout: 10000, headers: { "User-Agent": UA } }
  );
  const d = searchRes.data;
  if (d.extract && d.extract.length > 30) {
    return {
      title: d.title,
      summary: d.extract.slice(0, 500) + (d.extract.length > 500 ? "…" : ""),
      url: d.content_urls?.desktop?.page || "",
    };
  }
  return null;
}

module.exports = {
  command: ["google", "search", "g", "web"],
  description: "Search the web",
  category: "Search",
  usage: ".google <query>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .google <query>\nExample: .google Pakistan population 2024",
      });
    }

    const query = args.join(" ");
    await sock.sendMessage(from, { text: `🔍 Searching: *${query}*...` });

    let text = `🔍 *${query}*\n\n`;
    let hasContent = false;

    // ── Step 1: DuckDuckGo Instant Answer ────────────────────────
    try {
      const res = await axios.get(
        `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`,
        { timeout: 10000, headers: { "User-Agent": UA } }
      );
      const d = res.data;

      if (d.Answer) {
        text += `💡 *Quick Answer:*\n${d.Answer}\n\n`;
        hasContent = true;
      }
      if (d.AbstractText && d.AbstractText.length > 30) {
        text += `📝 *Summary:*\n${d.AbstractText.slice(0, 450)}${d.AbstractText.length > 450 ? "…" : ""}\n`;
        if (d.AbstractSource) text += `📌 _Source: ${d.AbstractSource}_\n`;
        if (d.AbstractURL)    text += `🔗 ${d.AbstractURL}\n`;
        text += "\n";
        hasContent = true;
      }
      if (d.Definition && d.Definition.length > 10) {
        text += `📖 *Definition:*\n${d.Definition}\n`;
        if (d.DefinitionSource) text += `📌 _${d.DefinitionSource}_\n`;
        text += "\n";
        hasContent = true;
      }
      if (!hasContent && d.RelatedTopics?.length) {
        const t = d.RelatedTopics[0];
        const excerpt = (t.Text || "").slice(0, 300);
        if (excerpt.length > 20) {
          text += `📝 *Related:*\n${excerpt}\n\n`;
          hasContent = true;
        }
      }
    } catch (_) {}

    // ── Step 2: Wikipedia (if no instant answer) ──────────────────
    if (!hasContent) {
      try {
        const wiki = await wikiSearch(query);
        if (wiki) {
          text += `📚 *${wiki.title}* _(Wikipedia)_\n\n${wiki.summary}\n`;
          if (wiki.url) text += `\n🔗 ${wiki.url}\n`;
          text += "\n";
          hasContent = true;
        }
      } catch (_) {}
    }

    // ── Step 3: DDG HTML search results ──────────────────────────
    if (!hasContent) {
      try {
        const results = await ddgHtmlSearch(query);
        if (results.length > 0) {
          text += `📌 *Top Results:*\n\n`;
          for (const r of results.slice(0, 4)) {
            if (r.title) text += `*${r.title}*\n`;
            text += `${r.snippet.slice(0, 180)}\n`;
            if (r.url) text += `🔗 ${r.url}\n`;
            text += "\n";
          }
          hasContent = true;
        }
      } catch (_) {}
    }

    // ── Fallback: search links ────────────────────────────────────
    if (!hasContent) {
      text +=
        `No instant result found. Try:\n\n` +
        `🔍 DuckDuckGo: https://duckduckgo.com/?q=${encodeURIComponent(query)}\n` +
        `🌐 Google: https://www.google.com/search?q=${encodeURIComponent(query)}\n` +
        `📚 Wikipedia: https://en.wikipedia.org/wiki/${encodeURIComponent(query.replace(/\s+/g, "_"))}`;
    }

    text += `\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n🤖 _AA MD Bot by Ahsan Ali_`;

    await sock.sendMessage(from, { text: text.trim() });
  },
};
