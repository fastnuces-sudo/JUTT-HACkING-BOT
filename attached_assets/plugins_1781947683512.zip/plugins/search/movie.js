// ============================================
// AA MD Bot - Movie/Show Search Plugin
// Developer: Ahsan Ali | AA Mods
// Uses TVMaze (free, no key) + YTS for movies
// ============================================

const axios = require("axios");

module.exports = {
  command: ["movie", "film", "imdb"],
  description: "Search for movie/show information",
  category: "Search",
  usage: ".movie <title>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .movie <title>\nExample: .movie Inception",
      });
    }

    const title = args.join(" ");
    await sock.sendMessage(from, { text: `🎬 Searching for: *${title}*...` });

    // ── Try 1: TVMaze — TV shows (free, no key) ──────────────────
    try {
      const res = await axios.get(
        `https://api.tvmaze.com/singlesearch/shows?q=${encodeURIComponent(title)}`,
        { timeout: 10000 }
      );
      const s = res.data;
      if (s && s.name) {
        const summary = s.summary ? s.summary.replace(/<[^>]*>/g, "").slice(0, 300) : "N/A";
        const text =
          `📺 *${s.name}*\n\n` +
          `🎭 *Type:* TV Show\n` +
          `⭐ *Rating:* ${s.rating?.average || "N/A"}/10\n` +
          `📅 *Premiered:* ${s.premiered || "N/A"}\n` +
          `🌐 *Language:* ${s.language || "N/A"}\n` +
          `🏷️ *Genres:* ${s.genres?.join(", ") || "N/A"}\n` +
          `📊 *Status:* ${s.status || "N/A"}\n\n` +
          `📝 *Summary:*\n${summary}`;

        if (s.image?.medium) {
          return sock.sendMessage(from, {
            image: { url: s.image.medium },
            caption: text,
          });
        }
        return sock.sendMessage(from, { text });
      }
    } catch (_) {}

    // ── Try 2: YTS — Movies (free, no key) ───────────────────────
    try {
      const res = await axios.get(
        `https://yts.mx/api/v2/list_movies.json?query_term=${encodeURIComponent(title)}&limit=1`,
        { timeout: 10000 }
      );
      const movie = res.data?.data?.movies?.[0];
      if (movie) {
        const genres = movie.genres?.join(", ") || "N/A";
        const text =
          `🎬 *${movie.title}* (${movie.year})\n\n` +
          `⭐ *Rating:* ${movie.rating}/10\n` +
          `🎭 *Genre:* ${genres}\n` +
          `⏱️ *Runtime:* ${movie.runtime} min\n` +
          `🌍 *Language:* ${movie.language?.toUpperCase() || "N/A"}\n\n` +
          `📝 *Summary:*\n${movie.description_full?.slice(0, 350) || "N/A"}\n\n` +
          `🔗 *YTS:* ${movie.url}`;

        if (movie.large_cover_image) {
          return sock.sendMessage(from, {
            image: { url: movie.large_cover_image },
            caption: text,
          });
        }
        return sock.sendMessage(from, { text });
      }
    } catch (_) {}

    // ── Try 3: TVMaze search (multiple results) ───────────────────
    try {
      const res = await axios.get(
        `https://api.tvmaze.com/search/shows?q=${encodeURIComponent(title)}`,
        { timeout: 10000 }
      );
      const results = res.data;
      if (results && results.length > 0) {
        const s = results[0].show;
        const summary = s.summary ? s.summary.replace(/<[^>]*>/g, "").slice(0, 300) : "N/A";
        const text =
          `📺 *${s.name}*\n\n` +
          `⭐ *Rating:* ${s.rating?.average || "N/A"}/10\n` +
          `📅 *Premiered:* ${s.premiered || "N/A"}\n` +
          `🌐 *Language:* ${s.language || "N/A"}\n` +
          `🏷️ *Genres:* ${s.genres?.join(", ") || "N/A"}\n\n` +
          `📝 *Summary:*\n${summary}`;

        if (s.image?.medium) {
          return sock.sendMessage(from, {
            image: { url: s.image.medium },
            caption: text,
          });
        }
        return sock.sendMessage(from, { text });
      }
    } catch (_) {}

    await sock.sendMessage(from, {
      text: `❌ No results found for: *${title}*\n\nTry searching on:\n🔗 https://www.imdb.com/find?q=${encodeURIComponent(title)}`,
    });
  },
};
