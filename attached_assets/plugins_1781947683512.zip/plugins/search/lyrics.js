// ============================================
// AA MD Bot - Lyrics Search Plugin
// Developer: Ahsan Ali | AA Mods
// lrclib.net (primary, free) + ovh fallback
// ============================================

const axios = require("axios");

async function fetchFromLrclib(artist, title) {
  // Search with both artist + title
  const res = await axios.get(
    `https://lrclib.net/api/search?track_name=${encodeURIComponent(title)}&artist_name=${encodeURIComponent(artist)}`,
    { timeout: 12000, headers: { "User-Agent": "Mozilla/5.0" } }
  );
  const items = res.data;
  if (Array.isArray(items) && items.length > 0) {
    const hit = items.find((i) => i.plainLyrics) || items[0];
    if (hit?.plainLyrics) return { lyrics: hit.plainLyrics, title: hit.trackName || title, artist: hit.artistName || artist };
  }
  return null;
}

async function fetchFromLrclibQuery(query) {
  const res = await axios.get(
    `https://lrclib.net/api/search?q=${encodeURIComponent(query)}`,
    { timeout: 12000, headers: { "User-Agent": "Mozilla/5.0" } }
  );
  const items = res.data;
  if (Array.isArray(items) && items.length > 0) {
    const hit = items.find((i) => i.plainLyrics) || items[0];
    if (hit?.plainLyrics) return { lyrics: hit.plainLyrics, title: hit.trackName || query, artist: hit.artistName || "Unknown" };
  }
  return null;
}

async function fetchFromOvh(artist, title) {
  const res = await axios.get(
    `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`,
    { timeout: 15000, headers: { "User-Agent": "Mozilla/5.0" } }
  );
  if (res.data?.lyrics) return { lyrics: res.data.lyrics, title, artist };
  return null;
}

module.exports = {
  command: ["lyrics", "lyric"],
  description: "Search for song lyrics",
  category: "Search",
  usage: ".lyrics <song name>  OR  .lyrics <artist> - <song>",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage:\n• .lyrics Shape of You\n• .lyrics Ed Sheeran - Shape of You",
      });
    }

    const full = args.join(" ");
    const hasDash = full.includes(" - ");
    const artist = hasDash ? full.split(" - ")[0].trim() : "";
    const title = hasDash ? full.split(" - ").slice(1).join(" - ").trim() : full.trim();

    await sock.sendMessage(from, {
      text: `🎵 Searching lyrics for *${hasDash ? `${title} by ${artist}` : title}*...`,
    });

    let result = null;

    // ── Try 1: lrclib.net (best free lyrics database) ────────────
    try {
      if (hasDash) {
        result = await fetchFromLrclib(artist, title);
      }
      if (!result) {
        result = await fetchFromLrclibQuery(full);
      }
    } catch (e) {
      console.warn("[Lyrics] lrclib failed:", e.message.slice(0, 60));
    }

    // ── Try 2: lyrics.ovh (good for English songs) ───────────────
    if (!result && hasDash) {
      try {
        result = await fetchFromOvh(artist, title);
      } catch (_) {}
    }
    if (!result) {
      try {
        const query = hasDash ? title : full;
        result = await fetchFromOvh("", query).catch(() => null);
      } catch (_) {}
    }

    if (!result) {
      return sock.sendMessage(from, {
        text:
          `❌ Lyrics not found for: *${full}*\n\n` +
          `Tips:\n• .lyrics Shape of You\n• .lyrics Ed Sheeran - Shape of You`,
      });
    }

    const { lyrics, title: foundTitle, artist: foundArtist } = result;
    const maxLen = 3800;
    const trimmed = lyrics.length > maxLen
      ? lyrics.slice(0, maxLen) + "\n\n... _(lyrics trimmed)_"
      : lyrics;

    await sock.sendMessage(from, {
      text: `🎵 *${foundTitle}*\n👤 *${foundArtist}*\n\n${trimmed}\n\n_AA MD Bot_`,
    });
  },
};
