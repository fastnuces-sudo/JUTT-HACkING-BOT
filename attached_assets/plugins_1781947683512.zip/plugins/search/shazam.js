// ============================================
// AA MD Bot - Shazam Song Identifier Plugin
// Developer: Ahsan Ali | AA Mods
// Uses audd.io free API
// ============================================

const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs-extra");
const path = require("path");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const { TEMP_DIR, cleanup } = require("../../lib/ytdlp");

module.exports = {
  command: ["shazam", "identify", "songid"],
  description: "Identify a song from a replied audio or video message",
  category: "Search",
  usage: ".shazam (reply to an audio/video)",
  cooldown: 20000,

  async execute({ sock, ctx }) {
    const { from, quoted, msg } = ctx;

    // Get the quoted message from ctx (properly parsed by handler)
    const quotedMsg = quoted?.message;
    if (!quotedMsg) {
      return sock.sendMessage(from, {
        text: "🎵 Reply to an *audio* or *video* message with .shazam to identify the song.",
      });
    }

    const msgType = quoted.type;
    if (!["audioMessage", "videoMessage"].includes(msgType)) {
      return sock.sendMessage(from, {
        text: "❌ Please reply to an *audio* or *video* message.",
      });
    }

    await sock.sendMessage(from, { text: "🎧 Identifying song... Please wait ⏳" });

    let tmpFile = null;
    try {
      // Download the audio/video content
      const stream = await downloadContentFromMessage(
        quotedMsg[msgType],
        msgType.replace("Message", "")
      );

      let buffer = Buffer.alloc(0);
      for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
      }

      tmpFile = path.join(TEMP_DIR, `shazam_${Date.now()}.ogg`);
      fs.writeFileSync(tmpFile, buffer);

      // Use Node.js form-data (NOT browser FormData)
      const form = new FormData();
      form.append("return", "apple_music,spotify");
      form.append("api_token", "test");
      form.append("file", fs.createReadStream(tmpFile), {
        filename: "audio.ogg",
        contentType: "audio/ogg",
      });

      const res = await axios.post("https://api.audd.io/", form, {
        headers: form.getHeaders(),
        timeout: 30000,
      });

      const result = res.data?.result;

      if (!result) {
        return sock.sendMessage(from, {
          text:
            "❌ Could not identify the song.\n\n" +
            "Tips:\n" +
            "• Use a clear audio clip (5–30 seconds)\n" +
            "• Make sure there's music playing without heavy noise",
        });
      }

      const spotifyUrl = result.spotify?.external_urls?.spotify || "N/A";
      const appleUrl = result.apple_music?.url || "N/A";

      await sock.sendMessage(from, {
        text:
          `✦✦✦✦✦✦✦✦✦✦\n` +
          `   🎵 SONG IDENTIFIED!\n` +
          `✦✦✦✦✦✦✦✦✦✦\n\n` +
          `🎤 *Title:* ${result.title}\n` +
          `🎸 *Artist:* ${result.artist}\n` +
          `💿 *Album:* ${result.album || "N/A"}\n` +
          `📅 *Released:* ${result.release_date || "N/A"}\n\n` +
          `🎧 *Spotify:* ${spotifyUrl}\n` +
          `🍎 *Apple Music:* ${appleUrl}\n\n` +
          `_Powered by AA MD Bot_`,
      });
    } catch (err) {
      await sock.sendMessage(from, {
        text: `❌ Shazam failed: ${err.message}`,
      });
    } finally {
      cleanup(tmpFile);
    }
  },
};
