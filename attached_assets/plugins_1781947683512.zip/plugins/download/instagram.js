// ============================================
// AA MD Bot - Instagram Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const fs = require("fs-extra");
const { downloadSocialMedia, cleanup } = require("../../lib/ytdlp");

module.exports = {
  command: ["ig", "instagram", "insta"],
  description: "Download Instagram reels/videos/photos",
  category: "Download",
  usage: ".ig <Instagram URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .ig <Instagram URL>" });
    }

    const url = args[0];
    if (!url.includes("instagram.com")) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid Instagram URL." });
    }

    await sock.sendMessage(from, { text: "⬇️ Downloading from Instagram..." });

    let tmpFile = null;
    try {
      const { filePath } = await downloadSocialMedia(url);
      tmpFile = filePath;
      await sock.sendMessage(from, {
        video: fs.readFileSync(filePath),
        caption: "📸 *Downloaded by AA MD Bot*",
        mimetype: "video/mp4",
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to download: ${err.message}\n\n_Make sure the post is public._` });
    } finally {
      cleanup(tmpFile);
    }
  },
};
