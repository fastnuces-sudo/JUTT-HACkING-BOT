// ============================================
// AA MD Bot - YouTube Audio Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const YouTube = require("youtube-sr").default;
const axios = require("axios");
const fs = require("fs-extra");
const { downloadAudio, downloadSoundCloud, getInfo, formatDuration, cleanup } = require("../../lib/ytdlp");

module.exports = {
  command: ["ytmp3", "ytaudio"],
  description: "Download audio — SoundCloud first, then YouTube",
  category: "Download",
  usage: ".ytmp3 <YouTube URL or song name>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .ytmp3 <YouTube URL or song name>\nExample: .ytmp3 Shape of You",
      });
    }

    const input = args.join(" ");
    const isYtUrl =
      input.startsWith("http") &&
      (input.includes("youtube.com") || input.includes("youtu.be"));

    await sock.sendMessage(from, { text: "🎵 Processing audio..." });

    let tmpFile = null;
    try {
      // ── Priority 1: SoundCloud (song name only, not YT URL) ──────
      if (!isYtUrl) {
        try {
          const sc = await downloadSoundCloud(input);
          tmpFile = sc.filePath;
          const headerText =
            `✦✦✦✦✦✦✦✦✦✦\n` +
            `   🎧 AA MD Bot MUSIC\n` +
            `✦✦✦✦✦✦✦✦✦✦\n\n` +
            `🎶 *${sc.title || input}*\n` +
            `🎵 SoundCloud\n\n` +
            `━━━━━━━━━━━━━━\n` +
            `⚡ Sending...`;
          await sock.sendMessage(from, { text: headerText });
          await sock.sendMessage(from, {
            audio: fs.readFileSync(sc.filePath),
            mimetype: sc.mimetype || "audio/mpeg",
            ptt: false,
          });
          return;
        } catch (_) {
          // SoundCloud failed — fall through to YouTube
        }
      }

      // ── Priority 2: YouTube (Innertube → Invidious → yt-dlp) ─────
      let videoId, videoUrl, title, author, durationSec;

      if (isYtUrl) {
        videoUrl = input;
        const match = input.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
        videoId = match ? match[1] : null;
        const info = await getInfo(videoUrl);
        title = info.title;
        author = info.author;
        durationSec = info.duration;
      } else {
        const results = await YouTube.search(input, { limit: 1, type: "video" });
        if (!results || results.length === 0) {
          return sock.sendMessage(from, { text: "❌ No results found on SoundCloud or YouTube." });
        }
        const video = results[0];
        videoId = video.id;
        videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
        title = video.title;
        author = video.channel?.name || "Unknown";
        durationSec = Math.floor((video.duration || 0) / 1000);
      }

      const duration = formatDuration(durationSec);
      const thumbUrl = videoId
        ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
        : null;

      const headerText =
        `✦✦✦✦✦✦✦✦✦✦\n` +
        `   🎧 AA MD Bot MUSIC\n` +
        `✦✦✦✦✦✦✦✦✦✦\n\n` +
        `🎶 *${title}*\n` +
        `👤 ${author}\n` +
        `⏱️ ${duration}\n\n` +
        `━━━━━━━━━━━━━━\n` +
        `⚡ Downloading...\n` +
        `🚀 Sending Soon`;

      const thumbPromise = thumbUrl
        ? axios.get(thumbUrl, { responseType: "arraybuffer", timeout: 8000 }).catch(() => null)
        : Promise.resolve(null);

      const audioPromise = downloadAudio(videoUrl);

      const thumbRes = await thumbPromise;
      if (thumbRes) {
        await sock.sendMessage(from, { image: Buffer.from(thumbRes.data), caption: headerText });
      } else {
        await sock.sendMessage(from, { text: headerText });
      }

      const { filePath, mimetype } = await audioPromise;
      tmpFile = filePath;

      await sock.sendMessage(from, {
        audio: fs.readFileSync(filePath),
        mimetype,
        ptt: false,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Error: ${err.message}` });
    } finally {
      cleanup(tmpFile);
    }
  },
};
