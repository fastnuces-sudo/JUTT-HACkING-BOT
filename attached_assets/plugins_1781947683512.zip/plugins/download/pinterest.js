// ============================================
// AA MD Bot - Pinterest Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// Multiple API fallbacks + yt-dlp
// ============================================

const axios = require("axios");
const fs = require("fs-extra");
const { downloadSocialMedia, cleanup } = require("../../lib/ytdlp");

const PIN_APIS = [
  (url) =>
    `https://api.nexoracle.com/downloaders/pinterest?url=${encodeURIComponent(url)}&apikey=free_for_use`,
  (url) =>
    `https://api.siputzx.my.id/api/d/pinterest?url=${encodeURIComponent(url)}`,
  (url) =>
    `https://api.davidcyriltech.my.id/download/pinterest?url=${encodeURIComponent(url)}`,
  (url) =>
    `https://api.tiklydown.eu.org/api/download/social?url=${encodeURIComponent(url)}`,
];

async function tryPinApis(url) {
  for (const buildUrl of PIN_APIS) {
    try {
      const { data } = await axios.get(buildUrl(url), {
        timeout: 18000,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      const result = data?.result || data?.data || data;
      if (!result || typeof result !== "object") continue;
      const mediaUrl =
        result.url || result.media || result.video || result.image ||
        result.download || result.link || result.mediaUrl;
      if (mediaUrl && typeof mediaUrl === "string" && mediaUrl.startsWith("http")) {
        return mediaUrl;
      }
      // Sometimes result is an array
      if (Array.isArray(result) && result.length > 0) {
        const first = result[0];
        const u = first?.url || first?.media || first?.link;
        if (u && u.startsWith("http")) return u;
      }
    } catch (_) {}
  }
  return null;
}

module.exports = {
  command: ["pin", "pinterest"],
  description: "Download Pinterest images/videos",
  category: "Download",
  usage: ".pin <Pinterest URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .pin <Pinterest URL>" });
    }

    const url = args[0];
    if (!url.includes("pinterest.com") && !url.includes("pin.it")) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid Pinterest URL." });
    }

    await sock.sendMessage(from, { text: "⬇️ Downloading from Pinterest..." });

    // ── Try 1: Multiple Pinterest APIs ───────────────────────────
    const mediaUrl = await tryPinApis(url);
    if (mediaUrl) {
      const isVideo = /\.mp4|video/i.test(mediaUrl);
      return await sock.sendMessage(from, {
        [isVideo ? "video" : "image"]: { url: mediaUrl },
        caption: "📌 *Downloaded by AA MD Bot*",
        ...(isVideo ? { mimetype: "video/mp4" } : {}),
      });
    }

    // ── Try 2: yt-dlp direct (Pinterest supported) ────────────────
    let tmpFile = null;
    try {
      const { filePath } = await downloadSocialMedia(url);
      tmpFile = filePath;
      await sock.sendMessage(from, {
        video: fs.readFileSync(filePath),
        caption: "📌 *Downloaded by AA MD Bot*",
        mimetype: "video/mp4",
      });
    } catch (err) {
      await sock.sendMessage(from, {
        text: `❌ Failed to download Pinterest content: ${err.message}`,
      });
    } finally {
      cleanup(tmpFile);
    }
  },
};
