// ============================================
// AA MD Bot - Spotify Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// Multiple API fallbacks + YouTube fallback
// ============================================

const axios = require("axios");
const YouTube = require("youtube-sr").default;
const fs = require("fs-extra");
const { downloadAudio, cleanup } = require("../../lib/ytdlp");

const SPOTIFY_APIS = [
  (q) =>
    `https://api.nexoracle.com/downloaders/spotify?query=${encodeURIComponent(q)}&apikey=free_for_use`,
  (q) =>
    `https://api.siputzx.my.id/api/d/spotifydl?url=${encodeURIComponent(q)}`,
  (q) =>
    `https://api.davidcyriltech.my.id/download/spotify?url=${encodeURIComponent(q)}`,
];

async function trySpotifyApis(query) {
  for (const buildUrl of SPOTIFY_APIS) {
    try {
      const { data } = await axios.get(buildUrl(query), {
        timeout: 18000,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      const result = data?.result || data?.data || data;
      if (!result || typeof result !== "object") continue;
      const audioUrl =
        result.audio || result.download_url || result.url ||
        result.audioUrl || result.link || result.downloadUrl;
      if (audioUrl && typeof audioUrl === "string" && audioUrl.startsWith("http")) {
        return {
          audioUrl,
          title: result.name || result.title || query,
          artist: result.artist || result.artists || "Unknown",
          duration: result.duration || "",
          coverUrl: result.thumbnail || result.image || result.cover || null,
        };
      }
    } catch (_) {}
  }
  return null;
}

module.exports = {
  command: ["spotify", "spoti", "spdl"],
  description: "Download Spotify / any song as audio",
  category: "Download",
  usage: ".spotify <song name>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .spotify <song name>\nExample: .spotify Blinding Lights",
      });
    }

    const query = args.join(" ");
    await sock.sendMessage(from, { text: `🎵 Searching: *${query}*...` });

    // ── Try 1: Spotify-specific download APIs ─────────────────────
    const spotifyResult = await trySpotifyApis(query);
    if (spotifyResult) {
      const { audioUrl, title, artist, duration, coverUrl } = spotifyResult;
      const caption =
        `✦✦✦✦✦✦✦✦✦✦\n` +
        `   🎵 SPOTIFY DOWNLOAD\n` +
        `✦✦✦✦✦✦✦✦✦✦\n\n` +
        `🎶 *${title}*\n` +
        `👤 ${artist}\n` +
        (duration ? `⏱️ ${duration}\n` : "") +
        `\n_Downloaded by AA MD Bot_`;

      if (coverUrl) {
        await sock.sendMessage(from, {
          image: { url: coverUrl },
          caption,
        }).catch(() => {});
      }
      return await sock.sendMessage(from, {
        audio: { url: audioUrl },
        mimetype: "audio/mpeg",
        ptt: false,
      });
    }

    // ── Try 2: YouTube search + yt-dlp (always works) ────────────
    let tmpFile = null;
    try {
      await sock.sendMessage(from, {
        text: "🔄 Spotify API busy — using YouTube fallback...",
      });

      const results = await YouTube.search(query, { limit: 1, type: "video" });
      if (!results || results.length === 0) throw new Error("No results found.");

      const video = results[0];
      const videoUrl = `https://www.youtube.com/watch?v=${video.id}`;
      const thumbUrl = `https://img.youtube.com/vi/${video.id}/hqdefault.jpg`;
      const caption =
        `🎵 *${video.title}*\n👤 ${video.channel?.name || "Unknown"}\n` +
        `📡 _Via YouTube | AA MD Bot_`;

      const [thumbRes, audioResult] = await Promise.all([
        axios.get(thumbUrl, { responseType: "arraybuffer", timeout: 8000 }).catch(() => null),
        downloadAudio(videoUrl),
      ]);

      if (thumbRes) {
        await sock.sendMessage(from, { image: Buffer.from(thumbRes.data), caption });
      }
      tmpFile = audioResult.filePath;
      await sock.sendMessage(from, {
        audio: fs.readFileSync(audioResult.filePath),
        mimetype: audioResult.mimetype,
        ptt: false,
      });
    } catch (err) {
      await sock.sendMessage(from, {
        text: `❌ Download failed: ${err.message}\n\nTip: Also try *.play ${query}*`,
      });
    } finally {
      cleanup(tmpFile);
    }
  },
};
