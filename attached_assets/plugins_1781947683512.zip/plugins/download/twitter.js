// ============================================
// AA MD Bot - Twitter/X Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const fs = require("fs-extra");
const { downloadSocialMedia, cleanup } = require("../../lib/ytdlp");

module.exports = {
  command: ["twitter", "tw", "xvideo"],
  description: "Download Twitter/X videos",
  category: "Download",
  usage: ".twitter <Tweet URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, { text: "⚠️ Usage: .twitter <Tweet URL>" });
    }

    const url = args[0];
    if (!url.includes("twitter.com") && !url.includes("x.com") && !url.includes("t.co")) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid Twitter/X URL." });
    }

    await sock.sendMessage(from, { text: "⬇️ Downloading Twitter/X video..." });

    let tmpFile = null;
    try {
      const { filePath } = await downloadSocialMedia(url);
      tmpFile = filePath;
      await sock.sendMessage(from, {
        video: fs.readFileSync(filePath),
        caption: "🐦 *Downloaded by AA MD Bot*",
        mimetype: "video/mp4",
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to download: ${err.message}` });
    } finally {
      cleanup(tmpFile);
    }
  },
};
