// ============================================
// AA MD Bot - SoundCloud Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// Multiple API fallbacks + yt-dlp direct
// ============================================

const axios = require("axios");
const fs = require("fs-extra");
const { downloadSocialMedia, cleanup } = require("../../lib/ytdlp");

const SC_APIS = [
  (url) =>
    `https://api.nexoracle.com/downloaders/soundcloud?url=${encodeURIComponent(url)}&apikey=free_for_use`,
  (url) =>
    `https://api.siputzx.my.id/api/d/soundcloud?url=${encodeURIComponent(url)}`,
  (url) =>
    `https://api.davidcyriltech.my.id/download/soundcloud?url=${encodeURIComponent(url)}`,
];

async function tryScApis(url) {
  for (const buildUrl of SC_APIS) {
    try {
      const { data } = await axios.get(buildUrl(url), {
        timeout: 18000,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      const result = data?.result || data?.data || data;
      if (!result || typeof result !== "object") continue;
      const audioUrl =
        result.audio || result.download || result.url ||
        result.audio_url || result.downloadUrl || result.link;
      if (audioUrl && typeof audioUrl === "string" && audioUrl.startsWith("http")) {
        return {
          audioUrl,
          title: result.title || result.name || "SoundCloud Track",
          author: result.author || result.uploader || result.artist || "Unknown",
          coverUrl: result.thumbnail || result.artwork || null,
        };
      }
    } catch (_) {}
  }
  return null;
}

module.exports = {
  command: ["soundcloud", "scdl", "sc"],
  description: "Download SoundCloud audio",
  category: "Download",
  usage: ".sc <SoundCloud URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .sc <SoundCloud URL>\nExample: .sc https://soundcloud.com/artist/track",
      });
    }

    const url = args[0];
    if (!url.includes("soundcloud.com")) {
      return sock.sendMessage(from, {
        text: "❌ Please provide a valid SoundCloud URL.",
      });
    }

    await sock.sendMessage(from, { text: "⏳ Downloading SoundCloud audio..." });

    // ── Try 1: SC download APIs ───────────────────────────────────
    const scResult = await tryScApis(url);
    if (scResult) {
      const { audioUrl, title, author, coverUrl } = scResult;
      if (coverUrl) {
        await sock.sendMessage(from, {
          image: { url: coverUrl },
          caption: `🎵 *${title}*\n👤 ${author}\n_AA MD Bot_`,
        }).catch(() => {});
      }
      await sock.sendMessage(from, {
        audio: { url: audioUrl },
        mimetype: "audio/mpeg",
        ptt: false,
      });
      if (!coverUrl) {
        await sock.sendMessage(from, {
          text: `🎵 *${title}*\n👤 ${author}\n_Downloaded by AA MD Bot_`,
        });
      }
      return;
    }

    // ── Try 2: yt-dlp direct (SoundCloud is fully supported) ─────
    let tmpFile = null;
    try {
      await sock.sendMessage(from, { text: "🔄 Trying direct download..." });
      const { filePath } = await downloadSocialMedia(url);
      tmpFile = filePath;
      await sock.sendMessage(from, {
        audio: fs.readFileSync(filePath),
        mimetype: "audio/mpeg",
        ptt: false,
      });
      await sock.sendMessage(from, {
        text: `🎵 *SoundCloud Track*\n_Downloaded by AA MD Bot_`,
      });
    } catch (err) {
      await sock.sendMessage(from, {
        text: `❌ SoundCloud download failed: ${err.message}`,
      });
    } finally {
      cleanup(tmpFile);
    }
  },
};
