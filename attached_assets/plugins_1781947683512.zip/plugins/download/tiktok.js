// ============================================
// AA MD Bot - TikTok Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// Uses downloadSocialMedia (parallel watermark-free APIs)
// .ttaudio — download background music only
// ============================================

const fs = require("fs-extra");
const axios = require("axios");
const { downloadSocialMedia, downloadTikTokAudio } = require("../../lib/ytdlp");
const config = require("../../config");
const LINK = config.channelLink || "https://aa-mods.vercel.app/";

module.exports = {
  command: ["tiktok", "tt", "tiktokvideo", "ttaudio"],
  description: "Download TikTok video (no watermark) or audio",
  category: "Download",
  usage: ".tiktok <URL> — video | .ttaudio <URL> — audio/music only",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from, body } = ctx;
    const cmd = (body || "").split(/\s/)[0].replace(/[^a-z]/gi, "").toLowerCase();
    const isAudio = cmd === "ttaudio";

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: isAudio
          ? `⚠️ Usage: *.ttaudio* <TikTok URL>\nDownloads the background music from a TikTok video.`
          : `⚠️ Usage: *.tiktok* <TikTok URL>\n\n*Also:*\n• *.tt* — short alias\n• *.ttaudio* — download audio/music only`,
      });
    }

    const url = args[0];
    if (!/tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(url)) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid TikTok URL." });
    }

    await sock.sendMessage(from, {
      text: isAudio ? "🎵 Fetching TikTok audio..." : "⬇️ Downloading TikTok video (no watermark)...",
    });

    let tmpFile = null;
    try {
      if (isAudio) {
        // ── Audio mode ──────────────────────────────────────────
        const result = await downloadTikTokAudio(url);
        tmpFile = result.filePath;
        const { title, cover, author } = result.meta || {};

        if (cover) {
          try {
            const coverBuf = await axios.get(cover, { responseType: "arraybuffer", timeout: 8000 });
            await sock.sendMessage(from, {
              image: Buffer.from(coverBuf.data),
              caption:
                `✦✦✦✦✦✦✦✦✦✦\n` +
                `   🎵 TikTok Audio\n` +
                `✦✦✦✦✦✦✦✦✦✦\n\n` +
                `🎶 ${title || "TikTok Music"}\n` +
                `👤 ${author || "Unknown"}\n\n` +
                `━━━━━━━━━━━━━━\n` +
                `🌐 ${LINK}`,
            });
          } catch (_) {}
        }

        await sock.sendMessage(from, {
          audio: fs.readFileSync(tmpFile),
          mimetype: "audio/mpeg",
          ptt: false,
        });

      } else {
        // ── Video mode — downloadSocialMedia handles everything ──
        const result = await downloadSocialMedia(url);
        tmpFile = result.filePath;
        const { title, cover, author, audioUrl } = result.meta || {};

        if (cover) {
          try {
            const coverBuf = await axios.get(cover, { responseType: "arraybuffer", timeout: 8000 });
            await sock.sendMessage(from, {
              image: Buffer.from(coverBuf.data),
              caption:
                `✦✦✦✦✦✦✦✦✦✦\n` +
                `   🎬 TikTok Video\n` +
                `✦✦✦✦✦✦✦✦✦✦\n\n` +
                `📝 ${title || "TikTok Video"}\n` +
                `👤 ${author || "Unknown"}\n\n` +
                `━━━━━━━━━━━━━━\n` +
                `⏳ Sending video...`,
            });
          } catch (_) {}
        }

        await sock.sendMessage(from, {
          video: fs.readFileSync(tmpFile),
          caption:
            `🎬 *${title || "TikTok Video"}*\n` +
            `👤 ${author || ""}\n` +
            `_Downloaded by AA MD Bot_\n🌐 ${LINK}`,
          mimetype: "video/mp4",
        });

        if (audioUrl) {
          await sock.sendMessage(from, {
            text: `🎵 Want the audio only? Reply with *.ttaudio ${url}*`,
          });
        }
      }
    } catch (err) {
      await sock.sendMessage(from, {
        text:
          `❌ *TikTok ${isAudio ? "Audio" : "Video"} Failed*\n\n` +
          `${err.message}\n\n` +
          `💡 *Tips:*\n` +
          `• Make sure the video is public\n` +
          `• Try again — different APIs are tried each time\n` +
          `• Try a different TikTok link`,
      });
    } finally {
      if (tmpFile) { try { fs.removeSync(tmpFile); } catch (_) {} }
    }
  },
};
