// ============================================
// AA MD Bot - YouTube Video Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const YouTube = require("youtube-sr").default;
const axios = require("axios");
const fs = require("fs-extra");
const { downloadVideo, getInfo, formatDuration, cleanup } = require("../../lib/ytdlp");

module.exports = {
  command: ["yt", "ytmp4", "ytvideo"],
  description: "Download YouTube video — URL or search",
  category: "Download",
  usage: ".yt <YouTube URL or video title>",
  cooldown: 20000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .yt <YouTube URL or video title>\nExample: .yt Naruto opening",
      });
    }

    const input = args.join(" ");
    const isUrl =
      input.startsWith("http") &&
      (input.includes("youtube.com") || input.includes("youtu.be"));

    await sock.sendMessage(from, { text: "⬇️ Processing video..." });

    let tmpFile = null;
    try {
      let videoId, videoUrl, title, author, durationSec;

      if (isUrl) {
        videoUrl = input;
        const match = input.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
        videoId = match ? match[1] : null;
        const info = await getInfo(videoUrl);
        title = info.title;
        author = info.author;
        durationSec = info.duration;
      } else {
        const results = await YouTube.search(input, { limit: 1, type: "video" });
        if (!results || results.length === 0) {
          return sock.sendMessage(from, { text: "❌ No results found." });
        }
        const video = results[0];
        videoId = video.id;
        videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
        title = video.title;
        author = video.channel?.name || "Unknown";
        durationSec = Math.floor((video.duration || 0) / 1000);
      }

      const duration = formatDuration(durationSec);
      const thumbUrl = videoId
        ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
        : null;

      const headerText =
        `✦✦✦✦✦✦✦✦✦✦\n` +
        `   🎬 AA MD Bot VIDEO\n` +
        `✦✦✦✦✦✦✦✦✦✦\n\n` +
        `🎥 *${title}*\n` +
        `👤 ${author}\n` +
        `⏱️ ${duration}\n\n` +
        `━━━━━━━━━━━━━━\n` +
        `⚡ Downloading...\n` +
        `🚀 Sending Soon`;

      const thumbPromise = thumbUrl
        ? axios.get(thumbUrl, { responseType: "arraybuffer", timeout: 8000 }).catch(() => null)
        : Promise.resolve(null);

      const videoPromise = downloadVideo(videoUrl, 480);

      const thumbRes = await thumbPromise;
      if (thumbRes) {
        await sock.sendMessage(from, { image: Buffer.from(thumbRes.data), caption: headerText });
      } else {
        await sock.sendMessage(from, { text: headerText });
      }

      const { filePath } = await videoPromise;
      tmpFile = filePath;

      await sock.sendMessage(from, {
        video: fs.readFileSync(filePath),
        mimetype: "video/mp4",
        caption: `✅ *${title}*\n👤 ${author} | ⏱️ ${duration}\n_Downloaded by AA MD Bot_`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Error: ${err.message}` });
    } finally {
      cleanup(tmpFile);
    }
  },
};
