// ============================================
// AA MD Bot - MediaFire Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// Robust regex + API fallback
// ============================================

const axios = require("axios");

const MF_APIS = [
  (url) =>
    `https://api.nexoracle.com/downloaders/mediafire?url=${encodeURIComponent(url)}&apikey=free_for_use`,
  (url) =>
    `https://api.siputzx.my.id/api/d/mediafire?url=${encodeURIComponent(url)}`,
];

async function tryApis(url) {
  for (const buildUrl of MF_APIS) {
    try {
      const { data } = await axios.get(buildUrl(url), {
        timeout: 15000,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      const result = data?.result || data?.data || data;
      const dlUrl =
        result?.url || result?.download || result?.link ||
        result?.directLink || result?.direct_link;
      if (dlUrl && typeof dlUrl === "string" && dlUrl.startsWith("http")) {
        return {
          directLink: dlUrl,
          filename: result.filename || result.name || result.title || "MediaFire File",
          filesize: result.size || result.filesize || "Unknown",
        };
      }
    } catch (_) {}
  }
  return null;
}

module.exports = {
  command: ["mediafire", "mf"],
  description: "Get MediaFire direct download link",
  category: "Download",
  usage: ".mediafire <MediaFire URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .mediafire <MediaFire URL>",
      });
    }

    const url = args[0];
    if (!url.includes("mediafire.com")) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid MediaFire URL." });
    }

    await sock.sendMessage(from, { text: "🔍 Fetching MediaFire link..." });

    // ── Try 1: Dedicated APIs ─────────────────────────────────────
    const apiResult = await tryApis(url);
    if (apiResult) {
      return await sock.sendMessage(from, {
        text:
          `✅ *MediaFire File Found!*\n\n` +
          `📁 *File:* ${apiResult.filename}\n` +
          `📦 *Size:* ${apiResult.filesize}\n\n` +
          `⬇️ *Direct Download Link:*\n${apiResult.directLink}`,
      });
    }

    // ── Try 2: HTML scraping with multiple regex patterns ─────────
    try {
      const res = await axios.get(url, {
        timeout: 20000,
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
        maxRedirects: 10,
      });

      const html = res.data;

      // Multiple patterns for direct link extraction
      const dlPatterns = [
        /href="(https:\/\/download\d*\.mediafire\.com[^"]+)"/i,
        /id="downloadButton"[^>]*href="([^"]+)"/i,
        /"direct_download_link"\s*:\s*"([^"]+)"/i,
        /aria-label="Download file"[^>]*href="([^"]+)"/i,
        /class="[^"]*download[^"]*"[^>]*href="([^"]+download[^"]+)"/i,
        /"url"\s*:\s*"(https:\/\/[^"]*mediafire[^"]*download[^"]+)"/i,
        /window\.location\.href\s*=\s*['"]([^'"]+download[^'"]+)['"]/i,
      ];

      let directLink = null;
      for (const pattern of dlPatterns) {
        const m = html.match(pattern);
        if (m && m[1]) {
          directLink = m[1].replace(/\\u002F/g, "/").replace(/\\/g, "");
          break;
        }
      }

      // Filename patterns
      const filePatterns = [
        /<div[^>]+class="[^"]*filename[^"]*"[^>]*>([^<]+)</i,
        /<div[^>]+id="[^"]*filename[^"]*"[^>]*>([^<]+)</i,
        /<title>Download ([^|<]+)/i,
        /"filename"\s*:\s*"([^"]+)"/i,
        /<span[^>]+class="[^"]*name[^"]*"[^>]*>([^<]+)</i,
      ];

      let filename = "MediaFire File";
      for (const pattern of filePatterns) {
        const m = html.match(pattern);
        if (m && m[1] && m[1].trim()) {
          filename = m[1].trim();
          break;
        }
      }

      const sizeMatch = html.match(/(\d+(?:\.\d+)?\s*(?:KB|MB|GB))/i);
      const filesize = sizeMatch ? sizeMatch[1] : "Unknown";

      if (!directLink) {
        return sock.sendMessage(from, {
          text:
            "❌ Could not extract download link.\n\n" +
            "The file may be:\n• Private or removed\n• Blocked in your region\n\n" +
            `🔗 Try opening directly:\n${url}`,
        });
      }

      await sock.sendMessage(from, {
        text:
          `✅ *MediaFire File Found!*\n\n` +
          `📁 *File:* ${filename}\n` +
          `📦 *Size:* ${filesize}\n\n` +
          `⬇️ *Direct Download Link:*\n${directLink}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Error: ${err.message}` });
    }
  },
};
