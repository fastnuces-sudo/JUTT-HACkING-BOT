// ============================================
// AA MD Bot - CapCut Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// Multiple API fallbacks
// ============================================

const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const { TEMP_DIR, cleanup } = require("../../lib/ytdlp");

const CAPCUT_APIS = [
  (url) =>
    `https://api.nexoracle.com/downloaders/capcut?url=${encodeURIComponent(url)}&apikey=free_for_use`,
  (url) =>
    `https://api.siputzx.my.id/api/d/capcut?url=${encodeURIComponent(url)}`,
  (url) =>
    `https://api.davidcyriltech.my.id/download/capcut?url=${encodeURIComponent(url)}`,
  (url) =>
    `https://api.tiklydown.eu.org/api/download/social?url=${encodeURIComponent(url)}`,
];

async function getVideoUrl(url) {
  for (const buildUrl of CAPCUT_APIS) {
    try {
      const { data } = await axios.get(buildUrl(url), {
        timeout: 18000,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      const result = data?.result || data?.data || data;
      const videoUrl =
        result?.video || result?.url || result?.download ||
        result?.video_url || result?.videoUrl || result?.link;
      if (videoUrl && typeof videoUrl === "string" && videoUrl.startsWith("http")) {
        return {
          videoUrl,
          title: result?.title || result?.desc || "CapCut Video",
        };
      }
    } catch (_) {}
  }
  return null;
}

async function downloadToFile(videoUrl, dest) {
  const res = await axios({
    method: "get",
    url: videoUrl,
    responseType: "stream",
    timeout: 90000,
    headers: { "User-Agent": "Mozilla/5.0" },
  });
  await new Promise((resolve, reject) => {
    const out = fs.createWriteStream(dest);
    res.data.pipe(out);
    out.on("finish", resolve);
    out.on("error", reject);
  });
}

module.exports = {
  command: ["capcut", "capcutdl", "cc"],
  description: "Download CapCut videos without watermark",
  category: "Download",
  usage: ".capcut <CapCut URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .capcut <CapCut URL>\nExample: .capcut https://www.capcut.com/share/...",
      });
    }

    const url = args[0];
    if (!url.includes("capcut")) {
      return sock.sendMessage(from, { text: "❌ Please provide a valid CapCut URL." });
    }

    await sock.sendMessage(from, { text: "⬇️ Downloading CapCut video..." });

    let tmpFile = null;
    try {
      const found = await getVideoUrl(url);
      if (!found) throw new Error("Could not extract video from any API.");

      const filePath = path.join(TEMP_DIR, `capcut_${Date.now()}.mp4`);
      await downloadToFile(found.videoUrl, filePath);
      tmpFile = filePath;

      await sock.sendMessage(from, {
        video: fs.readFileSync(filePath),
        caption: `✂️ *${found.title}*\n_Downloaded by AA MD Bot_`,
        mimetype: "video/mp4",
      });
    } catch (e) {
      await sock.sendMessage(from, {
        text: `❌ CapCut download failed: ${e.message}`,
      });
    } finally {
      cleanup(tmpFile);
    }
  },
};
