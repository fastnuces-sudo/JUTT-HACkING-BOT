// ============================================
// AA MD Bot - Facebook Downloader Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const fs = require("fs-extra");
const axios = require("axios");
const path = require("path");
const { cleanup, TEMP_DIR } = require("../../lib/ytdlp");

// Facebook downloader free APIs with multiple fallbacks
const FB_APIS = (url) => [
  {
    // cobalt.tools — supports Facebook
    name: "cobalt",
    fetch: () =>
      axios.post(
        "https://api.cobalt.tools/",
        { url, downloadMode: "auto" },
        { timeout: 30000, headers: { Accept: "application/json", "Content-Type": "application/json" } }
      ),
    parse: (d) => {
      if (!d) return null;
      if (typeof d.url === "string" && d.url.startsWith("http")) return d.url;
      if (Array.isArray(d.picker)) return d.picker[0]?.url;
      return null;
    },
  },
  {
    name: "tiklydown",
    fetch: () =>
      axios.get(
        `https://api.tiklydown.eu.org/api/download/fb?url=${encodeURIComponent(url)}`,
        { timeout: 25000 }
      ),
    parse: (d) => d?.video || d?.url || d?.data?.url,
  },
  {
    name: "fdownloader-nexoracle",
    fetch: () =>
      axios.get(
        `https://api.nexoracle.com/downloaders/facebook?url=${encodeURIComponent(url)}&apikey=free_for_use`,
        { timeout: 25000 }
      ),
    parse: (d) => d?.result?.url || d?.result?.hd || d?.result?.sd,
  },
  {
    name: "siputzx-fb",
    fetch: () =>
      axios.get(
        `https://api.siputzx.my.id/api/d/facebook?url=${encodeURIComponent(url)}`,
        { timeout: 25000 }
      ),
    parse: (d) => d?.data?.url || d?.data?.hd || d?.data?.sd || d?.url,
  },
  {
    name: "davidcyriltech-fb",
    fetch: () =>
      axios.get(
        `https://api.davidcyriltech.my.id/download/facebook?url=${encodeURIComponent(url)}`,
        { timeout: 25000 }
      ),
    parse: (d) => d?.result?.url || d?.result?.downloadUrl || d?.url,
  },
];

async function streamToFile(dlUrl, filePath, timeout = 120000) {
  const res = await axios({
    method: "get",
    url: dlUrl,
    responseType: "stream",
    timeout,
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
  });
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(filePath);
    res.data.pipe(out);
    out.on("finish", resolve);
    out.on("error", reject);
    res.data.on("error", reject);
  });
}

module.exports = {
  command: ["fb", "facebook"],
  description: "Download Facebook videos",
  category: "Download",
  usage: ".fb <Facebook video URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .fb <Facebook video URL>\nExample: .fb https://www.facebook.com/share/r/xxxxx",
      });
    }

    const url = args[0];
    if (
      !url.includes("facebook.com") &&
      !url.includes("fb.watch") &&
      !url.includes("fb.com")
    ) {
      return sock.sendMessage(from, {
        text: "❌ Please provide a valid Facebook URL.",
      });
    }

    await sock.sendMessage(from, {
      text: "⬇️ Downloading Facebook video... Please wait ⏳",
    });

    let tmpFile = null;

    for (const api of FB_APIS(url)) {
      try {
        const { data } = await api.fetch();
        const dlUrl = api.parse(data);

        if (dlUrl && typeof dlUrl === "string" && dlUrl.startsWith("http")) {
          const filePath = path.join(TEMP_DIR, `fb_${Date.now()}.mp4`);
          await streamToFile(dlUrl, filePath, 120000);

          const stat = fs.statSync(filePath);
          if (stat.size > 1024) {
            tmpFile = filePath;
            console.log(`[FB] Downloaded via ${api.name} ✓`);

            await sock.sendMessage(from, {
              video: fs.readFileSync(filePath),
              caption: "📱 *Downloaded by AA MD Bot*\n_AA Mods_",
              mimetype: "video/mp4",
            });

            return;
          }
          fs.removeSync(filePath);
        }
      } catch (e) {
        console.warn(`[FB] ${api.name} failed: ${e.message.slice(0, 80)}`);
      }
    }

    // All APIs failed
    await sock.sendMessage(from, {
      text:
        "❌ *Facebook video download failed.*\n\n" +
        "Possible reasons:\n" +
        "• Video is *private* (only public videos can be downloaded)\n" +
        "• Share link has expired\n" +
        "• Facebook has blocked access\n\n" +
        "💡 *Tip:* Copy the direct video URL from the Facebook post (not the share link) and try again.",
    });

    cleanup(tmpFile);
  },
};
