// ============================================
// AA MD Bot - Anti-Link Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting } = require("../../lib/database");

module.exports = {
  command: ["antilink", "al"],
  description: "Enable/disable anti-link protection",
  category: "Admin",
  usage: ".antilink on/off",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const toggle = args[0]?.toLowerCase();

    if (!toggle || !["on", "off"].includes(toggle)) {
      const current = getGroupSetting(from, "antilink");
      return sock.sendMessage(from, {
        text: `ℹ️ Anti-link is currently *${current ? "ON" : "OFF"}*\nUse .antilink on/off to toggle.`,
      });
    }

    const value = toggle === "on";
    setGroupSetting(from, "antilink", value);
    await sock.sendMessage(from, {
      text: `🔗 Anti-link is now *${value ? "ON" : "OFF"}*\n${value ? "WhatsApp links will be deleted automatically." : "Links are now allowed."}`,
    });
  },
};
