// ============================================
// AA MD Bot - Hidetag Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["hidetag", "htag"],
  description: "Tag all without showing names",
  category: "Admin",
  usage: ".hidetag <message>",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from, groupMetadata } = ctx;

    if (!groupMetadata) {
      return sock.sendMessage(from, { text: "❌ Could not fetch group info." });
    }

    const participants = groupMetadata.participants;
    const mentions = participants.map((p) => p.id);
    const message = args.join(" ") || "👋";

    await sock.sendMessage(from, { text: message, mentions });
  },
};
