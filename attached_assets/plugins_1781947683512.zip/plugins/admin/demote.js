// ============================================
// AA MD Bot - Demote Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["demote"],
  description: "Demote an admin to member",
  category: "Admin",
  usage: ".demote @mention",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx }) {
    const { from, mentions, quoted } = ctx;

    let target = mentions?.[0] || quoted?.sender;
    if (!target) {
      return sock.sendMessage(from, { text: "⚠️ Please mention or reply to an admin to demote." });
    }

    try {
      await sock.groupParticipantsUpdate(from, [target], "demote");
      await sock.sendMessage(from, {
        text: `📉 @${cleanJid(target)} has been demoted to *Member*.`,
        mentions: [target],
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to demote: ${err.message}` });
    }
  },
};
