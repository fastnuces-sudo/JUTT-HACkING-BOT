// ============================================
// AA MD Bot - Set Group Description Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["setdesc", "setdescription"],
  description: "Change the group description",
  category: "Admin",
  usage: ".setdesc <description>",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, { text: "⚠️ Please provide a description." });
    }

    const desc = args.join(" ");
    try {
      await sock.groupUpdateDescription(from, desc);
      await sock.sendMessage(from, { text: `✅ Group description updated!` });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to update description: ${err.message}` });
    }
  },
};
