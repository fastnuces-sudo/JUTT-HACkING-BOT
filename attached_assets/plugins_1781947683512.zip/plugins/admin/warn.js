// ============================================
// AA MD Bot - Warn System Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { addWarn, getWarns, clearWarns } = require("../../lib/database");
const { cleanJid } = require("../../lib/utils");

const MAX_WARNS = 3;

module.exports = {
  command: ["warn"],
  description: "Warn a group member",
  category: "Admin",
  usage: ".warn @mention [reason]",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx, args }) {
    const { from, mentions, quoted } = ctx;

    let target = mentions?.[0] || quoted?.sender;
    if (!target) {
      return sock.sendMessage(from, { text: "⚠️ Please mention or reply to a member to warn." });
    }

    const reason = args.join(" ").replace(/<@\d+>/g, "").trim() || "No reason given";
    const warns = addWarn(from, target);

    let text = `⚠️ *Warning issued to @${cleanJid(target)}*\n`;
    text += `📋 Reason: ${reason}\n`;
    text += `⚡ Warnings: ${warns}/${MAX_WARNS}`;

    if (warns >= MAX_WARNS) {
      text += `\n\n🚨 Max warnings reached! Kicking...`;
      try {
        await sock.groupParticipantsUpdate(from, [target], "remove");
        clearWarns(from, target);
      } catch {}
    }

    await sock.sendMessage(from, { text, mentions: [target] });
  },
};
