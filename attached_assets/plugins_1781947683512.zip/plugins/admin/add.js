// ============================================
// AA MD Bot - Add Member Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["add"],
  description: "Add a member to the group",
  category: "Admin",
  usage: ".add 923xxxxxxxxx",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .add <number>\nExample: .add 923001234567",
      });
    }

    // Clean number
    const number = args[0].replace(/[^0-9]/g, "");
    if (number.length < 7) {
      return sock.sendMessage(from, {
        text: "❌ Invalid number. Include country code.\nExample: .add 923001234567",
      });
    }

    const jid = `${number}@s.whatsapp.net`;

    try {
      const result = await sock.groupParticipantsUpdate(from, [jid], "add");
      const status = String(result?.[0]?.status || "");

      if (status === "200") {
        await sock.sendMessage(from, {
          text: `✅ *+${number}* successfully added to the group!`,
        });
      } else if (status === "400") {
        // User requires an invite link to join — send them the group invite
        try {
          const inviteCode = await sock.groupInviteCode(from);
          const inviteLink = `https://chat.whatsapp.com/${inviteCode}`;
          await sock.sendMessage(from, {
            text: `⚠️ *+${number}* can't be added directly.\n\nTheir privacy settings require an invite link.\n\n🔗 *Group Invite Link:*\n${inviteLink}\n\n_Please share this link with them to join._`,
          });
        } catch {
          await sock.sendMessage(from, {
            text: `⚠️ *+${number}* can't be added directly.\nTheir privacy settings require them to be invited via a link.\n\nUse *.link* to get the group invite link and share it with them.`,
          });
        }
      } else if (status === "403") {
        await sock.sendMessage(from, {
          text: `❌ *+${number}* has privacy settings that block being added to groups.`,
        });
      } else if (status === "408") {
        await sock.sendMessage(from, {
          text: `❌ *+${number}* is not on WhatsApp or the number is invalid.`,
        });
      } else if (status === "401") {
        await sock.sendMessage(from, {
          text: `❌ *+${number}* has blocked this bot or you are not in their contacts.`,
        });
      } else if (status === "409") {
        await sock.sendMessage(from, {
          text: `ℹ️ *+${number}* is already a member of this group.`,
        });
      } else {
        await sock.sendMessage(from, {
          text: `⚠️ Could not add *+${number}*. Status: ${status || "unknown"}\n\nTry using the group invite link instead.`,
        });
      }
    } catch (err) {
      const msg = err.message || "";
      if (msg.includes("not-authorized") || msg.includes("403")) {
        await sock.sendMessage(from, {
          text: `❌ Bot is not authorized to add members. Make sure the bot is a group admin.`,
        });
      } else {
        await sock.sendMessage(from, {
          text: `❌ Failed to add: ${msg}`,
        });
      }
    }
  },
};
