// ============================================
// AA MD Bot - Clear Chat (Bot Messages) Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["clear", "clearchat"],
  description: "Send a series of blank lines to clear visible chat",
  category: "Admin",
  usage: ".clear",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;
    const blank = "\n".repeat(60);
    await sock.sendMessage(from, {
      text: `🧹 *Chat Cleared*${blank}⬆️ Scroll up for history.`,
    });
  },
};
