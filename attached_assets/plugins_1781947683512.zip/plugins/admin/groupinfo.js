// ============================================
// AA MD Bot - Group Info Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const moment = require("moment");

module.exports = {
  command: ["groupinfo", "ginfo", "gcinfo"],
  description: "Show group information",
  category: "Admin",
  usage: ".groupinfo",
  groupOnly: true,

  async execute({ sock, ctx }) {
    const { from, groupMetadata } = ctx;

    if (!groupMetadata) {
      return sock.sendMessage(from, { text: "❌ Could not fetch group info." });
    }

    const { subject, desc, participants, creation, owner } = groupMetadata;
    const admins = participants.filter((p) => p.admin).length;
    const members = participants.length;
    const created = moment(creation * 1000).format("MMMM Do YYYY");

    const text = `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
       📋 *GROUP INFO*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 *Name:* ${subject}
👥 *Members:* ${members}
🛡️ *Admins:* ${admins}
👤 *Owner:* ${owner ? owner.split("@")[0] : "Unknown"}
📅 *Created:* ${created}

📝 *Description:*
${desc || "No description set."}`;

    await sock.sendMessage(from, { text });
  },
};
