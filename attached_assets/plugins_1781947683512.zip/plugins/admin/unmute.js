// ============================================
// AA MD Bot - Unmute Group Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["unmute", "open"],
  description: "Unmute the group (everyone can send messages)",
  category: "Admin",
  usage: ".unmute",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;
    try {
      await sock.groupSettingUpdate(from, "not_announcement");
      await sock.sendMessage(from, { text: "🔊 Group has been *unmuted*. Everyone can send messages." });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to unmute: ${err.message}` });
    }
  },
};
