// ============================================
// AA MD Bot - Set Group Name Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["setname", "rename"],
  description: "Change the group name",
  category: "Admin",
  usage: ".setname <new name>",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, { text: "⚠️ Please provide a new group name." });
    }

    const name = args.join(" ");
    try {
      await sock.groupUpdateSubject(from, name);
      await sock.sendMessage(from, { text: `✅ Group name changed to: *${name}*` });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to change name: ${err.message}` });
    }
  },
};
