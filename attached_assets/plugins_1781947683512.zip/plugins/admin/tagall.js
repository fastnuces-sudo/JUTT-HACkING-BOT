// ============================================
// AA MD Bot - Tag All Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["tagall", "everyone", "@all"],
  description: "Tag all group members",
  category: "Admin",
  usage: ".tagall [message]",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from, groupMetadata } = ctx;

    if (!groupMetadata) {
      return sock.sendMessage(from, { text: "❌ Could not fetch group info." });
    }

    const participants = groupMetadata.participants;
    const mentions = participants.map((p) => p.id);
    const message = args.join(" ") || "📢 Attention everyone!";

    let text = `📢 *${message}*\n\n`;
    text += participants
      .map((p, i) => `${i + 1}. @${cleanJid(p.id)}`)
      .join("\n");

    await sock.sendMessage(from, { text, mentions });
  },
};
