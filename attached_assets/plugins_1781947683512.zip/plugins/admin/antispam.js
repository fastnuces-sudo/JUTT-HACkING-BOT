// ============================================
// AA MD Bot - Anti-Spam Toggle Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting } = require("../../lib/database");

module.exports = {
  command: ["antispam", "as"],
  description: "Enable/disable anti-spam protection",
  category: "Admin",
  usage: ".antispam on/off",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const toggle = args[0]?.toLowerCase();

    if (!toggle || !["on", "off"].includes(toggle)) {
      const current = getGroupSetting(from, "antispam");
      return sock.sendMessage(from, {
        text: `ℹ️ Anti-spam is currently *${current ? "ON" : "OFF"}*\nUse .antispam on/off to toggle.`,
      });
    }

    const value = toggle === "on";
    setGroupSetting(from, "antispam", value);
    await sock.sendMessage(from, {
      text: `🛡️ Anti-spam is now *${value ? "ON" : "OFF"}*`,
    });
  },
};
