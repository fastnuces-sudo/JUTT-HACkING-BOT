// ============================================
// AA MD Bot - Goodbye System Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting, updateGroup } = require("../../lib/database");

module.exports = {
  command: ["goodbye", "setgoodbye"],
  description: "Enable/disable goodbye messages or set custom goodbye",
  category: "Admin",
  usage: ".goodbye on/off | .setgoodbye <message>",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const command = ctx.body.split(" ")[0].replace(/[.!/#]/g, "");

    if (command === "setgoodbye") {
      const msg = args.join(" ");
      if (!msg) {
        return sock.sendMessage(from, {
          text: "⚠️ Provide a custom goodbye message.\nUse {name} for member name, {group} for group name.",
        });
      }
      updateGroup(from, { goodbyeMsg: msg });
      return sock.sendMessage(from, { text: `✅ Goodbye message updated:\n\n${msg}` });
    }

    const toggle = args[0]?.toLowerCase();
    if (!toggle || !["on", "off"].includes(toggle)) {
      const current = getGroupSetting(from, "goodbye");
      return sock.sendMessage(from, {
        text: `ℹ️ Goodbye messages are currently *${current ? "ON" : "OFF"}*\nUse .goodbye on/off to toggle.`,
      });
    }

    const value = toggle === "on";
    setGroupSetting(from, "goodbye", value);
    await sock.sendMessage(from, {
      text: `✅ Goodbye messages are now *${value ? "ON" : "OFF"}*`,
    });
  },
};
