// ============================================
// AA MD Bot - Anti Bad Word Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting } = require("../../lib/database");

module.exports = {
  command: ["antibadword", "antiswear", "abw"],
  description: "Enable/disable bad word filter",
  category: "Admin",
  usage: ".antibadword on/off",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const toggle = args[0]?.toLowerCase();

    if (!toggle || !["on", "off"].includes(toggle)) {
      const current = getGroupSetting(from, "antibadword");
      return sock.sendMessage(from, {
        text: `ℹ️ Anti bad-word is currently *${current ? "ON" : "OFF"}*\nUse .antibadword on/off to toggle.`,
      });
    }

    const value = toggle === "on";
    setGroupSetting(from, "antibadword", value);
    await sock.sendMessage(from, {
      text: `🤬 Anti bad-word filter is now *${value ? "ON" : "OFF"}*`,
    });
  },
};
