// ============================================
// AA MD Bot - Promote Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["promote"],
  description: "Promote a member to admin",
  category: "Admin",
  usage: ".promote @mention",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx }) {
    const { from, mentions, quoted } = ctx;

    let target = mentions?.[0] || quoted?.sender;
    if (!target) {
      return sock.sendMessage(from, { text: "⚠️ Please mention or reply to a member to promote." });
    }

    try {
      await sock.groupParticipantsUpdate(from, [target], "promote");
      await sock.sendMessage(from, {
        text: `⭐ @${cleanJid(target)} has been promoted to *Admin*!`,
        mentions: [target],
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to promote: ${err.message}` });
    }
  },
};
