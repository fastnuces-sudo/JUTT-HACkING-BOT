// ============================================
// AA MD Bot - View Warnings Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getWarns, clearWarns } = require("../../lib/database");
const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["warnings", "warns", "delwarn"],
  description: "View or clear warnings",
  category: "Admin",
  usage: ".warnings @mention | .delwarn @mention",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from, mentions, quoted } = ctx;
    const command = ctx.body?.split(" ")[0]?.replace(/[.!/#]/g, "") || "warnings";

    let target = mentions?.[0] || quoted?.sender;
    if (!target) {
      return sock.sendMessage(from, { text: "⚠️ Please mention or reply to a member." });
    }

    if (command === "delwarn") {
      clearWarns(from, target);
      return sock.sendMessage(from, {
        text: `✅ Warnings cleared for @${cleanJid(target)}.`,
        mentions: [target],
      });
    }

    const warns = getWarns(from, target);
    await sock.sendMessage(from, {
      text: `⚠️ *Warnings for @${cleanJid(target)}:* ${warns}/3`,
      mentions: [target],
    });
  },
};
