// ============================================
// AA MD Bot - Mute/Unmute Group Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["mute", "lock"],
  description: "Mute the group (only admins can send messages)",
  category: "Admin",
  usage: ".mute",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;
    try {
      await sock.groupSettingUpdate(from, "announcement");
      await sock.sendMessage(from, { text: "🔇 Group has been *muted*. Only admins can send messages." });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to mute: ${err.message}` });
    }
  },
};
