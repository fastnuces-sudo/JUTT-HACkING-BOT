// ============================================
// AA MD Bot - Kick Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["kick", "remove"],
  description: "Kick a member from the group",
  category: "Admin",
  usage: ".kick @mention",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx, args }) {
    const { from, mentions, quoted } = ctx;

    let targets = [];

    if (mentions && mentions.length > 0) {
      targets = mentions;
    } else if (quoted?.sender) {
      targets = [quoted.sender];
    } else if (args[0]) {
      const num = args[0].replace(/[^0-9]/g, "");
      targets = [`${num}@s.whatsapp.net`];
    }

    if (!targets.length) {
      return sock.sendMessage(from, {
        text: "⚠️ Please mention or reply to someone to kick.",
      });
    }

    for (const target of targets) {
      try {
        await sock.groupParticipantsUpdate(from, [target], "remove");
        await sock.sendMessage(from, {
          text: `✅ @${cleanJid(target)} has been kicked.`,
          mentions: [target],
        });
      } catch (err) {
        await sock.sendMessage(from, {
          text: `❌ Failed to kick @${cleanJid(target)}: ${err.message}`,
          mentions: [target],
        });
      }
    }
  },
};
