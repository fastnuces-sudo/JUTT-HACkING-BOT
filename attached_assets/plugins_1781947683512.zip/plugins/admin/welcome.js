// ============================================
// AA MD Bot - Welcome System Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting, updateGroup, getGroup } = require("../../lib/database");

module.exports = {
  command: ["welcome", "setwelcome"],
  description: "Enable/disable welcome messages or set custom welcome",
  category: "Admin",
  usage: ".welcome on/off | .setwelcome <message>",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const command = ctx.body.split(" ")[0].replace(/[.!/#]/g, "");

    if (command === "setwelcome") {
      const msg = args.join(" ");
      if (!msg) {
        return sock.sendMessage(from, {
          text: "⚠️ Provide a custom welcome message.\nUse {name} for member name, {group} for group name.",
        });
      }
      const group = getGroup(from);
      updateGroup(from, { welcomeMsg: msg });
      return sock.sendMessage(from, { text: `✅ Welcome message updated:\n\n${msg}` });
    }

    const toggle = args[0]?.toLowerCase();
    if (!toggle || !["on", "off"].includes(toggle)) {
      const current = getGroupSetting(from, "welcome");
      return sock.sendMessage(from, {
        text: `ℹ️ Welcome messages are currently *${current ? "ON" : "OFF"}*\nUse .welcome on/off to toggle.`,
      });
    }

    const value = toggle === "on";
    setGroupSetting(from, "welcome", value);
    await sock.sendMessage(from, {
      text: `✅ Welcome messages are now *${value ? "ON" : "OFF"}*`,
    });
  },
};
