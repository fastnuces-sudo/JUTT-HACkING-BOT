// ============================================
// AA MD Bot - Resize Image Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMedia } = require("../../lib/utils");
const sharp = require("sharp");

module.exports = {
  command: ["resize"],
  description: "Resize an image to specified dimensions",
  category: "Media",
  usage: ".resize <width> <height> (reply to image)",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from, quoted, message, messageType } = ctx;

    let imgMsg = null;

    if (messageType === "imageMessage") {
      imgMsg = message.imageMessage;
    } else if (quoted?.message?.imageMessage) {
      imgMsg = quoted.message.imageMessage;
    }

    if (!imgMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .resize <width> <height> (reply to image)\nExample: .resize 800 600",
      });
    }

    const width = parseInt(args[0]);
    const height = parseInt(args[1]) || width;

    if (!width || width < 1 || width > 4000) {
      return sock.sendMessage(from, { text: "⚠️ Please provide valid dimensions (1-4000)." });
    }

    try {
      const buffer = await downloadMedia(imgMsg, "image");
      const resized = await sharp(buffer)
        .resize(width, height, { fit: "cover" })
        .jpeg({ quality: 90 })
        .toBuffer();

      await sock.sendMessage(from, {
        image: resized,
        caption: `✅ *Resized to ${width}x${height}*`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Resize failed: ${err.message}` });
    }
  },
};
