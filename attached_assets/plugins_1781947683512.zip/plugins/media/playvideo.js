// ============================================
// AA MD Bot - Play Video Plugin
// Developer: Ahsan Ali | AA Mods
// Flow: Invidious → yt-dlp+cookies → API fallbacks
// Metadata: ALWAYS from YouTube
// ============================================

const YouTube = require("youtube-sr").default;
const axios   = require("axios");
const fs      = require("fs-extra");
const path    = require("path");
const { downloadVideo, formatDuration, cleanup, TEMP_DIR } = require("../../lib/ytdlp");

// ── Invidious instances (fastest first) ──────────────────────────
const INVIDIOUS = [
  "https://inv.nadeko.net",
  "https://invidious.fdn.fr",
  "https://yewtu.be",
  "https://vid.puffyan.us",
  "https://invidious.privacydev.net",
  "https://invidious.nerdvpn.de",
  "https://invidious.io.lol",
  "https://iv.datura.network",
];

function formatViews(count) {
  if (!count) return "?";
  if (count >= 1e9) return (count / 1e9).toFixed(1) + "B";
  if (count >= 1e6) return (count / 1e6).toFixed(1) + "M";
  if (count >= 1e3) return (count / 1e3).toFixed(1) + "K";
  return String(count);
}

// ── YouTube metadata (always from YouTube) ────────────────────────
async function getYouTubeMeta(query) {
  try {
    const results = await YouTube.search(query, { limit: 1, type: "video" });
    if (!results?.length) return null;
    const v = results[0];
    return {
      title:    v.title || query,
      author:   v.channel?.name || "Unknown",
      duration: formatDuration(Math.floor((v.duration || 0) / 1000)),
      views:    formatViews(v.views),
      thumbUrl: `https://img.youtube.com/vi/${v.id}/hqdefault.jpg`,
      videoUrl: `https://www.youtube.com/watch?v=${v.id}`,
      videoId:  v.id,
    };
  } catch (_) { return null; }
}

// ── Info card ─────────────────────────────────────────────────────
function buildCard(meta, source, status = "⏳ Fetching video...") {
  const srcBadge = source === "inv" ? "🔴 Invidious" : source === "ytdlp" ? "🟡 yt-dlp" : "🟢 YouTube";
  return (
    `✦✦✦✦✦✦✦✦✦✦\n` +
    `   🎬 AA MD Bot VIDEO\n` +
    `✦✦✦✦✦✦✦✦✦✦\n\n` +
    `🎥 *${meta.title}*\n` +
    `👤 ${meta.author}\n` +
    `⏱️ ${meta.duration || "?:??"} | 👁️ ${meta.views || "?"} views\n` +
    `📡 ${srcBadge}\n` +
    `\n━━━━━━━━━━━━━━\n` +
    status
  );
}

// ── Send thumbnail card ───────────────────────────────────────────
async function sendCard(sock, from, meta, source, status) {
  const card = buildCard(meta, source, status);
  if (meta.thumbUrl) {
    const res = await axios.get(meta.thumbUrl, { responseType: "arraybuffer", timeout: 8000 }).catch(() => null);
    if (res) {
      await sock.sendMessage(from, { image: Buffer.from(res.data), caption: card });
      return;
    }
  }
  await sock.sendMessage(from, { text: card });
}

// ── Search Invidious for videoId ──────────────────────────────────
async function searchInvidious(query) {
  for (const inst of INVIDIOUS) {
    try {
      const { data } = await axios.get(
        `${inst}/api/v1/search?q=${encodeURIComponent(query)}&type=video`,
        { timeout: 9000, headers: { "User-Agent": "Mozilla/5.0" } }
      );
      if (Array.isArray(data) && data[0]?.videoId) return data[0].videoId;
    } catch (_) {}
  }
  return null;
}

// ── Download video via Invidious formatStreams (muxed = audio+video) ─
async function invidiousVideo(videoId) {
  for (const inst of INVIDIOUS) {
    try {
      const { data } = await axios.get(
        `${inst}/api/v1/videos/${videoId}`,
        { timeout: 12000, headers: { "User-Agent": "Mozilla/5.0" } }
      );
      if (!data || data.error) continue;

      // formatStreams = muxed (video+audio) — prefer 480p then 360p
      const streams = data.formatStreams || [];
      const pick =
        streams.find(s => s.qualityLabel === "480p" && s.url) ||
        streams.find(s => s.qualityLabel === "360p" && s.url) ||
        streams.find(s => s.qualityLabel === "720p" && s.url) ||
        streams.find(s => s.url);

      if (!pick?.url) continue;

      const filePath = path.join(TEMP_DIR, `inv_video_${Date.now()}.mp4`);
      const res = await axios({
        method: "get", url: pick.url, responseType: "stream",
        timeout: 300000,
        headers: { "User-Agent": "Mozilla/5.0", Referer: inst },
      });
      await new Promise((resolve, reject) => {
        const out = fs.createWriteStream(filePath);
        res.data.pipe(out);
        out.on("finish", resolve);
        out.on("error", reject);
        res.data.on("error", reject);
      });

      const stat = fs.statSync(filePath);
      if (stat.size < 50 * 1024) { fs.removeSync(filePath); continue; }
      if (stat.size > 64 * 1024 * 1024) {
        fs.removeSync(filePath);
        throw new Error(`File too large (${(stat.size / 1024 / 1024).toFixed(0)}MB). WhatsApp max ~64MB.`);
      }

      console.log(`[playvideo] Invidious video via ${inst} ✓ (${(stat.size / 1024 / 1024).toFixed(1)}MB)`);
      return filePath;
    } catch (e) {
      if (e.message?.includes("too large")) throw e;
      // try next instance
    }
  }
  return null;
}

module.exports = {
  command: ["video", "playvideo", "vplay", "ytv"],
  description: "Search and send a YouTube video — Invidious → yt-dlp+cookies",
  category: "Media",
  usage: ".video <title or YouTube URL>",
  cooldown: 20000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text:
          `⚠️ *Usage:* .video <title or YouTube URL>\n\n` +
          `*Examples:*\n` +
          `• .video Naruto OST\n` +
          `• .video https://youtu.be/xxxxx`,
      });
    }

    const query  = args.join(" ");
    const isUrl  = query.startsWith("http") &&
      (query.includes("youtube.com") || query.includes("youtu.be"));

    await sock.sendMessage(from, { text: `🎬 *Searching:* ${query}...` });

    let tmpFile = null;
    let meta    = null;

    try {
      // ── Get YouTube metadata ──────────────────────────────────────
      if (isUrl) {
        const vid = query.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1];
        try {
          const v = vid ? await YouTube.getVideo(query) : null;
          meta = v ? {
            title:    v.title  || "YouTube Video",
            author:   v.channel?.name || "Unknown",
            duration: formatDuration(Math.floor((v.duration || 0) / 1000)),
            views:    formatViews(v.views),
            thumbUrl: `https://img.youtube.com/vi/${vid}/hqdefault.jpg`,
            videoUrl: query,
            videoId:  vid,
          } : { title: "YouTube Video", author: "Unknown", duration: null, views: null,
                thumbUrl: vid ? `https://img.youtube.com/vi/${vid}/hqdefault.jpg` : null,
                videoUrl: query, videoId: vid };
        } catch (_) {
          meta = { title: "YouTube Video", author: "Unknown", duration: null, views: null,
                   thumbUrl: null, videoUrl: query, videoId: null };
        }
      } else {
        meta = await getYouTubeMeta(query);
        if (!meta) {
          return sock.sendMessage(from, { text: `❌ No results found for: *${query}*\n\nTry a different keyword.` });
        }
      }

      const videoId = meta.videoId;
      const ytUrl   = meta.videoUrl;

      // ── PRIORITY 1: Invidious (fast, no cookies needed) ──────────
      let invFile = null;
      if (videoId) {
        try {
          console.log(`[playvideo] Trying Invidious for ${videoId}...`);
          invFile = await invidiousVideo(videoId);
        } catch (e) {
          if (e.message?.includes("too large")) {
            return sock.sendMessage(from, { text: `❌ ${e.message}` });
          }
          console.warn(`[playvideo] Invidious failed: ${e.message?.slice(0, 80)}`);
        }
      }

      if (invFile) {
        tmpFile = invFile;
        await sendCard(sock, from, meta, "inv", "⏳ Please wait, sending video...");
        await sock.sendMessage(from, {
          video: fs.readFileSync(tmpFile),
          mimetype: "video/mp4",
          caption: `🎬 *${meta.title}*\n👤 ${meta.author} | ⏱️ ${meta.duration || "?:??"}`,
          gifPlayback: false,
        });
        return;
      }

      // ── PRIORITY 2: yt-dlp + cookies + all API fallbacks ─────────
      console.log("[playvideo] Trying yt-dlp + cookies...");
      await sendCard(sock, from, meta, "ytdlp", "⏳ Please wait, this may take a moment...");

      const result = await downloadVideo(ytUrl, 480);
      tmpFile = result.filePath;

      await sock.sendMessage(from, {
        video: fs.readFileSync(tmpFile),
        mimetype: "video/mp4",
        caption: `🎬 *${meta.title}*\n👤 ${meta.author} | ⏱️ ${meta.duration || "?:??"}`,
        gifPlayback: false,
      });

    } catch (err) {
      console.warn(`[playvideo] All methods failed: ${err.message?.slice(0, 100)}`);
      await sock.sendMessage(from, {
        text:
          `❌ *Video Download Failed*\n\n` +
          `All servers tried — none worked for this video.\n\n` +
          `💡 *Try:*\n` +
          `• Send again — Invidious servers rotate\n` +
          `• Paste the direct YouTube link instead of title\n` +
          `• Try a shorter/different video\n` +
          `• Use *.play ${query}* to get audio only\n\n` +
          `_Reason: ${err.message?.slice(0, 80) || "unknown"}_`,
      });
    } finally {
      cleanup(tmpFile);
    }
  },
};
