// ============================================
// AA MD Bot - Compress Image Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMedia } = require("../../lib/utils");
const sharp = require("sharp");

module.exports = {
  command: ["compress", "compressimg"],
  description: "Compress an image",
  category: "Media",
  usage: ".compress [quality 1-100] (reply to image)",
  cooldown: 5000,

  async execute({ sock, ctx, args }) {
    const { from, quoted, message, messageType } = ctx;

    let imgMsg = null;

    if (messageType === "imageMessage") {
      imgMsg = message.imageMessage;
    } else if (quoted?.message?.imageMessage) {
      imgMsg = quoted.message.imageMessage;
    }

    if (!imgMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Please send or reply to an *image* with .compress",
      });
    }

    const quality = Math.min(100, Math.max(1, parseInt(args[0]) || 50));

    try {
      const buffer = await downloadMedia(imgMsg, "image");
      const originalSize = buffer.length;

      const compressed = await sharp(buffer)
        .jpeg({ quality })
        .toBuffer();

      const saving = (((originalSize - compressed.length) / originalSize) * 100).toFixed(1);

      await sock.sendMessage(from, {
        image: compressed,
        caption: `✅ *Image Compressed!*\n📊 Quality: ${quality}%\n💾 Saved: ${saving}% smaller`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Compression failed: ${err.message}` });
    }
  },
};
