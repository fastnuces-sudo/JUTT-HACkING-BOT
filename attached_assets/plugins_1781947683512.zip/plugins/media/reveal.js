// ============================================
// AA MD Bot - Reveal View-Once Plugin
// Developer: Ahsan Ali | AA Mods
// Reply to any view-once → get it as normal media
// ============================================

const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
const { getViewOnce } = require("../../lib/viewOnceCache");

async function downloadMedia(mediaMsg, mediaType) {
  const stream  = await downloadContentFromMessage(mediaMsg, mediaType);
  const chunks  = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

module.exports = {
  command: ["reveal", "rv", "unviewonce"],
  description: "Reveal a view-once photo or video (reply to it)",
  category: "Media",
  usage: ".reveal (reply to a view-once message)",

  async execute({ sock, ctx }) {
    const { from, quoted } = ctx;

    if (!quoted?.message) {
      return sock.sendMessage(from, {
        text:
          `👁️ *Reveal View-Once*\n\n` +
          `Reply to a view-once photo or video with *.reveal* to get it as a normal image/video.\n\n` +
          `━━━━━━━━━━━━━━━━━━\n` +
          `📌 Works on any view-once message received in DM or groups.`,
      });
    }

    const quotedId = quoted.key?.id || quoted.id;
    const qMsg     = quoted.message;

    // ── 1. Try viewOnceCache first (most reliable) ───────────────
    const cached = quotedId ? getViewOnce(quotedId) : null;
    const vMsg   = cached?.vMsg ||
      qMsg.viewOnceMessage?.message ||
      qMsg.viewOnceMessageV2?.message?.viewOnceMessage?.message ||
      qMsg.viewOnceMessageV2ExpiryExtension?.message?.viewOnceMessage?.message;

    if (vMsg) {
      const isImage = !!vMsg.imageMessage;
      const isVideo = !!vMsg.videoMessage;

      if (!isImage && !isVideo) {
        return sock.sendMessage(from, {
          text: "⚠️ View-once media type not supported (only photo and video).",
        });
      }

      const mediaType = isImage ? "image" : "video";
      await sock.sendMessage(from, { text: `⏳ Revealing view-once ${mediaType}...` }).catch(() => {});

      try {
        const buffer = await downloadMedia(vMsg[`${mediaType}Message`], mediaType);
        const who    = cached?.senderNum ? `+${cached.senderNum}` : "someone";
        await sock.sendMessage(from, {
          [mediaType]: buffer,
          caption: `👁️ *View-once ${mediaType === "image" ? "photo" : "video"} revealed*\n📨 From: ${who}`,
          mimetype: mediaType === "image" ? "image/jpeg" : "video/mp4",
        });
      } catch (err) {
        await sock.sendMessage(from, {
          text:
            `❌ *Could not reveal media*\n\n${err.message}\n\n` +
            `💡 This can happen if the view-once expired before the bot received it.`,
        });
      }
      return;
    }

    // ── 2. Fallback: maybe it's a regular image/video in the reply ─
    const isImage = !!qMsg.imageMessage;
    const isVideo = !!qMsg.videoMessage;

    if (!isImage && !isVideo) {
      return sock.sendMessage(from, {
        text: "⚠️ The replied message is not a view-once photo or video.",
      });
    }

    try {
      const mediaType = isImage ? "image" : "video";
      const buffer    = await downloadMedia(qMsg[`${mediaType}Message`], mediaType);
      await sock.sendMessage(from, {
        [mediaType]: buffer,
        caption: `👁️ *${mediaType === "image" ? "Image" : "Video"} revealed*`,
        mimetype: mediaType === "image" ? "image/jpeg" : "video/mp4",
      });
    } catch (e) {
      await sock.sendMessage(from, { text: `❌ Could not download media: ${e.message}` });
    }
  },
};
