// ============================================
// AA MD Bot - Send Audio File Plugin
// Developer: Ahsan Ali | AA Mods
// Sends audio from a direct URL for playback
// ============================================

const axios = require("axios");

module.exports = {
  command: ["sendaudio", "playurl", "audiourl"],
  description: "Send an audio file from a direct URL for playback",
  category: "Media",
  usage: ".sendaudio <direct audio URL>",
  cooldown: 10000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0] || !args[0].startsWith("http")) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .sendaudio <direct audio URL>\nExample: .sendaudio https://example.com/audio.mp3\n\n_URL must be a direct link to an audio file (mp3, ogg, wav, m4a, etc.)_",
      });
    }

    const url = args[0];
    await sock.sendMessage(from, { text: "🎵 Fetching audio..." });

    try {
      // Detect format from URL
      const ext = url.split("?")[0].split(".").pop().toLowerCase();
      const mimeMap = {
        mp3: "audio/mpeg",
        ogg: "audio/ogg",
        wav: "audio/wav",
        m4a: "audio/mp4",
        aac: "audio/aac",
        opus: "audio/opus",
        flac: "audio/flac",
      };
      const mimetype = mimeMap[ext] || "audio/mpeg";

      // Validate it's actually accessible
      await axios.head(url, { timeout: 10000 });

      await sock.sendMessage(from, {
        audio: { url },
        mimetype,
        ptt: false,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to send audio: ${err.message}` });
    }
  },
};
