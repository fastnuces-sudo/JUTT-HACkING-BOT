// ============================================
// AA MD Bot - Sticker Maker Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMedia } = require("../../lib/utils");
const sharp = require("sharp");
const config = require("../../config");
const path = require("path");
const fs = require("fs-extra");

module.exports = {
  command: ["sticker", "s", "stiker"],
  description: "Convert image/video to sticker",
  category: "Media",
  usage: ".sticker (reply to image/video)",
  cooldown: 5000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let mediaMsg = null;
    let mediaType = null;

    // Check if it's a direct image/video or quoted
    if (messageType === "imageMessage") {
      mediaMsg = message.imageMessage;
      mediaType = "image";
    } else if (messageType === "videoMessage" && message.videoMessage?.seconds <= 10) {
      mediaMsg = message.videoMessage;
      mediaType = "video";
    } else if (quoted) {
      const qType = Object.keys(quoted.message)[0];
      if (qType === "imageMessage") {
        mediaMsg = quoted.message.imageMessage;
        mediaType = "image";
      } else if (qType === "videoMessage" && quoted.message.videoMessage?.seconds <= 10) {
        mediaMsg = quoted.message.videoMessage;
        mediaType = "video";
      }
    }

    if (!mediaMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Please send or reply to an *image* or *short video* (max 10s) with .sticker",
      });
    }

    try {
      await sock.sendMessage(from, { text: "🎨 Creating sticker..." });

      const buffer = await downloadMedia(mediaMsg, mediaType);

      if (mediaType === "image") {
        // Convert image to WebP sticker
        const webp = await sharp(buffer)
          .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
          .webp({ quality: 80 })
          .toBuffer();

        await sock.sendMessage(from, {
          sticker: webp,
        });
      } else {
        // For video, send as animated sticker (webp)
        // Save as temp and use ffmpeg if available
        const tmpIn = path.join(config.tempPath, `sticker_${Date.now()}.mp4`);
        const tmpOut = path.join(config.tempPath, `sticker_${Date.now()}.webp`);
        await fs.writeFile(tmpIn, buffer);

        const { exec } = require("child_process");
        await new Promise((resolve, reject) => {
          exec(
            `ffmpeg -i ${tmpIn} -vcodec libwebp -filter:v fps=15 -lossless 0 -compression_level 3 -q:v 70 -loop 0 -preset default -an -vsync 0 -s 512:512 ${tmpOut}`,
            (err) => (err ? reject(err) : resolve())
          );
        });

        const webpBuffer = await fs.readFile(tmpOut);
        await sock.sendMessage(from, { sticker: webpBuffer });

        await fs.remove(tmpIn);
        await fs.remove(tmpOut);
      }
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to create sticker: ${err.message}` });
    }
  },
};
