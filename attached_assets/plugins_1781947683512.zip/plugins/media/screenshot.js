// ============================================
// AA MD Bot - Screenshot Plugin
// Developer: Ahsan Ali | AA Mods
// Microlink (fresh) + thum.io fallback
// ============================================

const axios = require("axios");

async function fetchScreenshot(targetUrl) {
  // ── Method 1: Microlink.io — always fresh, reliable ──────────
  try {
    const res = await axios.get(
      `https://api.microlink.io/?url=${encodeURIComponent(targetUrl)}&screenshot=true&meta=false&embed=screenshot.url`,
      {
        timeout: 20000,
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
      }
    );
    const ssUrl = res.data?.data?.screenshot?.url || (typeof res.data === "string" && res.data.startsWith("http") ? res.data : null);
    if (ssUrl) {
      const imgRes = await axios.get(ssUrl, {
        responseType: "arraybuffer",
        timeout: 20000,
        headers: { "User-Agent": "Mozilla/5.0" },
      });
      const buf = Buffer.from(imgRes.data);
      if (buf.length > 5000) return buf;
    }
  } catch (_) {}

  // ── Method 2: thum.io — free, no key ────────────────────────
  try {
    const res = await axios.get(
      `https://image.thum.io/get/width/1280/crop/800/${targetUrl}`,
      {
        responseType: "arraybuffer",
        timeout: 25000,
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
        maxRedirects: 5,
      }
    );
    const buf = Buffer.from(res.data);
    if (buf.length > 5000 && (buf[0] === 0xff || buf[0] === 0x89 || buf[0] === 0x47)) {
      return buf;
    }
  } catch (_) {}

  // ── Method 3: screenshotmachine ──────────────────────────────
  try {
    const res = await axios.get(
      `https://api.screenshotmachine.com/?key=3dd785&url=${encodeURIComponent(targetUrl)}&dimension=1366x768&format=jpg&timeout=5000`,
      { responseType: "arraybuffer", timeout: 20000 }
    );
    const buf = Buffer.from(res.data);
    if (buf.length > 5000) return buf;
  } catch (_) {}

  return null;
}

module.exports = {
  command: ["screenshot", "ss", "webss"],
  description: "Take a screenshot of a website",
  category: "Media",
  usage: ".ss <URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .ss <URL>\nExample: .ss https://google.com",
      });
    }

    let url = args[0];
    if (!url.startsWith("http")) url = `https://${url}`;

    try { new URL(url); } catch {
      return sock.sendMessage(from, { text: "❌ Invalid URL provided." });
    }

    await sock.sendMessage(from, { text: `📸 Taking screenshot of *${url}*...` });

    try {
      const imgBuf = await fetchScreenshot(url);
      if (!imgBuf) throw new Error("All screenshot services failed.");

      await sock.sendMessage(from, {
        image: imgBuf,
        caption: `📸 *Screenshot*\n🔗 ${url}\n\n_AA MD Bot_`,
      });
    } catch (err) {
      await sock.sendMessage(from, {
        text:
          `❌ Could not screenshot: *${url}*\n\n` +
          `Possible reasons:\n` +
          `• Site blocks bots/iframe\n` +
          `• Invalid or inaccessible URL\n\n` +
          `💡 Try: .ss https://google.com`,
      });
    }
  },
};
