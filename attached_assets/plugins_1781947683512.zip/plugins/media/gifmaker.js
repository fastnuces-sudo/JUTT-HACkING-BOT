// ============================================
// AA MD Bot - GIF Maker Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMediaToFile } = require("../../lib/utils");
const { exec } = require("child_process");
const fs = require("fs-extra");
const path = require("path");
const config = require("../../config");

module.exports = {
  command: ["gif", "gifmaker", "togif"],
  description: "Convert a video to GIF",
  category: "Media",
  usage: ".gif (reply to short video)",
  cooldown: 15000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let vidMsg = null;
    if (messageType === "videoMessage") {
      vidMsg = message.videoMessage;
    } else if (quoted?.message?.videoMessage) {
      vidMsg = quoted.message.videoMessage;
    }

    if (!vidMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Reply to a *short video* with .gif",
      });
    }

    if (vidMsg.seconds > 15) {
      return sock.sendMessage(from, { text: "⚠️ Video must be 15 seconds or less." });
    }

    await sock.sendMessage(from, { text: "🎬 Converting to GIF..." });

    try {
      const tmpIn = await downloadMediaToFile(vidMsg, "video", "mp4");
      const tmpOut = path.join(config.tempPath, `gif_${Date.now()}.gif`);

      await new Promise((resolve, reject) => {
        exec(
          `ffmpeg -i ${tmpIn} -vf "fps=10,scale=480:-1:flags=lanczos" -loop 0 ${tmpOut}`,
          { timeout: 30000 },
          (err) => (err ? reject(err) : resolve())
        );
      });

      const gifBuffer = await fs.readFile(tmpOut);
      await sock.sendMessage(from, {
        video: gifBuffer,
        gifPlayback: true,
        caption: "🎬 *GIF Created by AA MD Bot*",
        mimetype: "video/mp4",
      });

      await fs.remove(tmpIn);
      await fs.remove(tmpOut);
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ GIF creation failed: ${err.message}` });
    }
  },
};
