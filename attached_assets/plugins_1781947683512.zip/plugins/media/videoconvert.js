// ============================================
// AA MD Bot - Video Convert Plugin
// Developer: Ahsan Ali | AA Mods
// Re-encodes video for guaranteed WhatsApp playback
// ============================================

const { downloadMediaToFile } = require("../../lib/utils");
const { exec } = require("child_process");
const fs = require("fs-extra");
const path = require("path");
const config = require("../../config");

module.exports = {
  command: ["videoconvert", "fixvideo", "convertvideo"],
  description: "Re-encode a video for guaranteed WhatsApp playback",
  category: "Media",
  usage: ".videoconvert (reply to a video)",
  cooldown: 20000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let vidMsg = null;
    if (messageType === "videoMessage") {
      vidMsg = message.videoMessage;
    } else if (quoted?.message?.videoMessage) {
      vidMsg = quoted.message.videoMessage;
    }

    if (!vidMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Reply to a *video* with .videoconvert",
      });
    }

    await sock.sendMessage(from, { text: "🎬 Converting video for WhatsApp playback..." });

    let tmpIn = null;
    let tmpOut = null;
    try {
      tmpIn = await downloadMediaToFile(vidMsg, "video", "mp4");
      tmpOut = path.join(config.tempPath, `converted_${Date.now()}.mp4`);

      // Re-encode to H.264 + AAC — guaranteed WhatsApp compatibility
      await new Promise((resolve, reject) => {
        exec(
          `ffmpeg -i "${tmpIn}" -c:v libx264 -preset fast -crf 28 -c:a aac -b:a 128k -movflags +faststart -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" "${tmpOut}" -y`,
          { timeout: 120000 },
          (err) => (err ? reject(err) : resolve())
        );
      });

      const videoBuffer = await fs.readFile(tmpOut);
      await sock.sendMessage(from, {
        video: videoBuffer,
        mimetype: "video/mp4",
        caption: "✅ *Video converted for WhatsApp playback!*",
        gifPlayback: false,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Conversion failed: ${err.message}` });
    } finally {
      if (tmpIn) await fs.remove(tmpIn).catch(() => {});
      if (tmpOut) await fs.remove(tmpOut).catch(() => {});
    }
  },
};
