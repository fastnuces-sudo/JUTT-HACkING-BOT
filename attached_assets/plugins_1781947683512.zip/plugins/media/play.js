// ============================================
// AA MD Bot - Play Audio Plugin
// Developer: Ahsan Ali | AA Mods
// Flow: SoundCloud → Invidious → yt-dlp+cookies
// Metadata: ALWAYS from YouTube
// ============================================

const YouTube = require("youtube-sr").default;
const axios   = require("axios");
const fs      = require("fs-extra");
const path    = require("path");
const config  = require("../../config");
const { downloadSoundCloud, downloadAudio, formatDuration, cleanup, TEMP_DIR } = require("../../lib/ytdlp");

const LINK = config.channelLink || "https://wa.me/923346741532";

// ── Invidious instances (fastest first) ──────────────────────────
const INVIDIOUS = [
  "https://inv.nadeko.net",
  "https://invidious.fdn.fr",
  "https://yewtu.be",
  "https://vid.puffyan.us",
  "https://invidious.privacyredirect.com",
  "https://invidious.nerdvpn.de",
  "https://invidious.io.lol",
  "https://iv.datura.network",
];

// ── Always fetch YouTube metadata ─────────────────────────────────
async function getYouTubeMeta(query) {
  try {
    const results = await YouTube.search(query, { limit: 1, type: "video" });
    if (!results?.length) return null;
    const v = results[0];
    const durationSec = Math.floor((v.duration || 0) / 1000);
    return {
      title:    v.title  || query,
      author:   v.channel?.name || "Unknown",
      duration: formatDuration(durationSec),
      views:    v.views ? Number(v.views).toLocaleString() : null,
      thumbUrl: `https://img.youtube.com/vi/${v.id}/hqdefault.jpg`,
      videoUrl: `https://www.youtube.com/watch?v=${v.id}`,
      videoId:  v.id,
    };
  } catch (_) { return null; }
}

// ── Info card ─────────────────────────────────────────────────────
function buildCard(meta, source) {
  const srcBadge = source === "sc" ? "🟠 SoundCloud" : source === "inv" ? "🔴 Invidious" : "🟢 YouTube";
  return (
    `✦✦✦✦✦✦✦✦✦✦\n` +
    `   🎧 AA MD Bot MUSIC\n` +
    `✦✦✦✦✦✦✦✦✦✦\n\n` +
    `🎬 *${meta.title}*\n` +
    `👤 ${meta.author}\n` +
    (meta.views    ? `👁️ ${meta.views} views\n` : "") +
    (meta.duration ? `⏱️ ${meta.duration}\n`    : "") +
    `📡 ${srcBadge}\n` +
    `\n━━━━━━━━━━━━━━\n` +
    `🌐 ${LINK}\n` +
    `⏳ Sending audio...`
  );
}

// ── Send thumbnail card ───────────────────────────────────────────
async function sendCard(sock, from, meta, source) {
  const card = buildCard(meta, source);
  if (meta.thumbUrl) {
    const res = await axios.get(meta.thumbUrl, { responseType: "arraybuffer", timeout: 8000 }).catch(() => null);
    if (res) {
      await sock.sendMessage(from, { image: Buffer.from(res.data), caption: card });
      return;
    }
  }
  await sock.sendMessage(from, { text: card });
}

// ── Search Invidious for a videoId ────────────────────────────────
async function searchInvidious(query) {
  for (const inst of INVIDIOUS) {
    try {
      const { data } = await axios.get(
        `${inst}/api/v1/search?q=${encodeURIComponent(query)}&type=video`,
        { timeout: 9000, headers: { "User-Agent": "Mozilla/5.0" } }
      );
      if (Array.isArray(data) && data[0]?.videoId) return data[0].videoId;
    } catch (_) {}
  }
  return null;
}

// ── Download best audio via Invidious ────────────────────────────
async function invidiousAudio(videoId) {
  for (const inst of INVIDIOUS) {
    try {
      const { data } = await axios.get(
        `${inst}/api/v1/videos/${videoId}`,
        { timeout: 12000, headers: { "User-Agent": "Mozilla/5.0" } }
      );
      if (!data || data.error) continue;

      const formats = data.adaptiveFormats || [];
      const audio =
        formats.filter(f => f.type?.includes("audio/mp4") && f.url).sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0] ||
        formats.filter(f => f.type?.includes("audio/")  && f.url).sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];

      if (!audio?.url) continue;

      // Download to temp file
      const filePath = path.join(TEMP_DIR, `inv_audio_${Date.now()}.mp3`);
      const res = await axios({ method: "get", url: audio.url, responseType: "stream",
        timeout: 120000, headers: { "User-Agent": "Mozilla/5.0", Referer: inst } });
      await new Promise((resolve, reject) => {
        const out = fs.createWriteStream(filePath);
        res.data.pipe(out);
        out.on("finish", resolve);
        out.on("error", reject);
        res.data.on("error", reject);
      });

      const stat = fs.statSync(filePath);
      if (stat.size < 1024) { fs.removeSync(filePath); continue; }

      console.log(`[play] Invidious audio via ${inst} ✓`);
      return filePath;
    } catch (_) {}
  }
  return null;
}

module.exports = {
  command: ["play", "song", "audio", "music"],
  description: "Search and play audio — SoundCloud → Invidious → YouTube",
  category: "Media",
  usage: ".play <song name or YouTube URL>",
  cooldown: 15000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args.length) {
      return sock.sendMessage(from, {
        text:
          `⚠️ *Usage:* .play <song name>\n\n` +
          `*Examples:*\n` +
          `• .play Tum Hi Ho Arijit Singh\n` +
          `• .play Abbas Jo Zinda Ha Noha\n` +
          `• .play https://youtube.com/watch?v=...`,
      });
    }

    const query   = args.join(" ");
    const isYtUrl = query.startsWith("http") &&
      (query.includes("youtube.com") || query.includes("youtu.be"));

    await sock.sendMessage(from, { text: `🎵 *Searching:* ${query}...` });

    let tmpFile = null;

    // ══════════════════════════════════════════════════
    // DIRECT YOUTUBE URL
    // ══════════════════════════════════════════════════
    if (isYtUrl) {
      const vid = query.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)?.[1];
      const meta = {
        title: "YouTube Audio", author: "Unknown", duration: null, views: null,
        thumbUrl: vid ? `https://img.youtube.com/vi/${vid}/hqdefault.jpg` : null,
        videoId: vid, videoUrl: query,
      };

      // Try to get real metadata
      try {
        const v = vid ? await YouTube.getVideo(query) : null;
        if (v) {
          meta.title    = v.title  || meta.title;
          meta.author   = v.channel?.name || meta.author;
          meta.duration = formatDuration(Math.floor((v.duration || 0) / 1000));
          meta.views    = v.views ? Number(v.views).toLocaleString() : null;
        }
      } catch (_) {}

      try {
        // Step 1: Invidious
        if (vid) {
          const invFile = await invidiousAudio(vid);
          if (invFile) {
            tmpFile = invFile;
            await sendCard(sock, from, meta, "inv");
            await sock.sendMessage(from, { audio: fs.readFileSync(tmpFile), mimetype: "audio/mpeg", ptt: false });
            return cleanup(tmpFile);
          }
        }
        // Step 2: yt-dlp + cookies + all API fallbacks
        const result = await downloadAudio(query);
        tmpFile = result.filePath;
        await sendCard(sock, from, meta, "yt");
        await sock.sendMessage(from, { audio: fs.readFileSync(tmpFile), mimetype: result.mimetype, ptt: false });
      } catch (err) {
        await sock.sendMessage(from, { text: `❌ *Download Failed*\n\n${err.message}` });
      } finally {
        cleanup(tmpFile);
      }
      return;
    }

    // ══════════════════════════════════════════════════
    // SEARCH QUERY — fetch YouTube metadata in parallel
    // ══════════════════════════════════════════════════
    const [ytMetaResult, scResult] = await Promise.allSettled([
      getYouTubeMeta(query),
      downloadSoundCloud(query),
    ]);

    const ytMeta = ytMetaResult.status === "fulfilled" ? ytMetaResult.value : null;

    // ── PRIORITY 1: SoundCloud ────────────────────────────────────
    if (scResult.status === "fulfilled") {
      try {
        tmpFile = scResult.value.filePath;
        const meta = ytMeta || {
          title:    scResult.value.scTitle  || query,
          author:   scResult.value.scAuthor || "Unknown",
          duration: scResult.value.scDuration || null,
          views:    null,
          thumbUrl: scResult.value.scThumb  || (ytMeta?.thumbUrl ?? null),
        };
        await sendCard(sock, from, meta, "sc");
        await sock.sendMessage(from, { audio: fs.readFileSync(tmpFile), mimetype: "audio/mpeg", ptt: false });
        cleanup(tmpFile);
        return;
      } catch (e) {
        console.warn(`[play] SoundCloud send failed: ${e.message.slice(0, 80)}`);
        cleanup(tmpFile);
        tmpFile = null;
      }
    } else {
      console.warn(`[play] SoundCloud failed: ${scResult.reason?.message?.slice(0, 80)}`);
    }

    // From here on — SoundCloud failed, use YouTube metadata
    const meta    = ytMeta || { title: query, author: "Unknown", duration: null, views: null, thumbUrl: null };
    const videoId = ytMeta?.videoId || null;
    const ytUrl   = ytMeta?.videoUrl || null;

    // ── PRIORITY 2: Invidious audio ───────────────────────────────
    if (videoId) {
      try {
        console.log("[play] Trying Invidious audio...");
        const invFile = await invidiousAudio(videoId);
        if (invFile) {
          tmpFile = invFile;
          await sendCard(sock, from, meta, "inv");
          await sock.sendMessage(from, { audio: fs.readFileSync(tmpFile), mimetype: "audio/mpeg", ptt: false });
          cleanup(tmpFile);
          return;
        }
      } catch (e) {
        console.warn(`[play] Invidious audio failed: ${e.message.slice(0, 80)}`);
        cleanup(tmpFile);
        tmpFile = null;
      }
    }

    // ── PRIORITY 3: yt-dlp + cookies + API fallbacks ──────────────
    if (ytUrl) {
      try {
        console.log("[play] Trying yt-dlp + cookies...");
        const result = await downloadAudio(ytUrl);
        tmpFile = result.filePath;
        await sendCard(sock, from, meta, "yt");
        await sock.sendMessage(from, { audio: fs.readFileSync(tmpFile), mimetype: result.mimetype, ptt: false });
        cleanup(tmpFile);
        return;
      } catch (e) {
        console.warn(`[play] yt-dlp failed: ${e.message.slice(0, 80)}`);
        cleanup(tmpFile);
        tmpFile = null;
      }
    }

    // ── All sources exhausted ─────────────────────────────────────
    await sock.sendMessage(from, {
      text:
        `❌ *Song Not Found*\n\n` +
        `Tried SoundCloud, Invidious & YouTube — nothing worked for *${query}*.\n\n` +
        `💡 *Tips:*\n` +
        `• Add artist name — *.play Tum Hi Ho Arijit Singh*\n` +
        `• Paste a direct YouTube link\n` +
        `• Try alternate spelling or shorter title`,
    });
  },
};
