// ============================================
// AA MD Bot - Sticker to Image Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMedia } = require("../../lib/utils");
const sharp = require("sharp");

module.exports = {
  command: ["toimage", "toimg", "stickertoimage"],
  description: "Convert a sticker to an image",
  category: "Media",
  usage: ".toimage (reply to sticker)",
  cooldown: 5000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let stickerMsg = null;

    if (messageType === "stickerMessage") {
      stickerMsg = message.stickerMessage;
    } else if (quoted?.message?.stickerMessage) {
      stickerMsg = quoted.message.stickerMessage;
    }

    if (!stickerMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Please reply to a *sticker* with .toimage",
      });
    }

    try {
      const buffer = await downloadMedia(stickerMsg, "sticker");
      const png = await sharp(buffer).png().toBuffer();
      await sock.sendMessage(from, {
        image: png,
        caption: "🖼️ Sticker converted to image!",
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to convert: ${err.message}` });
    }
  },
};
