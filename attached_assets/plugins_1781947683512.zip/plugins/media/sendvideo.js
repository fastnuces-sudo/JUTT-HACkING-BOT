// ============================================
// AA MD Bot - Send Video File Plugin
// Developer: Ahsan Ali | AA Mods
// Sends video from a direct URL for playback
// ============================================

const axios = require("axios");

module.exports = {
  command: ["sendvideo", "videourl", "vurl"],
  description: "Send a video from a direct URL for playback",
  category: "Media",
  usage: ".sendvideo <direct video URL>",
  cooldown: 10000,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0] || !args[0].startsWith("http")) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .sendvideo <direct video URL>\nExample: .sendvideo https://example.com/video.mp4\n\n_URL must be a direct link to a video file (mp4, mov, avi, etc.)_",
      });
    }

    const url = args[0];
    await sock.sendMessage(from, { text: "🎬 Fetching video..." });

    try {
      const ext = url.split("?")[0].split(".").pop().toLowerCase();
      const mimeMap = {
        mp4: "video/mp4",
        mov: "video/quicktime",
        avi: "video/x-msvideo",
        mkv: "video/x-matroska",
        webm: "video/webm",
      };
      const mimetype = mimeMap[ext] || "video/mp4";

      await axios.head(url, { timeout: 10000 });

      await sock.sendMessage(from, {
        video: { url },
        mimetype,
        caption: "🎬 *Sent by AA MD Bot*",
        gifPlayback: false,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to send video: ${err.message}` });
    }
  },
};
