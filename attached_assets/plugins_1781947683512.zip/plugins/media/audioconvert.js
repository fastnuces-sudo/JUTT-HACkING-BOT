// ============================================
// AA MD Bot - Audio Converter (to voice note) Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { downloadMediaToFile } = require("../../lib/utils");
const { execFile } = require("child_process");
const fs = require("fs-extra");
const path = require("path");
const config = require("../../config");

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    execFile("ffmpeg", args, { timeout: 60000 }, (err, stdout, stderr) => {
      if (err) {
        reject(new Error(stderr?.slice(-200) || err.message));
      } else {
        resolve();
      }
    });
  });
}

module.exports = {
  command: ["toaudio", "tovoice", "audioconvert"],
  description: "Convert audio/video to voice note",
  category: "Media",
  usage: ".toaudio (reply to audio/video)",
  cooldown: 10000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;

    let mediaMsg = null;
    let mediaType = null;

    if (messageType === "audioMessage") {
      mediaMsg = message.audioMessage;
      mediaType = "audio";
    } else if (messageType === "videoMessage") {
      mediaMsg = message.videoMessage;
      mediaType = "video";
    } else if (quoted?.message?.audioMessage) {
      mediaMsg = quoted.message.audioMessage;
      mediaType = "audio";
    } else if (quoted?.message?.videoMessage) {
      mediaMsg = quoted.message.videoMessage;
      mediaType = "video";
    }

    if (!mediaMsg) {
      return sock.sendMessage(from, {
        text: "⚠️ Reply to an *audio* or *video* message with *.toaudio*",
      });
    }

    await sock.sendMessage(from, { text: "🎵 _Converting to voice note..._" });

    let tmpIn = null;
    let tmpOut = null;

    try {
      const ext = mediaType === "video" ? "mp4" : "mp3";
      tmpIn  = await downloadMediaToFile(mediaMsg, mediaType, ext);
      tmpOut = path.join(config.tempPath, `voicenote_${Date.now()}.ogg`);

      // Convert to OGG/Opus — the format WhatsApp voice notes use
      await runFfmpeg([
        "-y",
        "-i", tmpIn,
        "-vn",
        "-ar", "48000",
        "-ac", "1",
        "-c:a", "libopus",
        "-b:a", "64k",
        tmpOut,
      ]);

      const audioBuffer = await fs.readFile(tmpOut);

      if (!audioBuffer || audioBuffer.byteLength < 100) {
        throw new Error("Converted file is empty.");
      }

      await sock.sendMessage(from, {
        audio: audioBuffer,
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
      });
    } catch (err) {
      console.error("[toaudio] Error:", err.message);
      await sock.sendMessage(from, {
        text: `❌ *Conversion failed.*\n\n_${err.message.slice(0, 200)}_\n\nMake sure you replied to a valid audio or video file.`,
      });
    } finally {
      if (tmpIn)  fs.remove(tmpIn).catch(() => {});
      if (tmpOut) fs.remove(tmpOut).catch(() => {});
    }
  },
};
