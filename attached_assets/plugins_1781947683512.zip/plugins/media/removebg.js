// ============================================
// AA MD Bot - Remove Background Plugin
// Developer: Ahsan Ali | AA Mods
// Multiple free providers with auto-fallback
// ============================================

const axios = require("axios");
const FormData = require("form-data");
const { downloadMedia } = require("../../lib/utils");
const config = require("../../config");

// ── Validate buffer is a real image (PNG/JPEG/WebP magic bytes) ──
function isValidImage(buf) {
  if (!buf || buf.byteLength < 5000) return false;
  // PNG: 89 50 4E 47
  if (buf[0] === 0x89 && buf[1] === 0x50) return true;
  // JPEG: FF D8 FF
  if (buf[0] === 0xFF && buf[1] === 0xD8) return true;
  // WebP: RIFF????WEBP
  if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46) return true;
  return false;
}

// ── Provider 1: remove.bg (if API key is configured) ─────────────
async function removeWithRemoveBg(buffer, apiKey) {
  const form = new FormData();
  form.append("image_file", buffer, { filename: "image.jpg", contentType: "image/jpeg" });
  form.append("size", "auto");
  const res = await axios.post("https://api.remove.bg/v1.0/removebg", form, {
    headers: { ...form.getHeaders(), "X-Api-Key": apiKey },
    responseType: "arraybuffer",
    timeout: 35000,
  });
  const buf = Buffer.from(res.data);
  if (!isValidImage(buf)) throw new Error("Invalid image from remove.bg");
  return buf;
}

// ── Provider 2: HuggingFace RMBG-1.4 (not-lain space) ────────────
async function removeWithHuggingFaceNotLain(buffer) {
  const b64 = buffer.toString("base64");
  const res = await axios.post(
    "https://not-lain-background-removal.hf.space/run/predict",
    { data: [`data:image/jpeg;base64,${b64}`] },
    { headers: { "Content-Type": "application/json" }, timeout: 90000 }
  );
  const resultData = res.data?.data?.[0];
  if (!resultData) throw new Error("No result data");

  // Response is an object with url field
  if (typeof resultData === "object" && resultData?.url) {
    const imgRes = await axios.get(resultData.url, { responseType: "arraybuffer", timeout: 30000 });
    const buf = Buffer.from(imgRes.data);
    if (isValidImage(buf)) return buf;
    throw new Error("Downloaded image is invalid");
  }
  // Response is base64 string
  if (typeof resultData === "string" && resultData.includes("base64,")) {
    const buf = Buffer.from(resultData.split("base64,")[1], "base64");
    if (isValidImage(buf)) return buf;
    throw new Error("Base64 image is invalid");
  }
  throw new Error("Unknown response format from HuggingFace");
}

// ── Provider 3: HuggingFace rembg (hysts space) ───────────────────
async function removeWithHuggingFaceRembg(buffer) {
  const b64 = buffer.toString("base64");
  const res = await axios.post(
    "https://hysts-rembg.hf.space/run/predict",
    { data: [`data:image/jpeg;base64,${b64}`] },
    { headers: { "Content-Type": "application/json" }, timeout: 90000 }
  );
  const resultData = res.data?.data?.[0];
  if (!resultData) throw new Error("No result from hysts-rembg");

  let buf;
  if (typeof resultData === "string" && resultData.includes("base64,")) {
    buf = Buffer.from(resultData.split("base64,")[1], "base64");
  } else if (typeof resultData === "object" && resultData?.url) {
    const imgRes = await axios.get(resultData.url, { responseType: "arraybuffer", timeout: 30000 });
    buf = Buffer.from(imgRes.data);
  }
  if (buf && isValidImage(buf)) return buf;
  throw new Error("Invalid image from hysts-rembg");
}

// ── Provider 4: PhotoRoom sandbox ────────────────────────────────
async function removeWithPhotoRoom(buffer) {
  const form = new FormData();
  form.append("image_file", buffer, { filename: "image.jpg", contentType: "image/jpeg" });
  const res = await axios.post(
    "https://sdk.photoroom.com/v1/segment",
    form,
    {
      headers: { ...form.getHeaders(), "x-api-key": "sandbox_", Accept: "image/png" },
      responseType: "arraybuffer",
      timeout: 35000,
      validateStatus: () => true,
    }
  );
  const buf = Buffer.from(res.data);
  if (!isValidImage(buf)) throw new Error("Invalid image from PhotoRoom");
  return buf;
}

// ── Provider 5: Erase.bg ──────────────────────────────────────────
async function removeWithEraseBg(buffer) {
  const form = new FormData();
  form.append("image_file", buffer, { filename: "image.jpg", contentType: "image/jpeg" });
  const res = await axios.post("https://erase.bg/api/v1/erase", form, {
    headers: { ...form.getHeaders(), Accept: "application/json" },
    timeout: 35000,
    validateStatus: () => true,
  });
  const resultUrl = res.data?.data?.result_url || res.data?.result_url;
  if (!resultUrl) throw new Error("No result URL from erase.bg");
  const imgRes = await axios.get(resultUrl, { responseType: "arraybuffer", timeout: 25000 });
  const buf = Buffer.from(imgRes.data);
  if (!isValidImage(buf)) throw new Error("Invalid image from erase.bg");
  return buf;
}

module.exports = {
  command: ["removebg", "rmbg", "nobg"],
  description: "Remove background from an image",
  category: "Media",
  usage: ".removebg (send/reply to an image)",
  cooldown: 15000,

  async execute({ sock, ctx }) {
    const { from, quoted, message, messageType } = ctx;
    const pref = config.prefix;

    let imgMsg = null;
    if (messageType === "imageMessage") {
      imgMsg = message.imageMessage;
    } else if (quoted?.message?.imageMessage) {
      imgMsg = quoted.message.imageMessage;
    }

    if (!imgMsg) {
      return sock.sendMessage(from, {
        text:
          `⚠️ *How to use:*\n` +
          `1️⃣ Send an image with caption *${pref}removebg*\n` +
          `2️⃣ OR reply to any image with *${pref}removebg*`,
      });
    }

    await sock.sendMessage(from, { text: "🎨 Removing background, please wait..." });

    let buffer;
    try {
      buffer = await downloadMedia(imgMsg, "image");
    } catch (err) {
      return sock.sendMessage(from, { text: `❌ Could not download image: ${err.message}` });
    }

    // ── Provider list: try each until one works ──────────────────
    const providers = [];

    const apiKey = config.apiKeys?.removeBg || process.env.REMOVEBG_API_KEY;
    if (apiKey) providers.push({ name: "Remove.bg", fn: () => removeWithRemoveBg(buffer, apiKey) });

    providers.push(
      { name: "HuggingFace RMBG-1.4", fn: () => removeWithHuggingFaceNotLain(buffer) },
      { name: "HuggingFace Rembg",    fn: () => removeWithHuggingFaceRembg(buffer) },
      { name: "PhotoRoom",            fn: () => removeWithPhotoRoom(buffer) },
      { name: "Erase.bg",             fn: () => removeWithEraseBg(buffer) },
    );

    for (const provider of providers) {
      try {
        console.log(`[RemoveBG] Trying ${provider.name}...`);
        const result = await provider.fn();
        console.log(`[RemoveBG] ✅ ${provider.name} succeeded (${result.byteLength} bytes)`);
        return await sock.sendMessage(from, {
          image: result,
          mimetype: "image/png",
          caption: `✅ *Background Removed!*`,
        });
      } catch (err) {
        console.warn(`[RemoveBG] ${provider.name} failed: ${err.message.slice(0, 80)}`);
      }
    }

    await sock.sendMessage(from, {
      text:
        `❌ *Background removal failed.*\n\n` +
        `All free servers are busy right now. Please try again in a few minutes.\n\n` +
        `💡 Use *${pref}report removebg is not working* to notify the owner.`,
    });
  },
};
