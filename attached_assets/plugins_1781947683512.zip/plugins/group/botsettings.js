// ============================================
// AA MD Bot - Personal Bot Settings Plugin
// Developer: Ahsan Ali | AA Mods
// Toggle and configure bot automation settings
// ============================================

const config = require("../../config");
const { setSetting, getSetting, getAllSettings } = require("../../lib/database");

function toggle(key, value) {
  config[key] = value;
  setSetting(key, value);
}

// Also persists to per-session settings so the connected account's preferences are saved
async function toggleSess(sock, key, value) {
  toggle(key, value);
  if (sock?._sessionId) {
    try {
      const { updateSessionSettings } = require("../../lib/botEngine");
      await updateSessionSettings(sock._sessionId, { [key]: value });
    } catch {}
  }
  if (sock?._settings) sock._settings[key] = value;
}

const fmt = (v) => v ? `✅ ON` : `❌ OFF`;

module.exports = {
  command: [
    "botstatus", "bs", "botsettings", "settings",
    "mode", "autoread", "ar", "autotyping", "at", "recording",
    "statusview", "statusreact", "autoreact", "atr",
    "anticall", "anticallmsg", "antiedit", "adminaction",
    "autoreply", "setautoreply", "online", "reactemojis",
    "setprefix", "sp", "setbotname", "sbn", "cooldown", "spamprotect",
    "setownername", "son", "setwelcome", "publicwelcome", "pw",
    "savestatus", "welcomenew",
  ],
  description: "All bot settings — toggle mode, auto-features, protection & more",
  category: "Settings",
  usage: ".bs / .botstatus | .mode public/private | .autoread on/off | .setprefix . | .setwelcome on/off",
  ownerOnly: true,

  async execute({ sock, ctx, args }) {
    const { from, body } = ctx;
    const rawCmd = body.split(" ")[0].replace(/[.!/#]/g, "").toLowerCase();
    // Short aliases → normalize to canonical command name
    const CMD_ALIASES = {
      bs: "botstatus", botsettings: "botstatus", settings: "botstatus",
      ar: "autoread", at: "autotyping", atr: "autoreact",
      sp: "setprefix", sbn: "setbotname", son: "setownername",
      pw: "setwelcome", publicwelcome: "setwelcome", welcome: "setwelcome",
    };
    const cmd = CMD_ALIASES[rawCmd] ?? rawCmd;
    const arg  = (args[0] || "").toLowerCase();
    const val  = arg === "on" ? true : arg === "off" ? false : null;
    const pref = config.prefix;

    // ── .botstatus — full settings overview ───────────────────────
    if (cmd === "botstatus") {
      const s = getAllSettings();
      const botMode     = s.botMode          ?? config.botMode;
      const autoRead    = s.autoRead         ?? config.autoRead;
      const autoTyping  = s.autoTyping       ?? config.autoTyping;
      const autoRec     = s.autoRecording    ?? config.autoRecording;
      const autoReply   = s.autoReply        ?? config.autoReply;
      const statusView  = s.autoStatusView   ?? config.autoStatusView;
      const statusReact = s.autoStatusReact  ?? config.autoStatusReact;
      const reactMsg    = s.autoReactMessages ?? config.autoReactMessages;
      const reactEmoji  = s.autoReactEmoji   ?? config.autoReactEmoji;
      const antiCall    = s.antiCall         ?? config.antiCall;
      const antiEdit    = s.antiEdit         ?? config.antiEdit;
      const cooldownMs  = s.cooldown         ?? config.cooldown;
      const spamLim     = s.spamLimit        ?? config.spamLimit;
      const pubWelcome  = s.publicWelcome    ?? config.publicWelcome;
      const autoStatus  = s.autoStatus      ?? config.autoStatus  ?? false;
      const statusEmoji = s.statusEmoji     ?? config.statusEmoji ?? "❤️";
      const ownerNum = (config.ownerNumber?.[0] || "").slice(0, 5) + "xxxxxxx";
      const upSec = Math.floor(process.uptime());
      const upH = Math.floor(upSec / 3600), upM = Math.floor((upSec % 3600) / 60), upS = upSec % 60;
      const uptimeStr = `${upH}h ${upM}m ${upS}s`;
      return sock.sendMessage(from, {
        text:
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `   ⚙️  *BOT SETTINGS STATUS*\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `🤖 *Bot Name:*    ${s.botName ?? config.botName}\n` +
          `🔖 *Version:*     v${config.botVersion || "1.0.0"}\n` +
          `👨‍💻 *Developer:*   ${config.developer || "Ahsan Ali"}\n` +
          `🏷️ *Brand:*       ${config.brand || "AA Mods"}\n` +
          `🌐 *Website:*     ${config.channelLink || "https://aa-mods.vercel.app/"}\n\n` +
          `━━━━ *Owner Info* ━━━━\n` +
          `👤 *Owner Name:*  ${s.ownerName ?? config.ownerName}\n` +
          `📱 *Owner No:*    +${ownerNum}\n` +
          `🔑 *Prefix:*      ${pref}\n` +
          `🔒 *Mode:*        ${botMode === "public" ? "🌍 Public" : "🔒 Private"}\n` +
          `⏱️ *Uptime:*      ${uptimeStr}\n\n` +
          `━━━━ *Automation* ━━━━\n` +
          `👁️ Auto Read:       ${fmt(autoRead)}\n` +
          `⌨️ Auto Typing:     ${fmt(autoTyping)}\n` +
          `🎙️ Recording:       ${fmt(autoRec)}\n` +
          `💬 Auto Reply:      ${fmt(autoReply)}\n` +
          `${reactEmoji} Auto React:      ${fmt(reactMsg)} (${reactEmoji})\n` +
          `👁️ Status View:     ${fmt(statusView)}\n` +
          `${statusEmoji} Status React:    ${fmt(statusReact)} (${statusEmoji})\n` +
          `📸 Status Save:     ${fmt(autoStatus)}\n\n` +
          `━━━━ *Protection* ━━━━\n` +
          `📵 Anti Call:       ${fmt(antiCall)}\n` +
          `✏️ Anti Edit:       ${fmt(antiEdit)}\n` +
          `🌍 Public Welcome:  ${fmt(pubWelcome)}\n\n` +
          `━━━━ *Limits* ━━━━\n` +
          `⏱️ Cooldown:        ${cooldownMs}ms\n` +
          `🚫 Spam Limit:      ${spamLim} msg/10s\n\n` +
          `━━━━ *All Commands* ━━━━\n` +
          `*${pref}mode* public/private\n` +
          `*${pref}autoread / ${pref}ar* on/off\n` +
          `*${pref}autotyping / ${pref}at* on/off\n` +
          `*${pref}autoreply* on/off\n` +
          `*${pref}autoreact / ${pref}atr* on/off\n` +
          `*${pref}statusview* on/off\n` +
          `*${pref}statusreact* on/off\n` +
          `*${pref}autostatus* on/off\n` +
          `*${pref}anticall* on/off\n` +
          `*${pref}antiedit* on/off\n` +
          `*${pref}publicwelcome / ${pref}pw* on/off\n` +
          `*${pref}setprefix / ${pref}sp* <symbol>\n` +
          `*${pref}setbotname / ${pref}sbn* <name>\n` +
          `*${pref}reactemojis* <emoji>\n` +
          `*${pref}cooldown* <ms>\n` +
          `*${pref}spamprotect* <num>\n\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      });
    }

    // ── .autoread on/off ──────────────────────────────────────────
    if (cmd === "autoread") {
      if (val === null) return sock.sendMessage(from, { text: `👁️ *Auto Read* — ${fmt(config.autoRead)}\n\nUsage: *${pref}autoread on/off*` });
      toggle("autoRead", val);
      return sock.sendMessage(from, { text: `👁️ Auto Read is now *${fmt(val)}*` });
    }

    // ── .autotyping on/off ────────────────────────────────────────
    if (cmd === "autotyping") {
      if (val === null) return sock.sendMessage(from, { text: `⌨️ *Auto Typing* — ${fmt(config.autoTyping)}\n\nUsage: *${pref}autotyping on/off*` });
      toggle("autoTyping", val);
      return sock.sendMessage(from, { text: `⌨️ Auto Typing is now *${fmt(val)}*` });
    }

    // ── .recording on/off ─────────────────────────────────────────
    if (cmd === "recording") {
      if (val === null) return sock.sendMessage(from, { text: `🎙️ *Recording Status* — ${fmt(config.autoRecording)}\n\nUsage: *${pref}recording on/off*` });
      toggle("autoRecording", val);
      return sock.sendMessage(from, { text: `🎙️ Recording status is now *${fmt(val)}*` });
    }

    // ── .statusview on/off ────────────────────────────────────────
    if (cmd === "statusview") {
      if (val === null) return sock.sendMessage(from, { text: `👁️ *Auto Status View* — ${fmt(config.autoStatusView)}\n\nUsage: *${pref}statusview on/off*` });
      toggle("autoStatusView", val);
      return sock.sendMessage(from, { text: `👁️ Auto Status View is now *${fmt(val)}*` });
    }

    // ── .statusreact on/off ───────────────────────────────────────
    if (cmd === "statusreact") {
      if (val === null) return sock.sendMessage(from, { text: `❤️ *Auto Status React* — ${fmt(config.autoStatusReact)}\n\nBot reacts to statuses with an emoji.\nCurrent emoji: ${config.statusEmoji || "❤️"}\n\nUsage: *${pref}statusreact on/off*` });
      toggle("autoStatusReact", val);
      return sock.sendMessage(from, { text: `❤️ Status React is now *${fmt(val)}*` });
    }

    // ── .autoreact on/off ─────────────────────────────────────────
    if (cmd === "autoreact") {
      if (val === null) return sock.sendMessage(from, { text: `${config.autoReactEmoji} *Auto React* — ${fmt(config.autoReactMessages)}\n\nBot reacts to every incoming message.\nCurrent emoji: ${config.autoReactEmoji}\n\nUsage: *${pref}autoreact on/off*\nChange emoji: *${pref}reactemojis ❤️*` });
      toggle("autoReactMessages", val);
      return sock.sendMessage(from, { text: `${config.autoReactEmoji} Auto React is now *${fmt(val)}*` });
    }

    // ── .reactemojis <emoji> ──────────────────────────────────────
    if (cmd === "reactemojis") {
      const emoji = args[0];
      if (!emoji) return sock.sendMessage(from, { text: `😊 *Auto React Emoji* — currently: ${config.autoReactEmoji}\n\nUsage: *${pref}reactemojis ❤️*` });
      toggle("autoReactEmoji", emoji);
      return sock.sendMessage(from, { text: `😊 Auto React emoji set to *${emoji}*` });
    }

    // ── .anticall on/off ──────────────────────────────────────────
    if (cmd === "anticall") {
      if (val === null) return sock.sendMessage(from, { text: `📵 *Anti Call* — ${fmt(sock._settings?.antiCall ?? config.antiCall)}\n\nRejects all incoming WhatsApp calls automatically.\n\nUsage: *${pref}anticall on/off*\nSet message: *${pref}anticallmsg <message>*` });
      await toggleSess(sock, "antiCall", val);
      return sock.sendMessage(from, { text: `📵 Anti Call is now *${fmt(val)}*\n${val ? "All incoming calls will be rejected automatically." : "Calls will not be rejected."}` });
    }

    // ── .anticallmsg <message> ────────────────────────────────────
    if (cmd === "anticallmsg") {
      const msg = args.join(" ");
      if (!msg) return sock.sendMessage(from, { text: `💬 *Anti Call Message:*\n\n"${sock._settings?.antiCallMsg || config.antiCallMsg}"\n\nUsage: *${pref}anticallmsg <your message>*` });
      await toggleSess(sock, "antiCallMsg", msg);
      return sock.sendMessage(from, { text: `💬 Anti Call message updated:\n\n"${msg}"` });
    }

    // ── .online on/off ────────────────────────────────────────────
    if (cmd === "online") {
      if (val === null) return sock.sendMessage(from, { text: `🟢 *Always Online*\n\nUsage: *${pref}online on* — set online\n*${pref}online off* — set unavailable` });
      try {
        await sock.sendPresenceUpdate(val ? "available" : "unavailable");
        return sock.sendMessage(from, { text: `🟢 Presence set to *${val ? "Online" : "Unavailable"}*` });
      } catch {
        return sock.sendMessage(from, { text: `❌ Failed to update presence.` });
      }
    }

    // ── .mode public/private ──────────────────────────────────────
    if (cmd === "mode") {
      const m = args[0]?.toLowerCase();
      if (!m || !["public", "private"].includes(m)) {
        const cur = getSetting("botMode") ?? config.botMode;
        return sock.sendMessage(from, { text: `🔒 *Bot Mode* — currently *${cur}*\n\n• *public* — Everyone can use the bot\n• *private* — Only owner can use the bot\n\nUsage: *${pref}mode public* or *${pref}mode private*` });
      }
      await toggleSess(sock, "botMode", m);
      config.botMode = m;
      return sock.sendMessage(from, { text: `🔒 Bot Mode set to *${m === "public" ? "🌍 Public" : "🔒 Private"}*\n${m === "public" ? "Everyone can now use the bot." : "Only you (owner) can use the bot now."}` });
    }

    // ── .antiedit on/off ──────────────────────────────────────────
    if (cmd === "antiedit") {
      if (val === null) return sock.sendMessage(from, { text: `✏️ *Anti Edit* — ${fmt(config.antiEdit)}\n\nDetects when someone edits a message and shows the original.\n\nUsage: *${pref}antiedit on/off*` });
      toggle("antiEdit", val);
      return sock.sendMessage(from, { text: `✏️ Anti Edit is now *${fmt(val)}*` });
    }

    // ── .adminaction on/off ───────────────────────────────────────
    if (cmd === "adminaction") {
      if (val === null) return sock.sendMessage(from, { text: `👮 *Admin Action Notifications* — ${fmt(config.adminAction)}\n\nUsage: *${pref}adminaction on/off*` });
      toggle("adminAction", val);
      return sock.sendMessage(from, { text: `👮 Admin Action Notifications are now *${fmt(val)}*` });
    }

    // ── .autoreply on/off ─────────────────────────────────────────
    if (cmd === "autoreply") {
      if (val === null) return sock.sendMessage(from, { text: `💬 *Auto Reply* — ${fmt(config.autoReply)}\n\nCurrent message: "${config.autoReplyMessage}"\n\nUsage: *${pref}autoreply on/off*\nSet message: *${pref}setautoreply <message>*` });
      toggle("autoReply", val);
      return sock.sendMessage(from, { text: `💬 Auto Reply is now *${fmt(val)}*` });
    }

    // ── .setautoreply <message> ───────────────────────────────────
    if (cmd === "setautoreply") {
      const msg = args.join(" ");
      if (!msg) return sock.sendMessage(from, { text: `💬 *Current Auto Reply:*\n\n"${config.autoReplyMessage}"\n\nUsage: *${pref}setautoreply <message>*` });
      toggle("autoReplyMessage", msg);
      return sock.sendMessage(from, { text: `✅ Auto reply message set to:\n\n"${msg}"` });
    }

    // ── .setprefix <prefix> ───────────────────────────────────────
    if (cmd === "setprefix") {
      const newPref = args[0];
      if (!newPref || newPref.length > 3) {
        return sock.sendMessage(from, { text: `🔑 *Current Prefix:* ${pref}\n\nUsage: *${pref}setprefix .* (any symbol: . ! / # @)\n\n⚠️ Max 3 characters.` });
      }
      toggle("prefix", newPref);
      config.prefix = newPref;
      return sock.sendMessage(from, { text: `🔑 *Prefix changed to:* *${newPref}*\n\nUse *${newPref}menu* to see commands now.` });
    }

    // ── .setbotname <name> ────────────────────────────────────────
    if (cmd === "setbotname") {
      const name = args.join(" ").trim();
      if (!name) return sock.sendMessage(from, { text: `🤖 *Current Bot Name:* ${config.botName}\n\nUsage: *${pref}setbotname My Cool Bot*` });
      toggle("botName", name);
      config.botName = name;
      return sock.sendMessage(from, { text: `🤖 Bot name set to *${name}*` });
    }

    // ── .setownername <name> ──────────────────────────────────────
    if (cmd === "setownername") {
      const name = args.join(" ").trim();
      if (!name) return sock.sendMessage(from, { text: `👤 *Current Owner Name:* ${config.ownerName}\n\nUsage: *${pref}setownername Ahsan Ali*` });
      toggle("ownerName", name);
      config.ownerName = name;
      return sock.sendMessage(from, { text: `👤 Owner name set to *${name}*` });
    }

    // ── .cooldown <milliseconds> ──────────────────────────────────
    if (cmd === "cooldown") {
      const ms = parseInt(args[0]);
      if (!ms || ms < 500 || ms > 60000) {
        return sock.sendMessage(from, {
          text: `⏱️ *Command Cooldown* — currently *${config.cooldown}ms*\n\nMinimum time between commands per user.\n\nUsage: *${pref}cooldown 3000*\nRange: 500ms – 60000ms (60s)`,
        });
      }
      toggle("cooldown", ms);
      config.cooldown = ms;
      return sock.sendMessage(from, { text: `⏱️ Cooldown set to *${ms}ms* (${(ms / 1000).toFixed(1)}s)` });
    }

    // ── .spamprotect <limit> ──────────────────────────────────────
    if (cmd === "spamprotect") {
      const lim = parseInt(args[0]);
      if (!lim || lim < 2 || lim > 50) {
        return sock.sendMessage(from, {
          text: `🚫 *Spam Protection* — currently *${config.spamLimit}* messages per 10 seconds\n\nUsage: *${pref}spamprotect 5*\nRange: 2 – 50 messages`,
        });
      }
      toggle("spamLimit", lim);
      config.spamLimit = lim;
      return sock.sendMessage(from, { text: `🚫 Spam limit set to *${lim} messages* per 10 seconds` });
    }

    // ── .setwelcome / .welcomenew on/off ─────────────────────────
    if (cmd === "setwelcome" || cmd === "welcomenew") {
      if (val === null) return sock.sendMessage(from, { text: `👋 *Welcome New Users* — ${fmt(getSetting("publicWelcome") ?? config.publicWelcome)}\n\nGreets first-time users with a welcome message in DM.\n\nUsage: *${pref}welcomenew on/off*` });
      toggle("publicWelcome", val);
      return sock.sendMessage(from, { text: `👋 Welcome New Users is now *${fmt(val)}*\n${val ? "First-time users will receive a welcome message." : "Welcome message disabled."}` });
    }

    // ── .savestatus on/off ────────────────────────────────────────
    if (cmd === "savestatus") {
      const cur = getSetting("autoStatus") ?? config.autoStatus ?? false;
      if (val === null) return sock.sendMessage(from, { text: `📸 *Auto Save Status* — ${fmt(cur)}\n\nSaves others' statuses (text/image/video) to your DM.\n\nUsage: *${pref}savestatus on/off*` });
      toggle("autoStatus", val);
      return sock.sendMessage(from, { text: `📸 Auto Save Status is now *${fmt(val)}*\n${val ? "Status updates from contacts will be saved to your DM." : "Status saving disabled."}` });
    }
  },
};
