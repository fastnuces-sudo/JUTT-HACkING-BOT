// ============================================
// AA MD Bot - Group Link Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["grouplink", "link", "getlink"],
  description: "Get the group invite link",
  category: "Group",
  usage: ".grouplink",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const code = await sock.groupInviteCode(from);
      await sock.sendMessage(from, {
        text: `🔗 *Group Invite Link*\n\nhttps://chat.whatsapp.com/${code}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to get link: ${err.message}` });
    }
  },
};
