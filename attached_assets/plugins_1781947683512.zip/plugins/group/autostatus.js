// ============================================
// AA MD Bot - Auto Status Saver Plugin
// Developer: Ahsan Ali | AA Mods
// Saves & forwards WhatsApp status updates to owner DM
// ============================================

const config  = require("../../config");
const { getSetting, setSetting } = require("../../lib/database");

module.exports = {
  command: ["autostatus", "stvsave", "statussave"],
  description: "Auto save & forward status updates to your DM",
  category: "Owner",
  usage: ".autostatus on/off/status",
  ownerOnly: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const pref     = config.prefix;
    const toggle   = args[0]?.toLowerCase();
    const current  = getSetting("autoStatus") ?? false;
    const viewOn   = config.autoStatusView    ?? true;
    const reactOn  = config.autoStatusReact   ?? true;
    const reactEmoji = config.statusEmoji     || "❤️";

    if (!toggle) {
      return sock.sendMessage(from, {
        text:
          `━━━━━━━━━━━━━━━━━━━━━━━━\n` +
          `  📸  *AUTO STATUS SAVER*\n` +
          `━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
          `💾 *Save & Forward:*  ${current  ? "✅ ON"  : "❌ OFF"}\n` +
          `👁️ *Auto View:*       ${viewOn   ? "✅ ON"  : "❌ OFF"}\n` +
          `${reactEmoji} *Auto React:*      ${reactOn  ? "✅ ON"  : "❌ OFF"}\n\n` +
          `━━━━━━ *Commands* ━━━━━━\n` +
          `*${pref}autostatus on*  — Enable status saving\n` +
          `*${pref}autostatus off* — Disable status saving\n\n` +
          `*${pref}statusview on/off*   — View statuses silently\n` +
          `*${pref}statusreact on/off* — React to statuses\n` +
          `*${pref}reactemojis ❤️*     — Change react emoji\n\n` +
          `💡 When ON, every contact's status is forwarded to your own chat.`,
      });
    }

    if (toggle === "on" || toggle === "off") {
      const value = toggle === "on";
      setSetting("autoStatus", value);
      config.autoStatus = value;
      return sock.sendMessage(from, {
        text:
          `📸 *Auto Status Saver* is now *${value ? "✅ ON" : "❌ OFF"}*\n\n` +
          (value
            ? `All status updates from your contacts will be forwarded to your DM automatically.`
            : `Status forwarding disabled.`),
      });
    }

    return sock.sendMessage(from, {
      text: `❓ Usage:\n*${pref}autostatus on/off* — Toggle status saving`,
    });
  },
};
