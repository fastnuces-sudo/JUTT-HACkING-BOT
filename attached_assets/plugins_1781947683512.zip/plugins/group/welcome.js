// ============================================
// AA MD Bot - Welcome / Goodbye Settings Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting, getGroup, updateGroup } = require("../../lib/database");
const config = require("../../config");

module.exports = {
  command: ["welcome", "goodbye", "setwelcome", "setgoodbye"],
  description: "Toggle/set welcome & goodbye messages for the group",
  category: "Group",
  usage: ".welcome on/off | .setwelcome <message> | .goodbye on/off | .setgoodbye <message>",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx, args }) {
    const { from, body } = ctx;
    const cmd = body.split(" ")[0].replace(/[.!/#]/g, "").toLowerCase();
    const toggle = (args[0] || "").toLowerCase();
    const prefix = config.prefix;

    if (cmd === "welcome") {
      if (!toggle || !["on", "off"].includes(toggle)) {
        const current = getGroupSetting(from, "welcome");
        return sock.sendMessage(from, {
          text: `👋 *Welcome messages* are currently *${current ? "✅ ON" : "❌ OFF"}*\n\nUsage: *${prefix}welcome on* / *${prefix}welcome off*\nCustomize: *${prefix}setwelcome <message>*\n\n💡 Variables: {name} {group} {count}`,
        });
      }
      const value = toggle === "on";
      setGroupSetting(from, "welcome", value);
      return sock.sendMessage(from, {
        text: `👋 Welcome messages are now *${value ? "✅ ON" : "❌ OFF"}*\n${value ? "New members will receive a welcome message." : "Welcome messages are disabled."}`,
      });
    }

    if (cmd === "goodbye") {
      if (!toggle || !["on", "off"].includes(toggle)) {
        const current = getGroupSetting(from, "goodbye");
        return sock.sendMessage(from, {
          text: `👋 *Goodbye messages* are currently *${current ? "✅ ON" : "❌ OFF"}*\n\nUsage: *${prefix}goodbye on* / *${prefix}goodbye off*\nCustomize: *${prefix}setgoodbye <message>*`,
        });
      }
      const value = toggle === "on";
      setGroupSetting(from, "goodbye", value);
      return sock.sendMessage(from, {
        text: `👋 Goodbye messages are now *${value ? "✅ ON" : "❌ OFF"}*`,
      });
    }

    if (cmd === "setwelcome") {
      const msg = args.join(" ");
      if (!msg) {
        const group = getGroup(from);
        return sock.sendMessage(from, {
          text:
            `👋 *Current Welcome Message:*\n\n${group.welcomeMsg || "Welcome {name} to {group}!"}\n\n` +
            `💡 *Variables you can use:*\n` +
            `• *{name}* — New member's name\n` +
            `• *{group}* — Group name\n` +
            `• *{count}* — Total member count\n\n` +
            `Usage: *${prefix}setwelcome Welcome to {group}, {name}!*`,
        });
      }
      updateGroup(from, { welcomeMsg: msg });
      return sock.sendMessage(from, {
        text: `✅ *Welcome message updated!*\n\n${msg}\n\n💡 Variables: {name}, {group}, {count}`,
      });
    }

    if (cmd === "setgoodbye") {
      const msg = args.join(" ");
      if (!msg) {
        const group = getGroup(from);
        return sock.sendMessage(from, {
          text:
            `👋 *Current Goodbye Message:*\n\n${group.goodbyeMsg || "Goodbye {name}!"}\n\n` +
            `💡 *Variables:* {name}, {group}\n\n` +
            `Usage: *${prefix}setgoodbye Goodbye {name}! We'll miss you.`,
        });
      }
      updateGroup(from, { goodbyeMsg: msg });
      return sock.sendMessage(from, {
        text: `✅ *Goodbye message updated!*\n\n${msg}`,
      });
    }
  },
};
