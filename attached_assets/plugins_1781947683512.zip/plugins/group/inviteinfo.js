// ============================================
// AA MD Bot - Invite Info Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["inviteinfo", "joininfo"],
  description: "Get info about a WhatsApp invite link",
  category: "Group",
  usage: ".inviteinfo <group link>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    if (!args[0]) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .inviteinfo <WhatsApp group link>",
      });
    }

    const link = args[0];
    const code = link.split("chat.whatsapp.com/")[1];

    if (!code) {
      return sock.sendMessage(from, { text: "❌ Invalid WhatsApp group link." });
    }

    try {
      const info = await sock.groupGetInviteInfo(code);
      const text = `📋 *Group Invite Info*\n\n` +
        `📌 *Name:* ${info.subject}\n` +
        `👥 *Members:* ${info.size}\n` +
        `👑 *Creator:* ${info.creator?.split("@")[0] || "Unknown"}\n` +
        `📅 *Created:* ${new Date(info.creation * 1000).toLocaleDateString()}\n\n` +
        `🔗 *Link:* ${link}`;

      await sock.sendMessage(from, { text });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to fetch info: ${err.message}` });
    }
  },
};
