// ============================================
// AA MD Bot - Anti Delete Plugin
// Developer: Ahsan Ali | AA Mods
// Works in groups (per-group) and DM (global)
// ============================================

const { getGroupSetting, setGroupSetting, getSetting, setSetting } = require("../../lib/database");

module.exports = {
  command: ["antidelete", "antidel"],
  description: "Re-send deleted messages (group or your DM)",
  category: "Settings",
  usage: ".antidelete on/off",

  async execute({ sock, ctx, args }) {
    const { from, isGroup, isOwner } = ctx;
    const toggle = args[0]?.toLowerCase();

    const currentVal = isGroup
      ? (getGroupSetting(from, "antidelete") ?? getSetting("antidelete") ?? false)
      : (getSetting("antidelete") ?? false);

    if (!toggle || !["on", "off"].includes(toggle)) {
      return sock.sendMessage(from, {
        text:
          `🗑️ *Anti Delete* is currently *${currentVal ? "ON" : "OFF"}*\n\n` +
          `━━━━━━━━━━━━━━━━━━\n` +
          `*.antidelete on*  — Recover deleted messages\n` +
          `*.antidelete off* — Don't recover them\n\n` +
          (isGroup
            ? `📌 Applies to *this group only*`
            : `📌 From DM → applies to *all groups + DMs globally*`),
      });
    }

    const value = toggle === "on";

    if (isGroup) {
      setGroupSetting(from, "antidelete", value);
      await sock.sendMessage(from, {
        text:
          `🗑️ *Anti Delete* is now *${value ? "ON" : "OFF"}* for this group.\n` +
          (value ? "Deleted messages will be re-sent automatically." : "Deleted messages will stay gone."),
      });
    } else {
      if (!isOwner) {
        return sock.sendMessage(from, { text: "⚠️ Only the owner can set global anti-delete." });
      }
      setSetting("antidelete", value);
      await sock.sendMessage(from, {
        text:
          `🗑️ *Anti Delete* globally set to *${value ? "ON" : "OFF"}*.\n` +
          (value
            ? "Deleted messages will be recovered in ALL groups and DMs."
            : "Anti-delete disabled globally."),
      });
    }
  },
};
