// ============================================
// AA MD Bot - Anti View Once Plugin
// Developer: Ahsan Ali | AA Mods
// Works in groups (per-group) and DM (global)
// ============================================

const { getGroupSetting, setGroupSetting, getSetting, setSetting } = require("../../lib/database");

module.exports = {
  command: ["antiviewonce", "antiview"],
  description: "Reveal view-once media automatically",
  category: "Settings",
  usage: ".antiviewonce on/off",

  async execute({ sock, ctx, args }) {
    const { from, isGroup, isOwner } = ctx;
    const toggle = args[0]?.toLowerCase();

    const currentVal = isGroup
      ? (getGroupSetting(from, "antiviewonce") ?? getSetting("antiviewonce") ?? false)
      : (getSetting("antiviewonce") ?? false);

    if (!toggle || !["on", "off"].includes(toggle)) {
      return sock.sendMessage(from, {
        text:
          `👁️ *Anti View-Once* is currently *${currentVal ? "ON" : "OFF"}*\n\n` +
          `━━━━━━━━━━━━━━━━━━\n` +
          `*.antiviewonce on*  — Reveal view-once media\n` +
          `*.antiviewonce off* — Keep view-once hidden\n\n` +
          (isGroup
            ? `📌 Applies to *this group only*`
            : `📌 From DM → applies to *all groups + DMs globally*`) +
          `\n\n💡 Tip: Use *.reveal* while replying to any view-once to reveal it manually.`,
      });
    }

    const value = toggle === "on";

    if (isGroup) {
      setGroupSetting(from, "antiviewonce", value);
      await sock.sendMessage(from, {
        text:
          `👁️ *Anti View-Once* is now *${value ? "ON" : "OFF"}* for this group.\n` +
          (value ? "View-once media will be revealed automatically." : "View-once media will stay hidden."),
      });
    } else {
      if (!isOwner) {
        return sock.sendMessage(from, { text: "⚠️ Only the owner can set global anti-view-once." });
      }
      setSetting("antiviewonce", value);
      await sock.sendMessage(from, {
        text:
          `👁️ *Anti View-Once* globally set to *${value ? "ON" : "OFF"}*.\n` +
          (value
            ? "View-once media will be revealed in ALL groups and DMs automatically."
            : "Anti-view-once disabled globally."),
      });
    }
  },
};
