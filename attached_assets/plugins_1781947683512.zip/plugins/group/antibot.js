// ============================================
// AA MD Bot - Anti Bot Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroupSetting, setGroupSetting } = require("../../lib/database");

module.exports = {
  command: ["antibot"],
  description: "Enable/disable anti-bot (kick other bots)",
  category: "Group",
  usage: ".antibot on/off",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx, args }) {
    const { from } = ctx;
    const toggle = args[0]?.toLowerCase();

    if (!toggle || !["on", "off"].includes(toggle)) {
      const current = getGroupSetting(from, "antibot");
      return sock.sendMessage(from, {
        text: `ℹ️ Anti-bot is currently *${current ? "ON" : "OFF"}*\nUse .antibot on/off to toggle.`,
      });
    }

    const value = toggle === "on";
    setGroupSetting(from, "antibot", value);
    await sock.sendMessage(from, {
      text: `🤖 Anti-bot is now *${value ? "ON" : "OFF"}*\n${value ? "Other bots will be kicked automatically." : "Bots are allowed."}`,
    });
  },
};
