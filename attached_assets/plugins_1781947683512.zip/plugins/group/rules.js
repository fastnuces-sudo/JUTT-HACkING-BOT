// ============================================
// AA MD Bot - Group Rules Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroup, updateGroup } = require("../../lib/database");

module.exports = {
  command: ["rules", "setrules"],
  description: "Show or set group rules",
  category: "Group",
  usage: ".rules | .setrules <rules>",
  groupOnly: true,

  async execute({ sock, ctx, args }) {
    const { from, isAdmin, isOwner } = ctx;
    const command = ctx.body.split(" ")[0].replace(/[.!/#]/g, "");

    if (command === "setrules") {
      if (!isAdmin && !isOwner) {
        return sock.sendMessage(from, { text: "⚠️ Only admins can set rules." });
      }
      const rules = args.join(" ");
      if (!rules) {
        return sock.sendMessage(from, { text: "⚠️ Please provide rules text." });
      }
      updateGroup(from, { rules });
      return sock.sendMessage(from, { text: "✅ Group rules updated!" });
    }

    const group = getGroup(from);
    if (!group.rules) {
      return sock.sendMessage(from, {
        text: "📋 No rules set for this group.\nAdmins can use .setrules to set them.",
      });
    }

    await sock.sendMessage(from, {
      text: `📋 *Group Rules:*\n\n${group.rules}`,
    });
  },
};
