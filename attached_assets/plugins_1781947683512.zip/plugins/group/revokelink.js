// ============================================
// AA MD Bot - Revoke Group Link Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  command: ["revoke", "revokelink", "resetlink"],
  description: "Revoke and reset the group invite link",
  category: "Group",
  usage: ".revoke",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const newCode = await sock.groupRevokeInvite(from);
      await sock.sendMessage(from, {
        text: `✅ *Group Link Revoked!*\n\n🔗 New Link:\nhttps://chat.whatsapp.com/${newCode}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Failed to revoke link: ${err.message}` });
    }
  },
};
