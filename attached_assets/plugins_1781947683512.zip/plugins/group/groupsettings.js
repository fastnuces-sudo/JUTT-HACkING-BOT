// ============================================
// AA MD Bot - Group Settings Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { getGroup } = require("../../lib/database");

module.exports = {
  command: ["gsettings", "groupsettings", "settings"],
  description: "View group bot settings",
  category: "Group",
  usage: ".gsettings",
  groupOnly: true,
  adminOnly: true,

  async execute({ sock, ctx }) {
    const { from, groupMetadata } = ctx;
    const group = getGroup(from);
    const s = group.settings;

    const toggle = (val) => (val ? "✅ ON" : "❌ OFF");

    const text = `⚙️ *Group Bot Settings*\n📌 ${groupMetadata?.subject || from}\n\n` +
      `🌟 *Auto Features:*\n` +
      `• Welcome: ${toggle(s.welcome)}\n` +
      `• Goodbye: ${toggle(s.goodbye)}\n\n` +
      `🛡️ *Protection:*\n` +
      `• Anti-Link: ${toggle(s.antilink)}\n` +
      `• Anti-Spam: ${toggle(s.antispam)}\n` +
      `• Anti-Delete: ${toggle(s.antidelete)}\n` +
      `• Anti-ViewOnce: ${toggle(s.antiviewonce)}\n` +
      `• Anti-BadWord: ${toggle(s.antibadword)}\n` +
      `• Anti-Bot: ${toggle(s.antibot)}\n\n` +
      `💡 Use .antilink on/off, .welcome on/off, etc. to toggle.`;

    await sock.sendMessage(from, { text });
  },
};
