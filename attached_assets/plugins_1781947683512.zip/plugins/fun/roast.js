// ============================================
// AA MD Bot - Roast Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { pickRandom, cleanJid } = require("../../lib/utils");

const roasts = [
  "You're the human equivalent of a participation trophy.",
  "I'd roast you, but my parents told me not to burn trash.",
  "You're not stupid; you just have bad luck thinking.",
  "If brains were dynamite, you wouldn't have enough to blow your hat off.",
  "You're like a cloud — when you disappear, it's a beautiful day.",
  "Somewhere out there is a tree working very hard to replace the oxygen you waste.",
  "I thought of you today. It reminded me to take out the trash.",
  "You're proof that evolution can go in reverse.",
  "I'd explain it to you, but I left my kindergarten teaching certificate at home.",
  "Your face is fine but we'll have to put a bag over your personality.",
];

module.exports = {
  command: ["roast"],
  description: "Roast someone playfully",
  category: "Fun",
  usage: ".roast @mention",

  async execute({ sock, ctx }) {
    const { from, mentions, pushName } = ctx;

    const target = mentions?.[0]
      ? `@${cleanJid(mentions[0])}`
      : pushName;

    await sock.sendMessage(from, {
      text: `🔥 *Roasting ${target}:*\n\n${pickRandom(roasts)}\n\n_Just kidding! 😄_`,
      mentions: mentions || [],
    });
  },
};
