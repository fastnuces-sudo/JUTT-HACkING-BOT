// ============================================
// AA MD Bot - Ship Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { generateProgressBar, cleanJid } = require("../../lib/utils");

module.exports = {
  command: ["ship", "couple"],
  description: "Ship two people together",
  category: "Fun",
  usage: ".ship @person1 @person2",

  async execute({ sock, ctx }) {
    const { from, mentions, pushName, sender } = ctx;

    let person1, person2;

    if (mentions && mentions.length >= 2) {
      person1 = `@${cleanJid(mentions[0])}`;
      person2 = `@${cleanJid(mentions[1])}`;
    } else if (mentions && mentions.length === 1) {
      person1 = pushName;
      person2 = `@${cleanJid(mentions[0])}`;
    } else {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .ship @person1 @person2",
      });
    }

    const score = Math.floor(Math.random() * 101);
    const bar = generateProgressBar(score, 100, 12);

    let emoji = "💔";
    let comment = "Not meant to be...";
    if (score >= 80) { emoji = "💑"; comment = "Perfect match! 😍"; }
    else if (score >= 60) { emoji = "❤️"; comment = "Great couple!"; }
    else if (score >= 40) { emoji = "💛"; comment = "Could work out!"; }
    else if (score >= 20) { emoji = "🤝"; comment = "Just friends..."; }

    const text = `💘 *SHIP CALCULATOR*\n\n` +
      `👤 ${person1}\n` +
      `💕 +\n` +
      `👤 ${person2}\n\n` +
      `[${bar}] ${score}%\n\n` +
      `${emoji} *${comment}*`;

    await sock.sendMessage(from, { text, mentions });
  },
};
