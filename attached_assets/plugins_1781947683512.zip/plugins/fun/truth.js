// ============================================
// AA MD Bot - Truth or Dare Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { pickRandom } = require("../../lib/utils");

const truths = [
  "What's the most embarrassing thing you've done in public?",
  "What's your biggest secret that you've never told anyone?",
  "Have you ever lied to your best friend?",
  "What's the most childish thing you still do?",
  "What's something you've done that you're not proud of?",
  "Have you ever cheated on a test?",
  "What's your biggest fear in life?",
  "What's the weirdest dream you've ever had?",
  "Do you have a crush on anyone right now?",
  "What's the biggest lie you've ever told?",
  "What's your most embarrassing nickname?",
  "Have you ever stalked someone on social media?",
  "What's something you've never told your parents?",
  "What's the silliest thing you're afraid of?",
  "Have you ever had a crush on a teacher?",
];

const dares = [
  "Send a silly selfie to someone in your contacts right now.",
  "Do 20 pushups without stopping.",
  "Sing a nursery rhyme out loud for 30 seconds.",
  "Text your last contact 'I love you' without explanation.",
  "Do your best celebrity impression.",
  "Send a voice message saying 'I am a potato.'",
  "Change your status to something embarrassing for 1 hour.",
  "Talk in an accent for the next 5 minutes.",
  "Send a random emoji to 5 different contacts.",
  "Tell a joke and laugh at your own joke loudly.",
];

module.exports = {
  command: ["truth"],
  description: "Get a truth question",
  category: "Fun",
  usage: ".truth",

  async execute({ sock, ctx }) {
    const { from } = ctx;
    await sock.sendMessage(from, {
      text: `🎯 *Truth:*\n\n${pickRandom(truths)}`,
    });
  },
};
