// ============================================
// AA MD Bot - Number Guessing Game Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

// Active games: { jid: { number, attempts, max } }
const games = {};

module.exports = {
  command: ["guess", "numguess"],
  description: "Play a number guessing game",
  category: "Fun",
  usage: ".guess start | .guess <number>",

  async execute({ sock, ctx, args }) {
    const { from, sender } = ctx;
    const gameKey = `${from}:${sender}`;
    const action = args[0]?.toLowerCase();

    if (!action || action === "start") {
      // Start new game
      const number = Math.floor(Math.random() * 100) + 1;
      games[gameKey] = { number, attempts: 0, max: 7 };
      return sock.sendMessage(from, {
        text: `🎮 *Number Guessing Game Started!*\n\n🔢 I'm thinking of a number between *1-100*\nYou have *7 attempts*!\n\nSend .guess <your_number> to play.`,
      });
    }

    const game = games[gameKey];
    if (!game) {
      return sock.sendMessage(from, {
        text: "ℹ️ No active game. Send *.guess start* to begin!",
      });
    }

    const guess = parseInt(action);
    if (isNaN(guess) || guess < 1 || guess > 100) {
      return sock.sendMessage(from, { text: "⚠️ Please enter a valid number between 1-100." });
    }

    game.attempts++;
    const remaining = game.max - game.attempts;

    if (guess === game.number) {
      delete games[gameKey];
      return sock.sendMessage(from, {
        text: `🎉 *Correct!* You guessed it in ${game.attempts} attempts!\n\nThe number was *${game.number}*! 🏆`,
      });
    }

    if (remaining <= 0) {
      const answer = game.number;
      delete games[gameKey];
      return sock.sendMessage(from, {
        text: `😢 *Game Over!* You've used all attempts.\n\nThe number was *${answer}*.\nSend .guess start to play again!`,
      });
    }

    const hint = guess < game.number ? "⬆️ Too low!" : "⬇️ Too high!";
    await sock.sendMessage(from, {
      text: `${hint}\nAttempts left: ${remaining}\nYour guess: ${guess}`,
    });
  },
};
