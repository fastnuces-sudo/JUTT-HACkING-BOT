// ============================================
// AA MD Bot - Dare Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { pickRandom } = require("../../lib/utils");

const dares = [
  "Send a silly selfie to someone in your contacts right now.",
  "Do 20 pushups without stopping.",
  "Sing a nursery rhyme out loud for 30 seconds.",
  "Text your last contact 'I love you' without explanation.",
  "Do your best celebrity impression for 1 minute.",
  "Send a voice message saying 'I am a potato.'",
  "Change your status to something embarrassing for 1 hour.",
  "Talk in an accent for the next 5 minutes.",
  "Send a random emoji to 5 different contacts.",
  "Tell a joke and laugh at your own joke loudly.",
  "Do the chicken dance for 30 seconds.",
  "Speak only in rhymes for the next 2 minutes.",
  "Post a funny status right now and keep it for 10 minutes.",
  "Call someone and sing Happy Birthday even if it's not their birthday.",
  "Mimic a famous person and let others guess who you are.",
];

module.exports = {
  command: ["dare"],
  description: "Get a dare challenge",
  category: "Fun",
  usage: ".dare",

  async execute({ sock, ctx }) {
    const { from } = ctx;
    await sock.sendMessage(from, {
      text: `🔥 *Dare:*\n\n${pickRandom(dares)}`,
    });
  },
};
