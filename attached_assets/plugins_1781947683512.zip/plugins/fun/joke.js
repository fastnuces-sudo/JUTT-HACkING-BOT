// ============================================
// AA MD Bot - Joke Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const axios = require("axios");

module.exports = {
  command: ["joke", "jokes"],
  description: "Get a random joke",
  category: "Fun",
  usage: ".joke",

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const res = await axios.get(
        "https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,racist,sexist,explicit",
        { timeout: 10000 }
      );
      const data = res.data;

      let text = "😂 *Random Joke:*\n\n";
      if (data.type === "twopart") {
        text += `❓ ${data.setup}\n\n😄 ${data.delivery}`;
      } else {
        text += data.joke;
      }

      await sock.sendMessage(from, { text });
    } catch (err) {
      await sock.sendMessage(from, { text: "❌ Couldn't fetch a joke right now." });
    }
  },
};
