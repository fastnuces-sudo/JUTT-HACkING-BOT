// ============================================
// AA MD Bot - Meme Plugin
// Developer: Ahsan Ali | AA Mods
// Uses Reddit API
// ============================================

const axios = require("axios");

const subreddits = ["memes", "dankmemes", "AdviceAnimals", "me_irl", "wholesomememes"];

module.exports = {
  command: ["meme", "randommeme"],
  description: "Get a random meme",
  category: "Fun",
  usage: ".meme",
  cooldown: 5000,

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const sub = subreddits[Math.floor(Math.random() * subreddits.length)];
      const res = await axios.get(
        `https://www.reddit.com/r/${sub}/random.json?limit=1`,
        {
          headers: { "User-Agent": "AA-MD-Bot/1.0" },
          timeout: 15000,
        }
      );

      const post = res.data?.[0]?.data?.children?.[0]?.data;
      if (!post || post.is_video || !post.url?.match(/\.(jpg|png|gif|jpeg)/i)) {
        return sock.sendMessage(from, { text: "😅 Couldn't find a meme right now, try again!" });
      }

      await sock.sendMessage(from, {
        image: { url: post.url },
        caption: `😂 *${post.title}*\n\n👍 ${post.ups} upvotes | r/${sub}`,
      });
    } catch (err) {
      await sock.sendMessage(from, { text: `❌ Meme fetch failed: ${err.message}` });
    }
  },
};
