// ============================================
// AA MD Bot - Love Calculator Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { generateProgressBar } = require("../../lib/utils");

function calculateLove(name1, name2) {
  // Deterministic but fun calculation based on names
  let seed = 0;
  const combined = (name1 + name2).toLowerCase();
  for (const c of combined) {
    seed += c.charCodeAt(0);
  }
  return seed % 101;
}

module.exports = {
  command: ["love", "lovecalc", "lovcalc"],
  description: "Calculate love percentage between two names",
  category: "Fun",
  usage: ".love <name1> & <name2>",

  async execute({ sock, ctx, args }) {
    const { from } = ctx;

    const full = args.join(" ");
    const parts = full.split("&");

    if (parts.length < 2) {
      return sock.sendMessage(from, {
        text: "⚠️ Usage: .love <name1> & <name2>\nExample: .love Ali & Sara",
      });
    }

    const name1 = parts[0].trim();
    const name2 = parts[1].trim();

    if (!name1 || !name2) {
      return sock.sendMessage(from, { text: "⚠️ Please provide two names." });
    }

    const score = calculateLove(name1, name2);
    const bar = generateProgressBar(score, 100, 12);

    let emoji = "💔";
    let comment = "Not a match...";
    if (score >= 90) { emoji = "💑"; comment = "Soulmates! 😍❤️"; }
    else if (score >= 70) { emoji = "❤️"; comment = "Perfect couple!"; }
    else if (score >= 50) { emoji = "💛"; comment = "Good match!"; }
    else if (score >= 30) { emoji = "🤝"; comment = "Could be friends."; }

    const text = `💘 *LOVE CALCULATOR*\n\n` +
      `👤 *${name1}*\n❤️ +\n👤 *${name2}*\n\n` +
      `[${bar}] *${score}%*\n\n` +
      `${emoji} *${comment}*`;

    await sock.sendMessage(from, { text });
  },
};
