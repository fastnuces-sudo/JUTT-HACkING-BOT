// ============================================
// AA MD Bot - Character/Personality Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { pickRandom, cleanJid } = require("../../lib/utils");

const characters = [
  { type: "The Adventurer", trait: "bold, risk-taking, and always seeking new experiences", emoji: "🧗" },
  { type: "The Genius", trait: "analytical, curious, and loves solving complex problems", emoji: "🧠" },
  { type: "The Artist", trait: "creative, emotional, and sees beauty in everything", emoji: "🎨" },
  { type: "The Leader", trait: "confident, decisive, and inspires others around them", emoji: "👑" },
  { type: "The Comedian", trait: "witty, playful, and always makes people laugh", emoji: "🤣" },
  { type: "The Dreamer", trait: "idealistic, imaginative, and full of big ideas", emoji: "🌙" },
  { type: "The Protector", trait: "loyal, caring, and always puts others first", emoji: "🛡️" },
  { type: "The Rebel", trait: "independent, unconventional, and challenges the status quo", emoji: "⚡" },
  { type: "The Sage", trait: "wise, patient, and seeks deeper meaning in life", emoji: "📖" },
  { type: "The Hustler", trait: "ambitious, determined, and never gives up", emoji: "💪" },
];

module.exports = {
  command: ["character", "personality", "type"],
  description: "Discover your character type",
  category: "Fun",
  usage: ".character | .character @mention",

  async execute({ sock, ctx }) {
    const { from, mentions, pushName } = ctx;

    const target = mentions?.[0]
      ? `@${cleanJid(mentions[0])}`
      : pushName;

    const char = pickRandom(characters);
    await sock.sendMessage(from, {
      text: `${char.emoji} *Character Reading for ${target}:*\n\n` +
        `🏷️ *Type:* ${char.type}\n\n` +
        `📝 *Personality:* You are ${char.trait}.\n\n` +
        `_This is just for fun! 😄_`,
      mentions: mentions || [],
    });
  },
};
