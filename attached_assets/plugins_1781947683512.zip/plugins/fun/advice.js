// ============================================
// AA MD Bot - Advice Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const axios = require("axios");

module.exports = {
  command: ["advice", "tip"],
  description: "Get a random piece of advice",
  category: "Fun",
  usage: ".advice",

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const res = await axios.get("https://api.adviceslip.com/advice", {
        timeout: 10000,
      });
      const advice = res.data.slip.advice;
      await sock.sendMessage(from, {
        text: `💡 *Advice of the moment:*\n\n_"${advice}"_`,
      });
    } catch {
      await sock.sendMessage(from, {
        text: "💡 *Advice:*\n\n_\"Every day is a new opportunity. Make the most of it!\"_",
      });
    }
  },
};
