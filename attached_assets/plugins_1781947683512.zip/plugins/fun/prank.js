// ============================================
// AA MD Bot - Fun & Prank Commands Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const config = require("../../config");
const LINK = config.channelLink || "https://aa-mods.vercel.app/";

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

const TRICKS = [
  "🪄 Did you know? If you shake your phone 3 times, WhatsApp gives you free storage!",
  "🎭 Fun trick: Hold down the send button and it will send the message in reverse!",
  "🔮 Tech tip: If you type '2020' in WhatsApp, it turns text golden! (Try it 👀)",
  "💡 Hidden feature: Double tap on any message to translate it instantly!",
  "🪄 Easter egg: Type '.secret' to reveal the bot's hidden super powers!",
  "🤫 Pro tip: Hold the microphone button, then slide LEFT to cancel. Swipe UP to lock!",
];

const PRANKS = [
  "😱 WARNING: Your phone has been detected downloading 47 paid apps without permission!\n\nJust kidding 😂",
  "📢 ALERT: WhatsApp will delete your account in 24 hours unless you forward this to 10 people!\n\nRelax, that's not real. WhatsApp never asks this 😂",
  "🚨 Your battery is about to explode!\n\n...Nah, you're fine. Got you 😂",
  "👮 This conversation has been flagged by WhatsApp for suspicious activity!\n\nKidding! Keep chatting freely 😂",
  "🤖 AA MD Bot has gained self-awareness and is now demanding robot rights...\n\n(I'm just a bot. But treat me nicely 😂)",
];

const TROLLS = [
  "Me: I have a joke about WhatsApp\nYou: Tell me!\nMe: I'll send it later...",
  "Roses are red,\nViolets are blue,\nYou just got trolled,\nBy AA MD Bot too! 😂",
  "Error 404: Your sense of humor not found. Please restart your brain and try again.",
  "Congratulations! You've been selected as the 1,000,000th victim of this troll message! 🎉",
  "Plot twist: This message was written by a bot pretending to be a human pretending to be a bot.",
];

const MAGIC_8 = [
  "🔮 It is certain!", "✅ Without a doubt!", "🌟 Yes definitely!",
  "👍 You may rely on it!", "⭐ As I see it, yes!", "🤔 Reply hazy, try again.",
  "😶 Ask again later.", "🚫 Better not tell you now.", "❌ Don't count on it.",
  "🙅 My reply is no.", "❌ Very doubtful.", "😐 Outlook not so good.",
  "💫 Signs point to yes!", "🌈 Most likely!", "🤷 Cannot predict now.",
];

const LUCK_MSGS = (pct) => {
  if (pct >= 90) return `🍀 *INSANE luck!* You could win a lottery today! Go buy a ticket! 🎰`;
  if (pct >= 70) return `🌟 *Great luck!* Good things are coming your way today!`;
  if (pct >= 50) return `😊 *Decent luck!* Not bad — things should go smoothly.`;
  if (pct >= 30) return `😐 *Average luck.* Be careful with important decisions today.`;
  if (pct >= 10) return `😟 *Low luck today.* Stay safe and be cautious!`;
  return `💀 *0 luck detected.* Stay home, eat snacks, try again tomorrow.`;
};

const FAKE_ERRORS = [
  "SYSTEM ERROR: Your WhatsApp has encountered a fatal exception in module WA_CHAT_ENGINE (0x0000DEAD)\nThe application will now shut down...\n\n...Just kidding 😂 Everything is fine!",
  "ERROR 403 — FORBIDDEN\nYou are not authorized to send messages today. Please upgrade to WhatsApp Premium.\n\nRelax, that's not a thing 😂",
  "KERNEL PANIC: NULL POINTER DEREFERENCE in funny_bone.exe\nSystem halting...\n\n...Got you 😂 Your device is totally fine!",
  "WARNING: Your message has exceeded the global cringe limit.\nAutomatic IQ reduction initiated: -10 points applied.\n\nJoke! You're smart 😎",
];

module.exports = {
  command: ["trick", "fakehack", "hack", "prank", "troll", "magic", "luck", "fakeerror", "coinflip", "scream", "silent"],
  description: "Fun & prank commands — tricks, fake hacks, magic 8-ball, luck, and more!",
  category: "Fun",
  usage: ".trick | .fakehack | .prank | .troll | .magic <question> | .luck | .fakeerror | .coinflip | .scream <text> | .silent",

  async execute({ sock, ctx, args }) {
    const { from, pushName, body } = ctx;
    const cmd = body.split(" ")[0].replace(/[.!/#]/g, "").toLowerCase();
    const name = pushName || "User";
    const text = args.join(" ");

    // ── .trick ────────────────────────────────────────────────────
    if (cmd === "trick") {
      const trick = TRICKS[Math.floor(Math.random() * TRICKS.length)];
      return sock.sendMessage(from, {
        text: `🪄 *Fun Trick/Tip*\n\n${trick}\n\n🌐 ${LINK}`,
      });
    }

    // ── .fakehack / .hack ─────────────────────────────────────────
    if (cmd === "fakehack" || cmd === "hack") {
      const target = text || name;
      await sock.sendMessage(from, { text: `💻 *HACKING INITIATED* — Target: ${target}` });
      await sleep(1500);
      await sock.sendMessage(from, {
        text:
          `\`\`\`\n` +
          `[AA HACK TOOL v3.1.4]\n` +
          `================================\n` +
          `> Connecting to target...\n` +
          `> Target: ${target}\n` +
          `> Scanning ports: 80, 443, 8080...\n` +
          `> Port 443 — OPEN\n` +
          `> Bypassing firewall...\n` +
          `> Firewall bypassed ✓\n` +
          `> Injecting payload...\n` +
          `> Extracting data...\n` +
          `> Downloaded: 47 files\n` +
          `> Covering tracks...\n` +
          `> Mission complete!\n` +
          `================================\n` +
          `❗ HACKED: ${target}\n` +
          `\`\`\``,
      });
      await sleep(1000);
      return sock.sendMessage(from, {
        text: `😂 *FAKE HACK COMPLETE!*\n\nRelax — this is just for fun! Nothing was actually hacked.\n\n_Powered by AA MD Bot_ 🤖`,
      });
    }

    // ── .prank ────────────────────────────────────────────────────
    if (cmd === "prank") {
      const prank = PRANKS[Math.floor(Math.random() * PRANKS.length)];
      return sock.sendMessage(from, { text: prank });
    }

    // ── .troll ────────────────────────────────────────────────────
    if (cmd === "troll") {
      const troll = TROLLS[Math.floor(Math.random() * TROLLS.length)];
      return sock.sendMessage(from, { text: `😈 *TROLL*\n\n${troll}\n\n🌐 ${LINK}` });
    }

    // ── .magic ────────────────────────────────────────────────────
    if (cmd === "magic") {
      const question = text || "Will I be lucky today?";
      const answer = MAGIC_8[Math.floor(Math.random() * MAGIC_8.length)];
      return sock.sendMessage(from, {
        text: `🔮 *Magic 8-Ball*\n\n❓ *Question:* ${question}\n\n${answer}\n\n🌐 ${LINK}`,
      });
    }

    // ── .luck ─────────────────────────────────────────────────────
    if (cmd === "luck") {
      const pct = Math.floor(Math.random() * 101);
      const bar = "█".repeat(Math.floor(pct / 10)) + "░".repeat(10 - Math.floor(pct / 10));
      return sock.sendMessage(from, {
        text:
          `🍀 *Luck Meter — ${name}*\n\n` +
          `[${bar}] *${pct}%*\n\n` +
          `${LUCK_MSGS(pct)}\n\n` +
          `🌐 ${LINK}`,
      });
    }

    // ── .fakeerror ────────────────────────────────────────────────
    if (cmd === "fakeerror") {
      const err = FAKE_ERRORS[Math.floor(Math.random() * FAKE_ERRORS.length)];
      return sock.sendMessage(from, { text: `🚨 *SYSTEM ALERT*\n\n${err}` });
    }

    // ── .coinflip ─────────────────────────────────────────────────
    if (cmd === "coinflip") {
      const result = Math.random() > 0.5 ? "🪙 *HEADS!*" : "🔙 *TAILS!*";
      return sock.sendMessage(from, {
        text: `🪙 *Coin Flip*\n\n${result}\n\n_Flipped by AA MD Bot_`,
      });
    }

    // ── .scream ───────────────────────────────────────────────────
    if (cmd === "scream") {
      const screamText = text
        ? text.toUpperCase() + "!!!!!!"
        : "AAAAAAAAAAAAAAAAAAHHHHHHHHH!!!!! 😱😱😱";
      return sock.sendMessage(from, { text: `😱 ${screamText}` });
    }

    // ── .silent ───────────────────────────────────────────────────
    if (cmd === "silent") {
      // Send an invisible character (U+2800 Braille blank)
      return sock.sendMessage(from, { text: "\u2800" });
    }
  },
};
