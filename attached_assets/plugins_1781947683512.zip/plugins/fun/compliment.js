// ============================================
// AA MD Bot - Compliment Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const { pickRandom, cleanJid } = require("../../lib/utils");

const compliments = [
  "You have the most amazing smile in the room!",
  "You make everything look effortless!",
  "The world is a better place with you in it.",
  "You have an incredible gift for making people feel welcome.",
  "You're someone that people can always count on.",
  "You are more fun than bubble wrap!",
  "You are one of the most inspiring people I know.",
  "Your dedication is truly admirable.",
  "You bring out the best in everyone around you.",
  "You have a heart of gold.",
  "You're not just smart — you're brilliant.",
  "Your kindness is a superpower.",
];

module.exports = {
  command: ["compliment", "comp"],
  description: "Send a compliment to someone",
  category: "Fun",
  usage: ".compliment @mention",

  async execute({ sock, ctx }) {
    const { from, mentions, pushName } = ctx;

    const target = mentions?.[0]
      ? `@${cleanJid(mentions[0])}`
      : pushName;

    await sock.sendMessage(from, {
      text: `💐 *Compliment for ${target}:*\n\n${pickRandom(compliments)} ✨`,
      mentions: mentions || [],
    });
  },
};
