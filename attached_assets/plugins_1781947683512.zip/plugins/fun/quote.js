// ============================================
// AA MD Bot - Quote Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const axios = require("axios");

module.exports = {
  command: ["quote", "inspire", "motivation"],
  description: "Get a random inspirational quote",
  category: "Fun",
  usage: ".quote",

  async execute({ sock, ctx }) {
    const { from } = ctx;

    try {
      const res = await axios.get("https://api.quotable.io/random", { timeout: 10000 });
      const data = res.data;
      await sock.sendMessage(from, {
        text: `💬 *"${data.content}"*\n\n— _${data.author}_`,
      });
    } catch {
      // Fallback quotes
      const quotes = [
        ["The only way to do great work is to love what you do.", "Steve Jobs"],
        ["Innovation distinguishes a leader from a follower.", "Steve Jobs"],
        ["Life is what happens when you're busy making other plans.", "John Lennon"],
        ["In the middle of every difficulty lies opportunity.", "Albert Einstein"],
        ["It does not matter how slowly you go as long as you do not stop.", "Confucius"],
      ];
      const [q, a] = quotes[Math.floor(Math.random() * quotes.length)];
      await sock.sendMessage(from, { text: `💬 *"${q}"*\n\n— _${a}_` });
    }
  },
};
