// ============================================
// AA MD Bot - Message Event Handler
// Developer: Ahsan Ali | AA Mods
// ============================================

const config = require("../config");
const { parseCommand, executeCommand, wrapSockWM, plugins: pluginsRef } = require("../lib/handler");
const { getBody, getMentions, getQuotedMessage, isGroup, cleanJid } = require("../lib/utils");
const { ensureUser, getUser, addXP, getGroup, getGroupSetting, getSetting, updateUser, addCommandHistory } = require("../lib/database");
const logger = require("../lib/logger");
const { addLog } = require("../lib/logBuffer");
const { fbPush } = require("../lib/firebase");

// Emoji per plugin category for smart auto-react
const CATEGORY_EMOJIS = {
  "AI":       "🤖",
  "Download": "📥",
  "Fun":      "😂",
  "Games":    "🎮",
  "Group":    "👥",
  "Media":    "🎨",
  "Admin":    "⚙️",
  "Owner":    "👑",
  "General":  "👋",
  "Economy":  "💰",
  "Search":   "🔍",
  "Utility":  "⚡",
  "Tools":    "🔧",
};

const processedMessageIds = new Set();
function markProcessedMessage(msg) {
  const key = `${msg?.key?.remoteJid || "?"}:${msg?.key?.id || "?"}:${!!msg?.key?.fromMe}`;
  if (!msg?.key?.id) return false;
  if (processedMessageIds.has(key)) return true;
  processedMessageIds.add(key);
  if (processedMessageIds.size > 3000) {
    const first = processedMessageIds.values().next().value;
    processedMessageIds.delete(first);
  }
  return false;
}

async function handleSingleMessage(msg, type, sock, plugins, msgCache) {
  try {
    // AUDIT LOG 3 — very top of handler, fires once per handleMessages call
    console.log(`[MSG-HANDLER] from=${msg?.key?.remoteJid} fromMe=${msg?.key?.fromMe} type=${Object.keys(msg?.message || {})[0] || "none"}`);
    if (!msg || !msg.message) return;
    if (markProcessedMessage(msg)) {
      console.log(`[DEDUP] skipping already processed ${msg.key?.remoteJid}:${msg.key?.id}:${!!msg.key?.fromMe}`);
      return;
    }

    // ── Skip bot's own outgoing non-command echoes only ───────────
    // fromMe=true echoes (own sends, delivery receipts) must never enter the
    // plugin system — only owner-typed commands starting with a prefix are allowed.
    if (msg.key.fromMe) {
      const selfBody = getBody(msg.message);
      const allPrefixes = [config.prefix, ...config.altPrefixes].filter(Boolean);
      const isSelfCommand = !!selfBody && allPrefixes.some((p) => selfBody.startsWith(p));
      if (!isSelfCommand) {
        // Log type only — not the body — to avoid polluting logs with bot output
        const msgType = Object.keys(msg.message || {})[0] || "unknown";
        console.log(`[SKIP-SELF] fromMe echo — type=${msgType} jid=${msg.key.remoteJid}`);
        return;
      }
      console.log(`[ALLOW-SELF-CMD] ${msg.key.remoteJid} cmd="${selfBody.slice(0, 60)}"`);
    }

    const rawFrom = msg.key.remoteJid;
    if (!rawFrom || rawFrom === "status@broadcast") return;

    const isFromMe = !!msg.key.fromMe;

    // ── Canonical identity layer ─────────────────────────────────
    // Commands and user records must never receive a raw @lid as the main
    // identity. Resolve in a stable priority order, persist successful LID →
    // phone mappings, then attach msg.identity before command processing.
    const rawSender = msg.key.participant || msg.key.remoteJid;
    const group     = isGroup(rawFrom);
    const rawLidNum = rawFrom.endsWith("@lid") ? rawFrom.split("@")[0].split(":")[0] : null;
    const rawSenderLidNum = rawSender.endsWith("@lid") ? rawSender.split("@")[0].split(":")[0] : null;

    function validPhoneJid(value) {
      const digits = (value || "").toString().replace(/\D/g, "");
      if (!digits || digits === rawLidNum || digits === rawSenderLidNum || digits.length < 7 || digits.length > 15) return null;
      return `${digits}@s.whatsapp.net`;
    }

    let resolvedPhoneJid = null;
    let identitySource = "raw";

    if (rawLidNum && !group) {
      // 1) senderPn is the best per-message phone hint when WhatsApp includes it.
      resolvedPhoneJid = validPhoneJid(msg.key?.senderPn);
      if (resolvedPhoneJid) identitySource = "senderPn";

      // 2) Persistent/local cache before expensive or unreliable USync.
      if (!resolvedPhoneJid) {
        const cached = sock._getLidMapping?.(rawFrom);
        resolvedPhoneJid = validPhoneJid(cached);
        if (resolvedPhoneJid) identitySource = "cache";
      }

      // 3) participantPn covers some multi-device/group-style key payloads.
      if (!resolvedPhoneJid) {
        resolvedPhoneJid = validPhoneJid(msg.key?.participantPn);
        if (resolvedPhoneJid) identitySource = "participantPn";
      }

      // 4) USync/onWhatsApp fallback last; logs show it often returns undefined.
      if (!resolvedPhoneJid) {
        const attempt = await sock._resolveLidAsync(rawFrom).catch(() => rawFrom);
        resolvedPhoneJid = attempt?.endsWith("@s.whatsapp.net") ? validPhoneJid(attempt) : null;
        if (resolvedPhoneJid) identitySource = "usync";
      }

      if (resolvedPhoneJid) {
        sock._storeLidMapping?.(rawFrom, resolvedPhoneJid, identitySource);
        console.log(`[IDENTITY] ${rawFrom} → ${resolvedPhoneJid} (${identitySource})`);
      } else {
        console.log(`[IDENTITY] unresolved LID ${rawFrom}; canonical falls back to raw`);
      }
    }

    let senderPhoneJid = null;
    if (rawSender.endsWith("@lid")) {
      senderPhoneJid = resolvedPhoneJid || validPhoneJid(msg.key?.participantPn) || validPhoneJid(msg.key?.senderPn);
      if (senderPhoneJid) sock._storeLidMapping?.(rawSender, senderPhoneJid, "sender-key");
    }

    const resolvedSender = rawSender.endsWith("@lid")
      ? (senderPhoneJid || await sock._resolveLidAsync(rawSender).catch(() => rawSender))
      : rawSender;

    // senderNum / senderJid — only use digits as phone number when the resolved
    // JID is a real @s.whatsapp.net address. If resolution failed and we still
    // have an @lid, keep the @lid as the stable identity rather than constructing
    // a fake phone JID from the LID number (LID ≠ phone number).
    const senderIsPhone = resolvedSender.endsWith("@s.whatsapp.net");
    const senderNum = resolvedSender.split("@")[0].split(":")[0];
    const senderJid = senderIsPhone
      ? resolvedSender
      : (rawSender.endsWith("@lid") ? rawSender : `${senderNum}@s.whatsapp.net`);

    const lidResolved  = !!resolvedPhoneJid;
    const rawFromIsLid = rawFrom.endsWith("@lid");

    // ── Stable internalUserId — single source of truth per user ──────────
    // Priority: resolved phone JID > raw @lid JID (never a fake phone from LID num)
    // This key is used for ALL DB operations so one user always has one record.
    const internalUserId = senderJid; // already fixed: phone JID or raw @lid
    const isUnverifiedIdentity = rawFromIsLid && !lidResolved;

    // ── Record migration: if LID just resolved, merge any existing LID record
    // into the phone JID key so XP/balance/history is not lost.
    if (lidResolved && rawSender.endsWith("@lid") && rawSender !== senderJid) {
      try {
        const oldRecord = getUser(rawSender);
        if (oldRecord) {
          const phoneRecord = getUser(senderJid);
          // Merge: prefer phone record for new fields, old lid record for history
          updateUser(senderJid, {
            ...oldRecord,
            ...(phoneRecord || {}),
            jid:                senderJid,
            id:                 senderJid,
            unverifiedIdentity: false,
          });
          console.log(`[IDENTITY-MIGRATE] ${rawSender} → ${senderJid} (lid record merged)`);
        }
      } catch (_) {}
    }

    msg.identity = {
      rawJid:             rawFrom,
      lid:                rawFromIsLid ? rawFrom : null,
      phoneJid:           resolvedPhoneJid || null,
      canonicalJid:       resolvedPhoneJid || rawFrom,
      internalUserId,
      isUnverifiedIdentity,
      source:             resolvedPhoneJid ? `lid->pn:${identitySource}` : "raw",
      lidResolved,
    };

    const from         = msg.identity.canonicalJid;
    const resolvedFrom = msg.identity.canonicalJid;

    // ── [IDENTITY-FINAL] — one log per message showing full identity state ──
    console.log(
      `[IDENTITY-FINAL] internalUserId=${internalUserId}` +
      ` resolved=${lidResolved} source=${msg.identity.source}` +
      ` fromMe=${isFromMe} group=${group}` +
      (isUnverifiedIdentity ? " ⚠️ unverified-lid" : "")
    );

    // Bot's own number (available once connection is open)
    const botRaw = sock.user?.id || "";
    const botNum = botRaw.split(":")[0].split("@")[0];

    // ── fromMe filter ─────────────────────────────────────────────
    // In groups: only allow fromMe if the message starts with a command prefix
    // (owner controlling the bot from their own number in a group).
    // Non-command messages from the bot are blocked to prevent reply loops.
    // In private chats: always allow fromMe (owner running commands from their number).
    if (isFromMe && group) {
      const bodyText = getBody(msg.message);
      const allPrefixes = [config.prefix, ...config.altPrefixes].filter(Boolean);
      if (!bodyText || !allPrefixes.some((p) => bodyText.startsWith(p))) return;
    }

    const pushName = msg.pushName || (isFromMe ? "Owner" : "User");
    const message = msg.message;
    const body = getBody(message);
    const mentions = getMentions(message);
    const quoted = getQuotedMessage(message);
    const messageType = Object.keys(message)[0];

    // Auto-read
    if (config.autoRead) {
      await sock.readMessages([msg.key]).catch(() => {});
    }

    // ── Owner check ───────────────────────────────────────────────
    // isOwner = true if: sender is in ownerNumber list OR message is fromMe in DM
    // botNum match only counts when botNum is non-empty (session connected)
    const ownerNums = config.ownerNumber.map((n) => n.replace(/[^0-9]/g, ""));
    const isOwner =
      isFromMe ||
      ownerNums.includes(senderNum) ||
      (botNum && senderNum === botNum);

    // ── Admin check (groups only) ─────────────────────────────────
    let isAdmin = false;
    let isBotAdmin = false;
    let groupMetadata = null;

    if (group) {
      try {
        groupMetadata = await sock.groupMetadata(from);
        const admins = groupMetadata.participants
          .filter((p) => p.admin === "admin" || p.admin === "superadmin")
          .map((p) => p.id.split(":")[0].split("@")[0]);
        isAdmin = admins.includes(senderNum);
        isBotAdmin = admins.includes(botNum);
      } catch {}
    }

    // Ensure user exists before any permission/welcome/command logic. Firebase
    // failures must never block message handling, so ensureUser provides an
    // in-memory fallback record if persistence fails.
    let userRecord;
    try {
      userRecord = await ensureUser(senderJid, { name: pushName, lastSeen: Date.now(), ...(isUnverifiedIdentity ? { unverifiedIdentity: true } : { unverifiedIdentity: false }) });
    } catch (e) {
      console.warn(`[USER-FALLBACK] ${senderJid}: ${e.message}`);
      userRecord = { id: senderJid, jid: senderJid, name: pushName, commandsUsed: 0, banned: false, createdAt: Date.now() };
    }
    if (userRecord?.banned && !isOwner) return;

    // ── Bot mode filter ───────────────────────────────────────────
    // Keep botMode hot-path lookup in memory only.
    // "private" = only owner can use bot in DMs. Groups always work.
    const sessionBotMode = sock._settings?.botMode ?? config.botMode ?? "public";
    if (sessionBotMode === "private" && !isOwner && !group) return;

    // Wrap sock so ALL user-facing messages (autoReply, welcome, levelUp,
    // unknown-command) get the watermark + View Channel button, not just
    // plugin responses. Group-system messages (anti-link etc.) still use
    // raw sock to avoid polluting moderation actions.
    const wsock = wrapSockWM(sock);

    // ── Welcome new users (first-ever message, DM only) ───────────
    if ((getSetting("publicWelcome") ?? config.publicWelcome) && !isOwner && !group
        && (userRecord?.commandsUsed ?? 0) === 0) {
      const botName = getSetting("botName") ?? config.botName;
      await wsock.sendMessage(resolvedFrom, {
        text:
          `👋 *Welcome, ${pushName}!*\n\n` +
          `I'm *${botName}*, your smart WhatsApp assistant. 🤖\n\n` +
          `📋 Send *${config.prefix}menu* to see all commands.\n` +
          `❓ Send *${config.prefix}help* for usage tips.\n\n` +
          `_Enjoy using the bot!_ 🎉`,
      }).then(() => console.log(`[SEND-OK] welcome → ${resolvedFrom}`))
        .catch(e => console.error(`[SEND-FAIL] welcome → ${resolvedFrom}: ${e.message}`));
    }

    // ── Context object passed to every plugin ─────────────────────
    const ctx = {
      from: resolvedFrom,
      sender: senderJid,
      senderNum,
      pushName,
      msg,
      message,
      body,
      mentions,
      quoted,
      messageType,
      isGroup: group,
      isOwner,
      isAdmin,
      isBotAdmin,
      groupMetadata,
      isFromMe,
      msgCache,
      sock,
    };

    // ── Group-only protection (anti-link, anti-bad-word) ──────────
    if (group && groupMetadata) {
      getGroup(from); // ensure DB entry exists

      // Anti-link
      if (getGroupSetting(from, "antilink") && !isAdmin && !isOwner) {
        if (/(https?:\/\/|www\.)?(chat\.whatsapp\.com|wa\.me)\/\S+/gi.test(body)) {
          await sock.sendMessage(from, { delete: msg.key }).catch(() => {});
          await sock.sendMessage(from, {
            text: `@${senderNum} ⚠️ Links are not allowed here!`,
            mentions: [senderJid],
          });
          return;
        }
      }

      // Anti-bad-word
      if (getGroupSetting(from, "antibadword") && !isAdmin && !isOwner) {
        const bl = body.toLowerCase();
        if (config.badWords.some((w) => bl.includes(w.toLowerCase()))) {
          await sock.sendMessage(from, { delete: msg.key }).catch(() => {});
          await sock.sendMessage(from, {
            text: `@${senderNum} ⚠️ Bad language is not allowed!`,
            mentions: [senderJid],
          });
          return;
        }
      }
    }

    // ── Anti-delete (groups + DMs) ────────────────────────────────
    {
      const antidelOn = group
        ? (getGroupSetting(from, "antidelete") ?? getSetting("antidelete") ?? false)
        : (getSetting("antidelete") ?? false);

      if (antidelOn) {
        const proto = message?.protocolMessage;
        if (proto?.type === 0 && proto?.key) {
          const cached = msgCache?.get(from)?.get(proto.key.id);
          if (cached) {
            const delTime = new Date().toLocaleString("en-PK", {
              timeZone: "Asia/Karachi",
              day: "2-digit", month: "short",
              hour: "2-digit", minute: "2-digit", hour12: true,
            });

            if (group) {
              // Groups: reveal in same group with deleter tag
              await sock.sendMessage(from, {
                text: `🗑️ *Message deleted by @${senderNum}*\n🕐 *Time:* ${delTime}`,
                mentions: [senderJid],
              }).catch(() => {});
              await sock.copyNForward(from, { key: proto.key, message: cached }, true).catch(() => {});
            } else {
              // DMs: forward deleted message to owner's self-chat (You chat)
              const ownerNums = config.ownerNumber || [];
              if (ownerNums.length) {
                const ownerJid = `${ownerNums[0].replace(/\D/g, "")}@s.whatsapp.net`;
                await sock.sendMessage(ownerJid, {
                  text:
                    `🗑️ *Message Deleted!*\n\n` +
                    `📨 *From:* +${senderNum}\n` +
                    `👤 *Name:* ${pushName}\n` +
                    `🕐 *Time:* ${delTime}`,
                }).catch(() => {});
                await sock.copyNForward(ownerJid, { key: proto.key, message: cached }, true).catch(() => {});
              }
            }
          }
        }
      }
    }

    // ── View-once interceptor — cache on arrival so .reveal works ─
    {
      const vMsg =
        message.viewOnceMessage?.message ||
        message.viewOnceMessageV2?.message?.viewOnceMessage?.message ||
        message.viewOnceMessageV2ExpiryExtension?.message?.viewOnceMessage?.message;
      if (vMsg && msg.key?.id) {
        const { cacheViewOnce } = require("../lib/viewOnceCache");
        cacheViewOnce(msg.key.id, vMsg, senderNum, pushName);
      }
    }

    // ── Anti-view-once (groups + DMs) ─────────────────────────────
    {
      const antiVoOn = group
        ? (getGroupSetting(from, "antiviewonce") ?? getSetting("antiviewonce") ?? false)
        : (getSetting("antiviewonce") ?? false);

      if (antiVoOn) {
        const vMsg =
          message.viewOnceMessage?.message ||
          message.viewOnceMessageV2?.message?.viewOnceMessage?.message ||
          message.viewOnceMessageV2ExpiryExtension?.message?.viewOnceMessage?.message;

        if (vMsg) {
          if (group) {
            // Groups: reveal in the group chat (existing behavior)
            await sock.copyNForward(from, { ...msg, message: vMsg }, true).catch(() => {});
          } else if (!isOwner) {
            // DMs: silently forward to owner as normal media — sender doesn't know
            const ownerNums = config.ownerNumber || [];
            if (ownerNums.length) {
              const ownerJid = `${ownerNums[0].replace(/\D/g, "")}@s.whatsapp.net`;
              try {
                const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
                const isImg = !!vMsg.imageMessage;
                const isVid = !!vMsg.videoMessage;
                const mediaType = isImg ? "image" : isVid ? "video" : null;
                if (mediaType) {
                  const mediaMsg = vMsg[`${mediaType}Message`];
                  const stream   = await downloadContentFromMessage(mediaMsg, mediaType);
                  const chunks   = [];
                  for await (const chunk of stream) chunks.push(chunk);
                  const buffer = Buffer.concat(chunks);
                  await sock.sendMessage(ownerJid, {
                    [mediaType]: buffer,
                    caption:
                      `👁️ *View-Once Revealed*\n\n` +
                      `📨 *From:* +${senderNum}\n` +
                      `👤 *Name:* ${pushName}\n` +
                      `📱 *Chat:* DM`,
                    mimetype: mediaType === "image" ? "image/jpeg" : "video/mp4",
                  }).catch(() => {});
                }
              } catch {}
            }
          }
        }
      }
    }

    // ── Auto-reply (private, non-command, non-self) ───────────────
    const allPrefixes = [config.prefix, ...config.altPrefixes].filter(Boolean);
    const hasPrefix = allPrefixes.some((p) => body.startsWith(p));
    if (!hasPrefix && config.autoReply && !group && !isFromMe) {
      await wsock.sendMessage(resolvedFrom, { text: config.autoReplyMessage })
        .then(() => console.log(`[SEND-OK] autoReply → ${resolvedFrom}`))
        .catch(e => console.error(`[SEND-FAIL] autoReply → ${resolvedFrom}: ${e.message}`));
    }

    // ── Command parsing ───────────────────────────────────────────
    const parsed = parseCommand(body);
    // AUDIT LOG 4 — shows whether a command was detected from the message body
    console.log(`[PARSE] body="${body?.slice(0,60)}" parsed=${parsed ? parsed.command : "null"}`);

    // ── Smart auto-react ───────────────────────────────────────────
    // ISSUE D FIX: wrap entire block in try/catch — Baileys encrypt step can
    // throw synchronously on @lid JIDs before the promise is even created,
    // which would bubble up and crash the entire handleMessages call.
    try {
      if (config.autoReactMessages && !isFromMe) {
        let reactEmoji = config.autoReactEmoji || "❤️";
        if (parsed) {
          const plugin = plugins[parsed.command] || pluginsRef[parsed.command];
          const cat = plugin?.category;
          if (cat && CATEGORY_EMOJIS[cat]) reactEmoji = CATEGORY_EMOJIS[cat];
        }
        // Build a clean key — groups use the group JID, DMs use resolvedFrom
        const reactTarget = group ? from : resolvedFrom;
        const reactKey = {
          remoteJid: reactTarget,
          id: msg.key.id,
          fromMe: !!msg.key.fromMe,
          ...(group && msg.key.participant ? { participant: msg.key.participant } : {}),
        };
        await sock.sendMessage(reactTarget, {
          react: { text: reactEmoji, key: reactKey }
        }).then(() => console.log(`[SEND-OK] autoReact → ${reactTarget}`))
          .catch(e => console.error(`[SEND-FAIL] autoReact → ${reactTarget}: ${e.message}`));
      }
    } catch (_) {}

    if (!parsed) return;

    // XP / stats (only for real incoming users, not self)
    if (!isFromMe) {
      updateUser(senderJid, {
        name: pushName,
        commandsUsed: (userRecord?.commandsUsed ?? 0) + 1,
        lastSeen: Date.now(),
      });
      const { leveledUp, user: up } = addXP(senderJid, config.xpPerCommand);
      if (leveledUp) {
        await wsock.sendMessage(resolvedFrom, {
          text: `🎉 @${senderNum} leveled up to *Level ${up.level}*! ⭐`,
          mentions: [senderJid],
        }).catch(() => {});
      }
    }

    const cmdLabel = isFromMe ? "SELF" : senderNum;
    const cmdStr = `${parsed.prefix}${parsed.command}${parsed.args.length ? " " + parsed.args.join(" ") : ""}`;
    logger.info(`[CMD] ${cmdLabel}: ${cmdStr}`);

    const logEntry = {
      type:    "cmd",
      number:  cmdLabel,
      name:    pushName,
      command: `${parsed.prefix}${parsed.command}`,
      args:    parsed.args.join(" "),
      chat:    group ? "group" : "dm",
      ts:      Date.now(),
    };
    addLog(logEntry);
    fbPush("cmdlogs", logEntry).catch(() => {});
    if (!isFromMe) {
      addCommandHistory(senderJid, {
        cmd:  `${parsed.prefix}${parsed.command}`,
        args: parsed.args.join(" "),
        chat: group ? "group" : "dm",
        name: pushName,
      });
    }

    logger.info(`[DBG] calling executeCommand: cmd=${parsed.command} from=${from} isOwner=${isOwner} mode=${getSetting("botMode") ?? config.botMode}`);
    const executed = await executeCommand(parsed, ctx, sock);
    logger.info(`[DBG] executeCommand returned: ${executed} for cmd=${parsed.command} from=${from}`);

    if (!executed && !group) {
      logger.info(`[DBG] sending unknown-command reply to ${resolvedFrom}`);
      await wsock.sendMessage(resolvedFrom, {
        text: `❓ Unknown command: *${parsed.prefix}${parsed.command}*\nSend *${config.prefix}menu* to see all commands.`,
      }).catch((e) => logger.error(`[DBG] unknown-cmd sendMessage failed: ${e.message}`));
    }
  } catch (err) {
    logger.error("Message handler error: " + err.message + "\n" + err.stack);
  }
}

async function handleMessages({ messages, type }, sock, plugins, msgCache) {
  for (const msg of messages || []) {
    await handleSingleMessage(msg, type, sock, plugins, msgCache);
  }
}

module.exports = { handleMessages };
