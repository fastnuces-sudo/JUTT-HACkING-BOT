// ============================================
// AA MD Bot - Connection Handler
// Developer: Ahsan Ali | AA Mods
// ============================================

const { DisconnectReason } = require("@whiskeysockets/baileys");
const chalk = require("chalk");
const fs = require("fs-extra");
const config = require("../config");
const logger = require("../lib/logger");

let reconnectAttempts = 0;
const MAX_RECONNECT = 10;
let welcomeSent = false;

async function sendOwnerWelcome(sock) {
  try {
    if (welcomeSent) return;
    welcomeSent = true;

    const ownerJid = config.ownerNumber[0] + "@s.whatsapp.net";
    const botJid = sock.user?.id || "";
    const botNumber = botJid.split(":")[0].split("@")[0];
    const now = new Date().toLocaleString("en-PK", { timeZone: "Asia/Karachi" });

    const caption =
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
      `   ✅ *AA MD Bot Online!*\n` +
      `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🤖 *Bot:* ${sock.user?.name || config.botName}\n` +
      `📱 *Number:* +${botNumber}\n` +
      `👤 *Owner:* ${config.ownerName}\n` +
      `⏰ *Time:* ${now}\n` +
      `🔢 *Version:* ${config.botVersion}\n\n` +
      `✦ Bot ready! Send *.menu* for commands ✦`;

    // Try with image first, fall back to text
    try {
      await sock.sendMessage(ownerJid, {
        image: { url: "https://i.imgur.com/0nGvuiU.jpeg" },
        caption,
      });
    } catch (_) {
      await sock.sendMessage(ownerJid, { text: caption });
    }

    logger.info(chalk.cyan("📩 Welcome message sent to owner."));
  } catch (e) {
    logger.warn("Could not send owner welcome: " + e.message);
  }
}

async function handleConnection(update, sock, startBot, saveCreds) {
  const { connection, lastDisconnect } = update;

  if (connection === "connecting") {
    logger.info(chalk.yellow("🔄 Connecting to WhatsApp..."));
    return;
  }

  if (connection === "open") {
    reconnectAttempts = 0;
    welcomeSent = false;
    const botJid = sock.user?.id || "";
    const botNumber = botJid.split(":")[0].split("@")[0];
    const botName = sock.user?.name || config.botName;

    logger.info(chalk.green("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
    logger.info(chalk.green("  ✅  AA MD Bot Connected!"));
    logger.info(chalk.green(`  📱 Number : ${botNumber}`));
    logger.info(chalk.green(`  🤖 Name   : ${botName}`));
    logger.info(chalk.green(`  👤 Dev    : ${config.developer}`));
    logger.info(chalk.green("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));

    // Auto-set owner if still placeholder
    if (
      botNumber &&
      (config.ownerNumber.length === 0 ||
        config.ownerNumber.includes("923xxxxxxxxx") ||
        config.ownerNumber.includes("0"))
    ) {
      config.ownerNumber = [botNumber];
      logger.info(
        chalk.cyan(`✅ Owner auto-set to: ${botNumber} (update config.js to make permanent)`)
      );
    }

    // Send welcome message to owner's own chat (YOU chat) after 3 seconds
    setTimeout(() => sendOwnerWelcome(sock), 3000);
    return;
  }

  if (connection === "close") {
    const statusCode = lastDisconnect?.error?.output?.statusCode;
    const reason =
      lastDisconnect?.error?.output?.payload?.error ||
      lastDisconnect?.error?.message ||
      "Unknown";

    logger.warn(chalk.yellow(`⚠️  Connection closed — ${reason} (${statusCode})`));

    // 403 Forbidden: session rejected by WhatsApp
    if (statusCode === DisconnectReason.forbidden || statusCode === 403) {
      logger.warn(chalk.yellow("🗑️  Session rejected (403). Clearing session for fresh login..."));
      try {
        fs.emptyDirSync("./session");
        logger.info(chalk.cyan("✅ Session cleared. Please restart the bot and re-pair."));
      } catch (e) {
        logger.error("Could not clear session: " + e.message);
      }
      process.exit(0);
    }

    // 401 / loggedOut: user removed device from WhatsApp
    if (
      statusCode === DisconnectReason.loggedOut ||
      statusCode === 401 ||
      statusCode === 440
    ) {
      logger.error(chalk.red("❌ Bot was logged out. Clearing session — please restart and re-pair."));
      try { fs.emptyDirSync("./session"); } catch {}
      process.exit(0);
    }

    // 428: connection replaced
    if (statusCode === 428) {
      logger.warn(chalk.yellow("⚠️  Connection replaced by another session. Reconnecting..."));
    }

    // All other cases: reconnect with exponential backoff
    if (reconnectAttempts < MAX_RECONNECT) {
      reconnectAttempts++;
      const delay = Math.min(reconnectAttempts * 4000, 20000);
      logger.info(
        chalk.cyan(`🔄 Reconnecting (${reconnectAttempts}/${MAX_RECONNECT}) in ${delay / 1000}s...`)
      );
      setTimeout(() => startBot(), delay);
    } else {
      logger.error(chalk.red("❌ Could not reconnect after multiple attempts. Restarting process..."));
      process.exit(1);
    }
  }
}

module.exports = { handleConnection };
