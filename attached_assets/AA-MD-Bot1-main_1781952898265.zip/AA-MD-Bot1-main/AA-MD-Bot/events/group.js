// ============================================
// AA MD Bot - Group Participant Update Handler
// Developer: Ahsan Ali | AA Mods
// Welcome/Goodbye with Banner Image
// ============================================

const { getGroup, getGroupSetting } = require("../lib/database");
const logger = require("../lib/logger");
const fs = require("fs");
const path = require("path");

const BANNER_PATH = path.join(__dirname, "../assets/banner.jpg");

async function handleGroupParticipants(update, sock) {
  try {
    const { id: groupJid, participants, action } = update;
    if (action !== "add" && action !== "remove") return;

    const welcome = getGroupSetting(groupJid, "welcome");
    const goodbye = getGroupSetting(groupJid, "goodbye");

    let meta = { subject: "this group" };
    try { meta = await sock.groupMetadata(groupJid); } catch {}

    const groupName = meta.subject || "this group";
    const memberCount = meta.participants?.length || 0;
    const hasBanner = fs.existsSync(BANNER_PATH);
    const banner = hasBanner ? fs.readFileSync(BANNER_PATH) : null;

    // ── Welcome ──────────────────────────────────────────────────
    if (action === "add" && welcome) {
      const group = getGroup(groupJid);

      for (const participant of participants) {
        const num = participant.split("@")[0];
        const customMsg = group.welcomeMsg || "";

        let welcomeText;
        if (customMsg) {
          welcomeText = customMsg
            .replace("{name}", `@${num}`)
            .replace("{group}", groupName)
            .replace("{count}", memberCount);
        } else {
          welcomeText =
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n` +
            `   👋  *WELCOME!*\n` +
            `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n` +
            `Assalam o Alaikum @${num}! 🎉\n\n` +
            `🏠 *Group:* ${groupName}\n` +
            `👥 *Members:* ${memberCount}\n\n` +
            `📌 Please read the group rules.\n` +
            `🤖 Send *.menu* to see bot commands.\n\n` +
            `_Welcome to the family! 💚_\n\n` +
            `— *AA MD Bot* by Ahsan Ali`;
        }

        try {
          if (banner) {
            await sock.sendMessage(groupJid, {
              image: banner,
              caption: welcomeText,
              mimetype: "image/jpeg",
              mentions: [participant],
            });
          } else {
            await sock.sendMessage(groupJid, {
              text: welcomeText,
              mentions: [participant],
            });
          }
        } catch (e) {
          logger.error("Welcome send error: " + e.message);
        }
      }
    }

    // ── Goodbye ──────────────────────────────────────────────────
    if (action === "remove" && goodbye) {
      const group = getGroup(groupJid);

      for (const participant of participants) {
        const num = participant.split("@")[0];
        const customMsg = group.goodbyeMsg || "";

        let goodbyeText;
        if (customMsg) {
          goodbyeText = customMsg
            .replace("{name}", `@${num}`)
            .replace("{group}", groupName);
        } else {
          goodbyeText =
            `👋 *Goodbye @${num}!*\n\n` +
            `You have left *${groupName}*.\n` +
            `We'll miss you! Hope to see you again. 💙\n\n` +
            `— *AA MD Bot* by Ahsan Ali`;
        }

        try {
          await sock.sendMessage(groupJid, {
            text: goodbyeText,
            mentions: [participant],
          });
        } catch (e) {
          logger.error("Goodbye send error: " + e.message);
        }
      }
    }
  } catch (err) {
    logger.error("Group participant handler error: " + err.message);
  }
}

module.exports = { handleGroupParticipants };
