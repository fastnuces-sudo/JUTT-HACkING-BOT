// ============================================
// AA MD Bot - Session Reset Helper
// Run: node reset.js
// ============================================

const fs = require("fs-extra");
const chalk = require("chalk");

console.log(chalk.yellow("\n⚠️  AA MD Bot - Session Reset"));
console.log(chalk.yellow("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));

const dirs = ["./session", "./temp", "./logs"];

for (const dir of dirs) {
  try {
    if (fs.existsSync(dir)) {
      fs.emptyDirSync(dir);
      console.log(chalk.green(`✅ Cleared: ${dir}`));
    }
  } catch (e) {
    console.log(chalk.red(`❌ Could not clear ${dir}: ${e.message}`));
  }
}

console.log(chalk.cyan("\n✅ Reset complete! Now run:  npm start\n"));
