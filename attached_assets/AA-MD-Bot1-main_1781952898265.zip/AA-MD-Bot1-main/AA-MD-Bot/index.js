// ============================================
// AA MD Bot - Main Entry Point
// Developer: Ahsan Ali | AA Mods
// ============================================

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
  proto,
} = require("@whiskeysockets/baileys");

const pino = require("pino");
const chalk = require("chalk");
const readline = require("readline");
const fs = require("fs-extra");
const config = require("./config");
const { initDatabase } = require("./lib/database");
const { loadPlugins } = require("./lib/handler");
const { handleMessages } = require("./events/messages");
const { handleConnection } = require("./events/connection");
const { handleGroupParticipants } = require("./events/group");
const logger = require("./lib/logger");

// Ensure required directories exist
fs.ensureDirSync(config.tempPath);
fs.ensureDirSync(config.mediaPath);
fs.ensureDirSync(config.logsPath);
fs.ensureDirSync("./session");

// ============================================
// Message Cache — Map<jid, Map<id, proto.IMessage>>
// Stores message content for WA retry/decryption
// ============================================
const msgCache = new Map();

function cacheMessage(jid, id, msgContent) {
  if (!jid || !id || !msgContent) return;
  if (!msgCache.has(jid)) msgCache.set(jid, new Map());
  const jidMap = msgCache.get(jid);
  jidMap.set(id, msgContent);
  // Keep last 500 messages per chat (enough for retry window)
  if (jidMap.size > 500) {
    jidMap.delete(jidMap.keys().next().value);
  }
}

// ============================================
// Retry Counter Cache
// Required so WhatsApp knows how many times a
// message has been retried and can stop looping
// ============================================
const retryCounterMap = new Map();
const msgRetryCounterCache = {
  get: (key) => retryCounterMap.get(key) || 0,
  set: (key, val) => retryCounterMap.set(key, val),
  del: (key) => retryCounterMap.delete(key),
};

// ============================================
// Ask for phone number before socket creation
// ============================================
function askPhoneNumber() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(
      chalk.yellow("\n📱 Enter your WhatsApp number (country code, no + or spaces):\n> "),
      (ans) => { rl.close(); resolve(ans.replace(/[^0-9]/g, "")); }
    );
  });
}

// ============================================
// Main Bot Startup
// ============================================
async function startBot() {
  logger.info(chalk.cyan("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
  logger.info(chalk.cyan("  AA MD Bot - Starting..."));
  logger.info(chalk.cyan("  Developer: Ahsan Ali | AA Mods"));
  logger.info(chalk.cyan("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));

  await initDatabase();
  logger.info(chalk.green("✓ Database initialized"));

  const plugins = await loadPlugins();
  logger.info(chalk.green(`✓ Loaded ${Object.keys(plugins).length} plugins`));

  const { version } = await fetchLatestBaileysVersion();
  logger.info(chalk.green(`✓ Baileys version: ${version}`));

  // ── Pairing: get number before socket ──────────────────────────
  let phoneNumber = null;

  {
    const { state: checkState } = await useMultiFileAuthState("./session");
    if (config.usePairingCode && !checkState.creds.registered) {
      const sessionFiles = fs.readdirSync("./session");
      if (sessionFiles.length > 0) {
        logger.info(chalk.yellow("🗑  Clearing stale session for fresh pairing..."));
        fs.emptyDirSync("./session");
      }
      phoneNumber = await askPhoneNumber();
      if (!phoneNumber || phoneNumber.length < 7) {
        logger.error("❌ Invalid number. Restart and try again.");
        process.exit(1);
      }
      logger.info(chalk.cyan(`📞 Number: +${phoneNumber}`));
      logger.info(chalk.yellow("⏳ Connecting to WhatsApp servers..."));
    }
  }

  const { state, saveCreds } = await useMultiFileAuthState("./session");

  // ── Create Socket ───────────────────────────────────────────────
  const sock = makeWASocket({
    version,
    logger: pino({ level: "silent" }),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
    },

    browser: Browsers.ubuntu("Chrome"),

    // ── Retry counter cache (REQUIRED to clear "Waiting for this message") ──
    msgRetryCounterCache,

    // ── getMessage: called when a participant requests message retry ─────────
    // MUST return the cached content (proto.IMessage) so Baileys can
    // re-encrypt and resend to the participant who couldn't decrypt.
    // Returning proto.Message.fromObject({}) as fallback tells WA the
    // message content is gone but ends the "Waiting" loop gracefully.
    getMessage: async (key) => {
      const cached = msgCache.get(key.remoteJid)?.get(key.id);
      if (cached) return cached;
      // Fallback: return empty proto message so WA clears the "Waiting" state
      // instead of looping retry requests forever
      return proto.Message.fromObject({});
    },

    syncFullHistory: false,
    printQRInTerminal: false,
    markOnlineOnConnect: true,
    generateHighQualityLinkPreview: false,
    connectTimeoutMs: 60000,
    keepAliveIntervalMs: 30000,
    retryRequestDelayMs: 2000,
  });

  // ── Request pairing code after WS handshake ─────────────────────
  if (config.usePairingCode && phoneNumber) {
    setTimeout(async () => {
      try {
        logger.info(chalk.yellow("🔑 Requesting pairing code..."));
        const code = await sock.requestPairingCode(phoneNumber);
        const fmt = code?.match(/.{1,4}/g)?.join("-") || code;
        logger.info(chalk.green("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        logger.info(chalk.green(`  🔑 PAIRING CODE:  ${chalk.bold.white(fmt)}`));
        logger.info(chalk.green("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        logger.info(chalk.yellow("👉 WhatsApp → Linked Devices → Link a Device → Link with phone number"));
        logger.info(chalk.yellow(`   Enter the code: ${chalk.bold.white(fmt)}\n`));
      } catch (err) {
        logger.error("❌ Pairing code error: " + err.message);
        logger.info(chalk.yellow("💡 Delete ./session and restart to try again."));
      }
    }, 3000);
  }

  // ── Patch sendMessage to cache every outgoing message ──────────
  // This is CRITICAL: when a group participant can't decrypt a bot
  // message they send a retry request. Baileys calls getMessage() to
  // get the original content and re-encrypt it for that participant.
  // Without caching sent messages, getMessage returns empty and the
  // participant stays stuck on "Waiting for this message".
  const _origSendMessage = sock.sendMessage.bind(sock);
  sock.sendMessage = async (jid, content, options) => {
    const result = await _origSendMessage(jid, content, options);
    if (result?.key?.id && result?.message) {
      cacheMessage(result.key.remoteJid || jid, result.key.id, result.message);
    }
    return result;
  };

  // ── Cache ALL received messages for getMessage() retries ────────
  // Cache EVERY message type (notify, append, history sync) so that
  // when WhatsApp asks for a retry we can provide the real content.
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    for (const msg of messages) {
      if (msg.key?.remoteJid && msg.key?.id && msg.message) {
        cacheMessage(msg.key.remoteJid, msg.key.id, msg.message);
      }
    }
    // Only execute commands for real incoming messages (not history sync)
    if (type === "notify") {
      await handleMessages({ messages, type }, sock, plugins, msgCache);
    }
  });

  // ── Event handlers ──────────────────────────────────────────────
  sock.ev.on("connection.update", (update) =>
    handleConnection(update, sock, startBot, saveCreds)
  );

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("group-participants.update", async (update) => {
    await handleGroupParticipants(update, sock);
  });

  sock.ev.on("contacts.update", async (contacts) => {
    if (!config.autoStatusView) return;
    for (const contact of contacts) {
      if (contact.status) {
        await sock.readMessages([{
          remoteJid: "status@broadcast",
          id: contact.status,
          participant: contact.id,
        }]).catch(() => {});
      }
    }
  });

  return sock;
}

// ============================================
// Boot
// ============================================
startBot().catch((err) => {
  logger.error("Fatal error: " + err.message);
  process.exit(1);
});

module.exports = { startBot };
