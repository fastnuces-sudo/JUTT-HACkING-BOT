// ============================================
// AA MD Bot - Web Dashboard + API Server
// Developer: Ahsan Ali | AA Mods
// ============================================

// ── Load .env file (for KataBump / Heroku / local) ────────────────
require("dotenv").config();

// ── Global crash guard — never let a single bad request kill the server ──
process.on("uncaughtException", (err) => {
  console.error("[uncaughtException] Caught — server kept alive:", err.message);
});
process.on("unhandledRejection", (reason) => {
  console.error("[unhandledRejection] Caught — server kept alive:", String(reason).slice(0, 200));
});

// ── Suppress Baileys/libsignal console noise ──────────────────────
const _ce = console.error.bind(console);
const _cl = console.log.bind(console);
const NOISE = [
  "Bad MAC", "Session error:", "Failed to decrypt",
  "Closing session:", "Removing old closed session:",
  "Closing open session in favor", "Closing open session:",
];
console.error = (...a) => { const m = String(a[0] || ""); if (NOISE.some(p => m.includes(p))) return; _ce(...a); };
console.log   = (...a) => { const m = String(a[0] || ""); if (NOISE.some(p => m.includes(p))) return; _cl(...a); };

const express = require("express");
const path    = require("path");
const fs      = require("fs-extra");
const crypto  = require("crypto");
const config  = require("./config");
const { addLog, getLogs, clearLogs } = require("./lib/logBuffer");
const { getAllUsers, updateUser, deleteUser, getAllSettings, setSetting, getUserHistory } = require("./lib/database");
const { fbGet, fbSet, fbUpdate, fbTest, isConfigured } = require("./lib/firebase");
const {
  startSession, disconnectSession, getSessionInfo,
  getAllSessions, restoreAllSessions, getSessionDir,
  getActiveSocket, getFirstActiveSession,
  updateSessionSettings, getSessionSettings,
} = require("./lib/botEngine");

const app  = express();
const PORT = process.env.PORT || 5000;
const startTime = Date.now();

app.use(express.json());
app.use(express.static(path.join(__dirname, "dashboard")));

// ── Admin token store ─────────────────────────────────────────────
const adminTokens = new Set();
function genToken() { return crypto.randomBytes(32).toString("hex"); }
function requireAdmin(req, res, next) {
  const token = req.headers["x-admin-token"] || req.query.token;
  if (!token || !adminTokens.has(token)) return res.status(401).json({ error: "Unauthorized" });
  next();
}


// ── Public: Bot connect API ───────────────────────────────────────
app.post("/api/bot/start", async (req, res) => {
  const { phoneNumber, useQR } = req.body;
  if (!useQR && (!phoneNumber || phoneNumber.length < 7))
    return res.json({ success: false, error: "Invalid phone number" });

  const sessionId = useQR ? "session_qr_" + Date.now() : "session_" + phoneNumber;
  const metaFile = path.join(getSessionDir(sessionId), "meta.json");
  fs.ensureDirSync(path.dirname(metaFile));
  fs.writeJsonSync(metaFile, { phoneNumber: phoneNumber || "", useQR: !!useQR });

  try {
    const result = await startSession(sessionId, phoneNumber || "", !!useQR);
    if (!result.success) return res.json({ success: false, error: result.error });
    addLog({ type: "system", message: `Session started: +${phoneNumber || "QR"}` });
    return res.json({ success: true, sessionId });
  } catch (err) {
    return res.json({ success: false, error: err.message });
  }
});

app.get("/api/bot/status/:sessionId", (req, res) => {
  const info = getSessionInfo(req.params.sessionId);
  if (!info) return res.json({ status: "not_found" });
  res.json({ status: info.status, pairingCode: info.pairingCode || null, qrDataUrl: info.qrDataUrl || null, botNumber: info.botNumber || null, error: info.error || null });
});

app.get("/api/bot/sessions", (req, res) => res.json({ sessions: getAllSessions() }));

// ── Public: Per-session user settings ────────────────────────────
app.get("/api/bot/session-settings/:sessionId", (req, res) => {
  const info = getSessionInfo(req.params.sessionId);
  if (!info) return res.json({ success: false, error: "Session not found" });
  const settings = getSessionSettings(req.params.sessionId);
  res.json({ success: true, settings });
});

app.post("/api/bot/session-settings/:sessionId", async (req, res) => {
  const info = getSessionInfo(req.params.sessionId);
  if (!info) return res.json({ success: false, error: "Session not found" });
  const allowed = [
    "botMode","publicWelcome",
    "autoStatus","autoStatusView","autoStatusReact","statusEmoji",
    "antiCall","antiCallMsg",
    "antiviewonce","antidelete",
    "autoRecording","autoRead","autoTyping","autoReply","autoReplyMessage",
    "autoReactMessages","autoReactEmoji","cooldown","spamLimit",
  ];
  const updates = {};
  for (const k of allowed) {
    if (req.body[k] !== undefined) updates[k] = req.body[k];
  }
  const result = await updateSessionSettings(req.params.sessionId, updates);
  if (result.success) addLog({ type: "system", message: `Session settings updated: ${req.params.sessionId}` });
  res.json(result);
});

app.delete("/api/bot/disconnect/:sessionId", async (req, res) => {
  const result = await disconnectSession(req.params.sessionId);
  if (result.success) addLog({ type: "system", message: `Session disconnected: ${req.params.sessionId}` });
  res.json(result);
});

// ── Admin credentials helpers ──────────────────────────────────────
const CREDS_PATH   = "botConfig/adminCreds";
const DEFAULT_EMAIL = "a67515346@gmail.com";
const DEFAULT_PASS  = "(Ahsan&ali12:@)";
const hashPass = (p) => crypto.createHash("sha256").update("aa-md-v2:" + p).digest("hex");

// Seed default credentials into Firebase if none exist yet
async function seedAdminCreds() {
  try {
    const existing = await fbGet(CREDS_PATH);
    if (!existing || !existing.email) {
      await fbSet(CREDS_PATH, { email: DEFAULT_EMAIL, passwordHash: hashPass(DEFAULT_PASS) });
      console.log("[Admin] Default credentials saved to Firebase.");
    }
  } catch (e) {
    console.error("[Admin] Could not seed credentials:", e.message);
  }
}

// ── Admin: Login — credentials stored in Firebase ─────────────────
app.post("/api/admin/login", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.json({ success: false, error: "Email and password are required." });

  try {
    const stored = await fbGet(CREDS_PATH);
    if (!stored || !stored.email) {
      // Firebase not configured — use in-memory defaults
      if (email.trim() !== DEFAULT_EMAIL || hashPass(password) !== hashPass(DEFAULT_PASS))
        return res.json({ success: false, error: "❌ Wrong email or password." });
    } else {
      if (email.trim() !== stored.email)
        return res.json({ success: false, error: "❌ Wrong email address." });
      if (hashPass(password) !== stored.passwordHash)
        return res.json({ success: false, error: "❌ Wrong password." });
    }
    const token = genToken();
    adminTokens.add(token);
    setTimeout(() => adminTokens.delete(token), 24 * 60 * 60 * 1000);
    addLog({ type: "system", message: `Admin login: ${email}` });
    return res.json({ success: true, token });
  } catch (e) {
    return res.json({ success: false, error: "❌ Login error: " + e.message });
  }
});

// ── Admin: Get current email (for display — never returns password) ─
app.get("/api/admin/credentials", requireAdmin, async (req, res) => {
  try {
    const stored = await fbGet(CREDS_PATH);
    res.json({ success: true, email: stored?.email || DEFAULT_EMAIL });
  } catch { res.json({ success: true, email: DEFAULT_EMAIL }); }
});

// ── Admin: Change password/email ───────────────────────────────────
app.post("/api/admin/change-password", requireAdmin, async (req, res) => {
  const { currentPassword, newEmail, newPassword } = req.body;
  if (!currentPassword)
    return res.json({ success: false, error: "Current password is required." });
  if (!newPassword && !newEmail)
    return res.json({ success: false, error: "Provide a new password or new email." });

  try {
    const stored = await fbGet(CREDS_PATH);
    const savedHash = stored?.passwordHash || hashPass(DEFAULT_PASS);
    if (hashPass(currentPassword) !== savedHash)
      return res.json({ success: false, error: "❌ Current password is wrong." });

    const updates = {};
    if (newEmail)    updates.email        = newEmail.trim();
    if (newPassword) updates.passwordHash = hashPass(newPassword);
    await fbUpdate(CREDS_PATH, updates);

    // Invalidate all existing tokens so re-login is required
    adminTokens.clear();
    addLog({ type: "system", message: `Admin credentials changed${newEmail ? " (email+password)" : " (password only)"}` });
    return res.json({ success: true, message: "Credentials updated. Please log in again." });
  } catch (e) {
    return res.json({ success: false, error: "❌ Error: " + e.message });
  }
});

app.get("/api/admin/verify", requireAdmin, (req, res) => res.json({ ok: true }));

// ── Admin: Stats ───────────────────────────────────────────────────
app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const users    = getAllUsers();
  const sessions = getAllSessions();
  const cmdLogs  = getLogs(1000, "cmd");
  const upSec    = Math.floor((Date.now() - startTime) / 1000);
  const days     = Math.floor(upSec / 86400);
  const hrs      = Math.floor((upSec % 86400) / 3600);
  const mins     = Math.floor((upSec % 3600) / 60);
  const uptime   = days > 0 ? `${days}d ${hrs}h ${mins}m` : hrs > 0 ? `${hrs}h ${mins}m` : `${mins}m ${upSec % 60}s`;

  const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
  const cmdToday = cmdLogs.filter(l => l.ts >= todayStart.getTime()).length;

  const usersArr = Object.values(users);
  res.json({
    totalUsers:     usersArr.length,
    bannedUsers:    usersArr.filter(u => u.banned).length,
    activeSessions: sessions.filter(s => s.status === "connected").length,
    totalSessions:  sessions.length,
    cmdToday,
    uptime,
    ramUsed:        Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
    sessions,
  });
});

// ── Admin: Users ───────────────────────────────────────────────────
app.get("/api/admin/users", requireAdmin, (req, res) => {
  const users = getAllUsers();
  const list = Object.values(users).map(u => ({
    jid:          u.id,
    number:       (u.id || "").split("@")[0],
    name:         u.name || "Unknown",
    level:        u.level || 1,
    xp:           u.xp || 0,
    commandsUsed: u.commandsUsed || 0,
    lastSeen:     u.lastSeen || 0,
    banned:       !!u.banned,
    premium:      !!u.premium,
    balance:      u.balance || 0,
  }));
  list.sort((a, b) => b.commandsUsed - a.commandsUsed);
  res.json({ users: list });
});

app.post("/api/admin/users/:jid/ban", requireAdmin, (req, res) => {
  try {
    updateUser(decodeURIComponent(req.params.jid), { banned: true });
    addLog({ type: "system", message: `User banned: ${req.params.jid}` });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post("/api/admin/users/:jid/unban", requireAdmin, (req, res) => {
  try {
    updateUser(decodeURIComponent(req.params.jid), { banned: false });
    addLog({ type: "system", message: `User unbanned: ${req.params.jid}` });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

app.post("/api/admin/users/:jid/premium", requireAdmin, (req, res) => {
  try {
    const val = !!req.body.premium;
    updateUser(decodeURIComponent(req.params.jid), { premium: val });
    addLog({ type: "system", message: `User ${val ? "granted" : "removed"} premium: ${req.params.jid}` });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ── Admin: Logs ────────────────────────────────────────────────────
app.get("/api/admin/logs", requireAdmin, (req, res) => {
  const filter = req.query.filter || "all";
  const limit  = parseInt(req.query.limit || "200");
  res.json({ logs: getLogs(limit, filter) });
});

app.delete("/api/admin/logs", requireAdmin, (req, res) => {
  clearLogs(); res.json({ success: true });
});

// ── Admin: Settings ────────────────────────────────────────────────
app.get("/api/admin/settings", requireAdmin, (req, res) => {
  const saved = getAllSettings();
  res.json({
    botName:               saved.botName           ?? config.botName,
    ownerName:             saved.ownerName          ?? config.ownerName,
    ownerNumber:           config.ownerNumber[0]    || "",
    prefix:                saved.prefix             ?? config.prefix,
    autoRead:              saved.autoRead           ?? config.autoRead,
    autoTyping:            saved.autoTyping         ?? config.autoTyping,
    autoReply:             saved.autoReply          ?? config.autoReply,
    autoReplyMessage:      saved.autoReplyMessage   ?? config.autoReplyMessage,
    autoStatusView:        saved.autoStatusView     ?? config.autoStatusView,
    autoStatusReact:       saved.autoStatusReact    ?? config.autoStatusReact,
    autoReactMessages:     saved.autoReactMessages  ?? config.autoReactMessages,
    autoReactEmoji:        saved.autoReactEmoji     ?? config.autoReactEmoji,
    cooldown:              saved.cooldown           ?? config.cooldown,
    spamLimit:             saved.spamLimit          ?? config.spamLimit,
    botMode:               saved.botMode            ?? config.botMode,
    publicWelcome:         saved.publicWelcome      ?? config.publicWelcome,
    autoStatus:            saved.autoStatus         ?? config.autoStatus ?? false,
    statusEmoji:           saved.statusEmoji        ?? config.statusEmoji ?? "❤️",
    antiCall:              saved.antiCall            ?? config.antiCall ?? false,
    antiEdit:              saved.antiEdit            ?? config.antiEdit ?? false,
    autoRecording:         saved.autoRecording       ?? config.autoRecording ?? false,
    antiCallMsg:           saved.antiCallMsg         ?? config.antiCallMsg ?? "",
    firebaseConfigured:    !!(process.env.FIREBASE_DB_SECRET && process.env.FIREBASE_DB_URL),
    firebaseDbUrl:         process.env.FIREBASE_DB_URL || "",
  });
});

app.post("/api/admin/settings", requireAdmin, async (req, res) => {
  const allowed = [
    "botName","ownerName","prefix",
    "autoRead","autoTyping","autoReply","autoReplyMessage",
    "autoStatusView","autoStatusReact",
    "autoReactMessages","autoReactEmoji",
    "cooldown","spamLimit",
    "botMode","publicWelcome","autoStatus","statusEmoji",
    "antiCall","antiEdit","autoRecording","antiCallMsg",
  ];
  const updates = {};
  for (const k of allowed) {
    if (req.body[k] !== undefined) {
      setSetting(k, req.body[k]);
      config[k] = req.body[k];
      updates[k] = req.body[k];
    }
  }
  addLog({ type: "system", message: "Settings updated from admin panel" });
  // Verify Firebase write actually succeeded
  let firebaseOk = false;
  if (Object.keys(updates).length > 0) {
    try {
      const r = await fbUpdate("settings", updates);
      firebaseOk = r !== null;
    } catch (_) { firebaseOk = false; }
  }
  res.json({
    success: true,
    firebaseOk,
    note: firebaseOk
      ? "✅ Settings saved to Firebase! Changes are permanent."
      : "⚠️ Saved in memory only — Firebase write failed. Check FIREBASE_DB_SECRET & FIREBASE_DB_URL in Replit Secrets.",
  });
});

// ── Admin: Firebase connection test ────────────────────────────────
app.get("/api/admin/firebase-test", requireAdmin, async (req, res) => {
  try {
    const result = await fbTest();
    res.json(result);
  } catch (e) { res.json({ configured: false, canRead: false, canWrite: false, error: e.message }); }
});

// ── Admin: Groups ──────────────────────────────────────────────────
app.get("/api/admin/groups", requireAdmin, async (req, res) => {
  try {
    const first = getFirstActiveSession();
    if (!first) return res.json({ groups: [], error: "No active session connected" });
    const sock = first.info.sock;
    const rawGroups = await sock.groupFetchAllParticipating();
    const groups = Object.values(rawGroups).map(g => ({
      id: g.id,
      subject: g.subject || "Unknown Group",
      participants: (g.participants || []).length,
      creation: g.creation || null,
      desc: g.desc || "",
      owner: g.owner || "",
    }));
    groups.sort((a, b) => (b.participants - a.participants));
    res.json({ groups, total: groups.length });
  } catch (e) {
    res.json({ groups: [], error: e.message });
  }
});

// ── Admin: Bulk delete users (keep owner numbers) ─────────────────
app.delete("/api/admin/users", requireAdmin, async (req, res) => {
  try {
    const keepNums = (config.ownerNumber || []).map(n => n.replace(/\D/g, ""));
    const users = getAllUsers();
    const toDelete = Object.keys(users).filter(jid => {
      const num = jid.split("@")[0];
      return !keepNums.includes(num);
    });
    let deleted = 0;
    for (const jid of toDelete) {
      await deleteUser(jid).catch(() => {});
      deleted++;
    }
    addLog({ type: "system", message: `Bulk delete: removed ${deleted} users (kept ${keepNums.join(", ")})` });
    res.json({ success: true, deleted, kept: keepNums });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ── Admin: Delete user data ────────────────────────────────────────
app.delete("/api/admin/users/:jid", requireAdmin, async (req, res) => {
  try {
    const jid = decodeURIComponent(req.params.jid);
    await deleteUser(jid);
    // Also disconnect any session whose botNumber matches this user's number
    const num = jid.split("@")[0];
    const sessions = getAllSessions();
    for (const s of sessions) {
      if ((s.botNumber || "").replace(/\D/g, "") === num) {
        await disconnectSession(s.sessionId).catch(() => {});
        const dir = getSessionDir(s.sessionId);
        await fs.remove(dir).catch(() => {});
      }
    }
    addLog({ type: "system", message: `User deleted: ${jid}` });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ── Admin: Sessions list (admin-protected) ─────────────────────────
app.get("/api/admin/sessions", requireAdmin, (req, res) => {
  const sessions = getAllSessions().map(s => ({
    sessionId:   s.sessionId,
    status:      s.status,
    number:      s.botNumber || "",
    phoneNumber: s.botNumber || s.phoneNumber || "",
  }));
  res.json({ sessions });
});

// ── Admin: Delete session files ────────────────────────────────────
app.delete("/api/admin/sessions/:sessionId", requireAdmin, async (req, res) => {
  try {
    const { sessionId } = req.params;
    await disconnectSession(sessionId).catch(() => {});
    const dir = getSessionDir(sessionId);
    await fs.remove(dir);
    addLog({ type: "system", message: `Session deleted: ${sessionId}` });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// ── Admin: Per-user command history ───────────────────────────────
app.get("/api/admin/users/:jid/history", requireAdmin, (req, res) => {
  const jid = decodeURIComponent(req.params.jid);
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const history = getUserHistory(jid, limit);
  res.json({ success: true, jid, history });
});

// ── Admin: Broadcast ───────────────────────────────────────────────
app.post("/api/admin/broadcast", requireAdmin, async (req, res) => {
  const { message, sessionId } = req.body;
  if (!message || !message.trim())
    return res.json({ success: false, error: "Message is required" });

  let sock = null;
  if (sessionId) {
    sock = getActiveSocket(sessionId);
  } else {
    const active = getFirstActiveSession();
    if (active) sock = active.info.sock;
  }

  if (!sock) return res.json({ success: false, error: "No active session connected. Please connect a WhatsApp number first." });

  const users = getAllUsers();
  const jids  = Object.keys(users).filter(j => j.endsWith("@s.whatsapp.net") && !users[j].banned);

  let sent = 0, failed = 0;
  for (const jid of jids) {
    try {
      await sock.sendMessage(jid, { text: message });
      sent++;
      await new Promise(r => setTimeout(r, 600)); // avoid rate-limit
    } catch { failed++; }
  }

  addLog({ type: "system", message: `Broadcast sent: ${sent} ok, ${failed} failed` });
  res.json({ success: true, sent, failed, total: jids.length });
});

// ── Firebase Rules ──────────────────────────────────────────────────────────
app.get("/api/admin/firebase-rules", requireAdmin, async (req, res) => {
  if (!isConfigured()) return res.json({ success: false, error: "Firebase not configured" });
  try {
    const axios = require("axios");
    const url   = process.env.FIREBASE_DB_URL.replace(/\/$/, "") + "/.settings/rules.json?auth=" + process.env.FIREBASE_DB_SECRET;
    const r     = await axios.get(url);
    res.json({ success: true, rules: r.data });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

app.post("/api/admin/firebase-rules", requireAdmin, async (req, res) => {
  if (!isConfigured()) return res.json({ success: false, error: "Firebase not configured" });
  const { rules } = req.body;
  if (!rules) return res.json({ success: false, error: "rules required" });
  try {
    const axios = require("axios");
    const url   = process.env.FIREBASE_DB_URL.replace(/\/$/, "") + "/.settings/rules.json?auth=" + process.env.FIREBASE_DB_SECRET;
    await axios.put(url, rules);
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// ── Debug: Direct send test (no auth — remove after debugging) ────────────
app.post("/api/debug/direct-send", async (req, res) => {
  const { jid, text } = req.body;
  const target = jid || "923417149048@s.whatsapp.net";
  const msg    = text || "DIRECT TEST from /api/debug/direct-send";
  try {
    const first = getFirstActiveSession();
    if (!first) return res.json({ success: false, error: "No active session" });
    const sock = first.info.sock;
    console.log(`[DIRECT-TEST] Sending to ${target}: "${msg}"`);
    const result = await sock.sendMessage(target, { text: msg });
    console.log(`[DIRECT-TEST] Result keyId=${result?.key?.id} remoteJid=${result?.key?.remoteJid}`);
    res.json({ success: true, keyId: result?.key?.id, remoteJid: result?.key?.remoteJid });
  } catch (err) {
    console.error(`[DIRECT-TEST] ERROR: ${err.message}`);
    res.json({ success: false, error: err.message });
  }
});

// ── Health check (used by Replit VM deployment to auto-restart on crash) ──
app.get("/health", (req, res) => {
  const sessions = getAllSessions();
  const upSec = Math.floor((Date.now() - startTime) / 1000);
  res.json({
    status: "ok",
    uptime: upSec,
    activeSessions: sessions.filter(s => s.status === "connected").length,
    totalSessions: sessions.length,
    timestamp: new Date().toISOString(),
  });
});

// ── Fallback: serve dashboard ──────────────────────────────────────
app.get("/{*path}", (req, res) => {
  res.sendFile(path.join(__dirname, "dashboard", "index.html"));
});

// ── Boot ───────────────────────────────────────────────────────────
app.listen(PORT, "0.0.0.0", () => {
  console.log(`\n✅ AA MD Bot Dashboard running on port ${PORT}`);
  console.log(`   Open: http://localhost:${PORT}\n`);
  addLog({ type: "system", message: `Server started on port ${PORT}` });
  // Fire-and-forget: don't block the listen callback so the port is immediately ready
  seedAdminCreds().catch(e => console.error("[Boot] seedAdminCreds:", e.message));
  restoreAllSessions().catch(e => console.error("[Boot] restoreAllSessions:", e.message));
});
