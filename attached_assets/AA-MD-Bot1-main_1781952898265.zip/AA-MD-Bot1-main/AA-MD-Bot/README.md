# 🤖 AA MD Bot

> A powerful, modular WhatsApp Multi-Device Bot built with Baileys.

**Developer:** Ahsan Ali  
**Brand:** AA Mods  
**Version:** 1.0.0

---

## ✨ Features

- 🔗 **Pairing Code Login** — No QR scan needed (or QR as fallback)
- 🔌 **Modular Plugin System** — 100+ commands in separate plugin files
- 🛡️ **Group Management** — Kick, add, promote, demote, warn, anti-link, anti-spam, and more
- ⬇️ **Downloaders** — YouTube, TikTok, Instagram, Facebook, Twitter, Pinterest, MediaFire
- 🤖 **AI Features** — Chat, translate, image generation, summarize, code helper
- 🎉 **Fun Commands** — Jokes, memes, quotes, truth/dare, ship, love calculator
- 🔧 **Utilities** — Weather, calculator, QR generator, URL shortener, currency converter
- 💰 **Economy System** — Balance, XP, levels, daily bonus, leaderboard
- 🔐 **Security** — Owner-only commands, cooldowns, spam protection, ban system
- 📢 **Broadcast** — Send messages to all known users
- ♾️ **Auto Features** — Auto-read, auto-typing, auto-status view/react, anti-delete

---

## 📁 Project Structure

```
AA-MD-Bot/
├── index.js              # Main entry point
├── config.js             # Bot configuration
├── package.json
├── .env.example          # Environment variables template
│
├── database/
│   ├── users.json        # User data (XP, balance, settings)
│   ├── groups.json       # Group settings
│   └── settings.json     # Global bot settings
│
├── events/
│   ├── connection.js     # WhatsApp connection events
│   ├── messages.js       # Message handler
│   └── group.js          # Welcome/goodbye events
│
├── lib/
│   ├── handler.js        # Command handler & plugin loader
│   ├── database.js       # JSON database system
│   ├── utils.js          # Utility functions
│   └── logger.js         # Logging system
│
├── plugins/
│   ├── admin/            # Group admin commands (20+)
│   ├── ai/               # AI-powered commands (8+)
│   ├── download/         # Media downloaders (10+)
│   ├── fun/              # Fun & games (11+)
│   ├── general/          # Core commands (menu, profile, etc.)
│   ├── group/            # Group feature toggles (9+)
│   ├── media/            # Media conversion (8+)
│   ├── owner/            # Owner-only commands (9+)
│   ├── search/           # Web search commands (6+)
│   ├── tools/            # Utility tools (8+)
│   └── utility/          # Utility commands (9+)
│
├── session/              # WhatsApp session files (auto-created)
├── temp/                 # Temporary media files (auto-cleaned)
├── media/                # Bot media assets
└── logs/                 # Log files
```

---

## 🚀 Installation & Setup

### Prerequisites

- Node.js 18 or higher
- npm or yarn
- ffmpeg (for media conversion)

### Install ffmpeg

**Ubuntu/Debian:**
```bash
sudo apt update && sudo apt install ffmpeg -y
```

**macOS:**
```bash
brew install ffmpeg
```

**Windows:** Download from [ffmpeg.org](https://ffmpeg.org/download.html)

---

### Local Installation

```bash
# 1. Clone or download the project
cd AA-MD-Bot

# 2. Install dependencies
npm install

# 3. Configure the bot
nano config.js
# Set your phone number in ownerNumber
# Set your preferred prefix

# 4. (Optional) Set up API keys
cp .env.example .env
nano .env

# 5. Start the bot
npm start
```

**On first run:** Enter your WhatsApp number (with country code, no +) when prompted.  
A **pairing code** will be displayed — enter it in WhatsApp → Linked Devices → Link with phone number.

---

### Replit Deployment

1. Fork this project on Replit
2. Open `config.js` and set your `ownerNumber`
3. Add any API keys to Replit Secrets (Settings → Secrets)
4. Click **Run**
5. Open the Shell tab, enter your number, and enter the pairing code in WhatsApp

**Keep alive:** Use [UptimeRobot](https://uptimerobot.com) to ping your Replit URL every 5 minutes.

---

### Render Deployment

1. Create a new **Web Service** on [Render](https://render.com)
2. Connect your GitHub repo
3. Set build command: `npm install`
4. Set start command: `npm start`
5. Add environment variables from `.env.example`
6. Deploy and check logs for the pairing code

---

### Koyeb Deployment

1. Create a new app on [Koyeb](https://koyeb.com)
2. Connect your GitHub repository
3. Set the run command to `npm start`
4. Add environment variables
5. Deploy and get pairing code from logs

---

## ⚙️ Configuration

Open `config.js` to configure the bot:

| Option | Description | Default |
|--------|-------------|---------|
| `ownerNumber` | Your WhatsApp number(s) with country code | `["923xxxxxxxxx"]` |
| `prefix` | Command prefix | `"."` |
| `usePairingCode` | Use pairing code instead of QR | `true` |
| `autoRead` | Auto-read all messages | `true` |
| `autoTyping` | Show typing indicator | `true` |
| `autoStatusView` | Auto-view status updates | `true` |
| `cooldown` | Command cooldown in ms | `3000` |
| `startingBalance` | Starting coin balance | `500` |

---

## 📜 Commands

### General
| Command | Description |
|---------|-------------|
| `.menu` | Show all commands |
| `.ping` | Check bot speed |
| `.info` | Bot information |
| `.profile` | Your XP/level/balance |
| `.leaderboard` | Top XP users |
| `.daily` | Claim daily bonus |
| `.balance` | Check coin balance |

### Admin (Group)
| Command | Description |
|---------|-------------|
| `.kick @user` | Remove from group |
| `.add 923...` | Add member |
| `.promote @user` | Make admin |
| `.demote @user` | Remove admin |
| `.mute` | Only admins can send |
| `.unmute` | Everyone can send |
| `.warn @user` | Issue warning |
| `.warnings @user` | Check warnings |
| `.tagall` | Tag everyone |
| `.hidetag` | Silent tag all |
| `.groupinfo` | Group details |
| `.setname <name>` | Change group name |
| `.setdesc <text>` | Change description |
| `.welcome on/off` | Toggle welcome messages |
| `.goodbye on/off` | Toggle goodbye messages |
| `.antilink on/off` | Block WhatsApp links |
| `.antispam on/off` | Block spam |
| `.antibadword on/off` | Block bad words |

### Download
| Command | Description |
|---------|-------------|
| `.yt <url>` | Download YouTube video |
| `.ytmp3 <url>` | Download YouTube audio |
| `.ig <url>` | Download Instagram |
| `.tiktok <url>` | Download TikTok (no watermark) |
| `.fb <url>` | Download Facebook video |
| `.twitter <url>` | Download Twitter/X video |
| `.pin <url>` | Download Pinterest |
| `.mediafire <url>` | Get MediaFire direct link |

### AI
| Command | Description |
|---------|-------------|
| `.ai <question>` | Chat with AI |
| `.translate <lang> <text>` | Translate text |
| `.imagine <prompt>` | Generate AI image |
| `.summarize <text>` | Summarize text |
| `.write <topic>` | AI writer |
| `.code <question>` | Code helper |
| `.qna <question>` | Q&A assistant |

### Fun
| Command | Description |
|---------|-------------|
| `.joke` | Random joke |
| `.meme` | Random meme |
| `.quote` | Inspirational quote |
| `.truth` | Truth question |
| `.dare` | Dare challenge |
| `.ship @user1 @user2` | Ship compatibility |
| `.love Name1 & Name2` | Love calculator |
| `.roast @user` | Playful roast |
| `.compliment @user` | Send compliment |
| `.character` | Personality type |
| `.guess start` | Number guessing game |

### Utility
| Command | Description |
|---------|-------------|
| `.weather <city>` | Weather report |
| `.calc <expression>` | Calculator |
| `.qr <text>` | Generate QR code |
| `.qrread` | Read QR from image |
| `.shorten <url>` | Shorten URL |
| `.time <country>` | Get timezone |
| `.currency 100 USD PKR` | Convert currency |
| `.random <min> <max>` | Random number |

### Media
| Command | Description |
|---------|-------------|
| `.sticker` | Image/video to sticker |
| `.toimage` | Sticker to image |
| `.ss <url>` | Website screenshot |
| `.removebg` | Remove image background |
| `.compress [quality]` | Compress image |
| `.resize <w> <h>` | Resize image |
| `.gif` | Video to GIF |
| `.toaudio` | Convert to voice note |
| `.steal` | Steal a sticker |

### Tools
| Command | Description |
|---------|-------------|
| `.base64 encode <text>` | Base64 encode |
| `.base64 decode <text>` | Base64 decode |
| `.password [length]` | Generate password |
| `.textstyle <text>` | Unicode text styles |
| `.font <num> <text>` | Change font |
| `.readmore text | hidden` | Read-more message |
| `.tts [lang] <text>` | Text to speech |
| `.upload` | Upload file, get link |

### Owner Only
| Command | Description |
|---------|-------------|
| `.broadcast <msg>` | Message all users |
| `.eval <code>` | Run JavaScript |
| `.shell <command>` | Run shell command |
| `.restart` | Restart bot |
| `.shutdown` | Stop bot |
| `.backup` | Backup database |
| `.stats` | Bot statistics |
| `.ban @user` | Ban user |
| `.addpremium @user` | Give premium |

---

## 🔌 Adding Custom Plugins

Create a new file in the appropriate `plugins/` subfolder:

```js
module.exports = {
  command: ["mycommand", "mc"],  // command name(s)
  description: "My custom command",
  category: "General",
  usage: ".mycommand <arg>",
  
  // Optional flags:
  // ownerOnly: true,   — only bot owner can use
  // adminOnly: true,   — only group admins
  // groupOnly: true,   — only works in groups
  // botAdmin: true,    — bot must be admin
  // cooldown: 10000,   — custom cooldown (ms)

  async execute({ sock, ctx, args, text, prefix, plugins }) {
    const { from, sender, pushName, isGroup, isOwner } = ctx;
    
    await sock.sendMessage(from, { text: "Hello from my custom plugin!" });
  },
};
```

The bot auto-loads all plugins on startup — no registration needed!

---

## 🔐 Security Notes

- `.eval` and `.shell` are **extremely dangerous** — they run arbitrary code. Keep `ownerOnly: true`.
- Never share your `session/` folder — it contains your WhatsApp credentials.
- Add your `.env` to `.gitignore` before pushing to GitHub.

---

## 📞 Support

**Developer:** Ahsan Ali  
**Brand:** AA Mods  
**WhatsApp:** wa.me/923xxxxxxxxx

---

## 📄 License

MIT License — Free to use and modify. Please credit **AA Mods** when sharing.
