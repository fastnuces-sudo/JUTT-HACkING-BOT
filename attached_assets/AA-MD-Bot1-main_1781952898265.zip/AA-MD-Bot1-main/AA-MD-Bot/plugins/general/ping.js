// ============================================
// AA MD Bot - Ping / Status Plugin
// Developer: Ahsan Ali | AA Mods
// ============================================

const fs   = require("fs");
const path = require("path");
const { formatTime } = require("../../lib/utils");
const BANNER = path.join(__dirname, "../../assets/banner.jpg");

module.exports = {
  command: ["ping", "alive", "speed", "status"],
  description: "Check bot ping, uptime, memory & WhatsApp connection status",
  category: "General",
  usage: ".ping",

  async execute({ sock, ctx }) {
    const { from } = ctx;

    // Measure real round-trip send latency
    const start = Date.now();
    await sock.sendMessage(from, { react: { text: "🏓", key: ctx.msg.key } }).catch(() => {});
    const ping = Date.now() - start;

    const uptime  = formatTime(process.uptime() * 1000);
    const mem     = process.memoryUsage();
    const heapMB  = Math.round(mem.heapUsed / 1024 / 1024);
    const rssMB   = Math.round(mem.rss    / 1024 / 1024);

    // Connection status from botEngine
    let sessionLines = "";
    try {
      const { getAllSessions } = require("../../lib/botEngine");
      const sessions = getAllSessions();
      const connected = sessions.filter(s => s.status === "connected");
      if (sessions.length === 0) {
        sessionLines = `📡 *Sessions:* None connected\n`;
      } else {
        sessionLines = connected
          .map(s => `📱 *+${s.botNumber || s.phoneNumber}* 🟢 Connected`)
          .join("\n");
        if (sessions.length > connected.length) {
          const idle = sessions.length - connected.length;
          sessionLines += `\n⚪ *${idle}* session${idle > 1 ? "s" : ""} idle/connecting`;
        }
        sessionLines += "\n";
      }
    } catch {
      const botNum = (sock.user?.id || "").split(":")[0].split("@")[0];
      sessionLines = botNum
        ? `📱 *+${botNum}* 🟢 Connected\n`
        : `📡 *Status:* Connected\n`;
    }

    const pingEmoji  = ping < 300 ? "🟢" : ping < 800 ? "🟡" : "🔴";
    const pingLabel  = ping < 300 ? "Fast" : ping < 800 ? "Medium" : "Slow";

    const text =
      `╔═══════════════════════════╗\n` +
      `║   🤖  *AA MD BOT*  🟢 Online   ║\n` +
      `╚═══════════════════════════╝\n\n` +
      `${pingEmoji} *Ping:*    ${ping}ms _(${pingLabel})_\n` +
      `⏱️  *Uptime:*  ${uptime}\n` +
      `💾 *Heap:*   ${heapMB} MB\n` +
      `📦 *RSS:*    ${rssMB} MB\n\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `📶 *Connection Status*\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      sessionLines +
      `\n_AA MD Bot by Ahsan Ali | AA Mods_`;

    console.log(`[PING-REPLY] to=${from} ping=${ping}ms hasBanner=${fs.existsSync(BANNER)}`);
    try {
      if (fs.existsSync(BANNER)) {
        await sock.sendMessage(from, {
          image:    fs.readFileSync(BANNER),
          caption:  text,
          mimetype: "image/jpeg",
        });
      } else {
        await sock.sendMessage(from, { text });
      }
    } catch {
      await sock.sendMessage(from, { text });
    }
  },
};
