// ============================================
// AA MD Bot - Configuration File
// Developer: Ahsan Ali | AA Mods
// ============================================

module.exports = {
  // Bot Identity
  botName: "AA MD Bot",
  botVersion: "1.0.0",
  developer: "Ahsan Ali",
  brand: "AA Mods",

  // Owner Settings
  ownerNumber: ["923346741532"], // Your WhatsApp number (country code, no +)
  ownerName: "Ahsan Ali",

  // Prefix System
  prefix: ".",
  altPrefixes: ["!", "/", "#"],

  // Bot Access Mode
  // "public"  = everyone can use the bot (groups always work)
  // "private" = only the owner's own "You" chat + groups
  botMode: "public",

  // Send a welcome message when a new user first messages in public mode
  publicWelcome: true,

  // Bot Behavior
  autoRead: true,
  autoTyping: true,
  autoRecording: false,
  autoStatusView: true,
  autoStatusReact: true,
  statusEmoji: "❤️",

  // Auto Reply (sent when someone messages the bot without a command)
  autoReply: true,
  autoReplyMessage: "Hello! I am AA MD Bot. Send .menu for commands.",

  // Auto React (react to every incoming message with an emoji)
  autoReactMessages: true,
  autoReactEmoji: "❤️",

  // Command Cooldown (milliseconds)
  cooldown: 3000,

  // Economy System
  startingBalance: 500,
  dailyBonus: 200,
  xpPerCommand: 10,
  levelUpXp: 500,

  // Logging
  logLevel: "info", // debug | info | warn | error
  logToFile: true,

  // ─────────────────────────────────────────────────────────────
  // API KEYS
  //
  // REMOVEBG_API_KEY  ← Optional, for .rembg command
  //    Bot has free fallbacks — works without this key too.
  //    Get key: https://www.remove.bg/api
  // ─────────────────────────────────────────────────────────────
  apiKeys: {
    removeBg: process.env.REMOVEBG_API_KEY || "",
  },

  // Free APIs (no key needed — used automatically)
  freeApis: {
    weather:  "https://wttr.in",
    quotable: "https://api.quotable.io",
    joke:     "https://v2.jokeapi.dev",
    advice:   "https://api.adviceslip.com",
    cat:      "https://catfact.ninja",
    dog:      "https://dog.ceo/api",
    wiki:     "https://en.wikipedia.org/api/rest_v1",
    lyrics:   "https://api.lyrics.ovh",
  },

  // Paths
  dbPath:    "./database",
  tempPath:  "./temp",
  mediaPath: "./media",
  logsPath:  "./logs",
  watermark: "AA MD Bot",
  footerText: "\n\n> 🤖 *Powered by AA MD Bot*\n> 👨‍💻 *Developed by Ahsan Ali Wadani*",

  // Anti-Call Settings
  antiCall: false,
  antiCallMsg: "📵 Calls are not accepted. Please send a message instead.",

  // Anti-Edit (detect when someone edits a message)
  antiEdit: false,

  // Channel / Website link added to menu footer
  channelLink: "https://aa-mods.vercel.app/",

  // Group Settings Defaults
  defaultGroupSettings: {
    welcome:       true,
    goodbye:       false,
    antilink:      false,
    antispam:      false,
    antidelete:    false,
    antiviewonce:  false,
    antibadword:   false,
    antibot:       false,
    muted:         false,
  },

  // Spam Protection
  spamLimit:  5,
  spamWindow: 10000,

  // Bad words list
  badWords: ["fuck", "shit", "bitch", "ass", "bastard"],

  // Bot Language
  language: "en",
};
