---
name: DM Command Fix — @lid JID Resolution
description: How to correctly handle WhatsApp's @lid JID format so DM replies actually reach non-owner users.
---

# @lid → @s.whatsapp.net Resolution

## The Rule
Use `rawFrom` directly as `from` (the send destination). Do NOT resolve `@lid` → `@s.whatsapp.net` for the send address.

**Why:** The `userDevicesCache` (which enables @lid encryption) is keyed on the **LID number** (e.g. `"74565564784701"`). When you resolve the @lid to a phone JID and then call `sock.sendMessage(phoneJid, ...)`, Baileys looks up `userDevicesCache.get(phoneNum)` — which misses — then calls USync — which returns empty for @lid strangers — leaving 0 devices. The message is "sent OK" per Baileys but silently never arrives.

When you keep `from = rawFrom` (the @lid JID) and call `sock.sendMessage(lidJid, ...)`, Baileys looks up `userDevicesCache.get(lidNum)` — which hits (pre-populated from session files) — and encrypts correctly.

**How to apply:**
1. In `messages.js`: set `const from = rawFrom;` — do NOT call `_resolveLidAsync(rawFrom)` for `from`.
2. Still resolve for **display/database** purposes: `const resolvedSender = await sock._resolveLidAsync(rawSender)` is fine for `senderJid`/`senderNum`.
3. In `botEngine.js`: pre-populate `userDevicesCache.set(lidUser, devices)` from session files before calling `handleMessages` — this is what makes the device cache work.

## Key Implementation Points
- `from` = `rawFrom` (used for ALL `sock.sendMessage(from, ...)` calls — auto-reply, welcome, react, plugin replies).
- `senderJid` is built from `resolvedSender` (for DB lookups, mentions, ban checks). For stranger @lid users, USync won't resolve so `senderJid` may still be `{lidNum}@s.whatsapp.net` — acceptable for now.
- The `userDevicesCache` is per-session and must be passed into `makeWASocket({ userDevicesCache })`.
- The `lidMap` (contacts.upsert/update) provides fast resolution for saved contacts; USync is the slow fallback for strangers (and often fails for privacy reasons).
