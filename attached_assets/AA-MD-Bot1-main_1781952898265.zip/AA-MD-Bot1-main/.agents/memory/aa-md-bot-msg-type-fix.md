---
name: Multi-Device Message Type Fix
description: Why filtering messages.upsert by type="notify" silently drops messages from other people in WA multi-device mode.
---

# Multi-Device Message Type Fix

## The Rule
Never filter `messages.upsert` events by `type === "notify"` to decide which messages to process. Process all types, guarded only by a staleness check and dedup set.

**Why:** In WhatsApp multi-device (how Baileys operates as a linked device), messages sent to the bot from OTHER people arrive as `type="append"`, not `type="notify"`. The old code had `if (type === "notify") { ... } else if (type === "append") { /* only self-chat */ }` which silently dropped all incoming messages from other numbers. The silva-md-bot repo explicitly documents this in a comment.

**How to apply:** Replace the type-based branch with:
1. Filter messages by: has `.message`, not `status@broadcast`, not older than 5 minutes
2. Dedup by `msg.key.id` using a sliding Set (max 2000 entries)
3. Pass all passing messages to `handleMessages` with `type: "notify"`

The 5-min stale check prevents replaying a large backlog queued during downtime/reconnect (the original purpose of the connectedTimestamp filter). The dedup Set prevents the same command running twice when the same message ID arrives in both a notify and append event.
