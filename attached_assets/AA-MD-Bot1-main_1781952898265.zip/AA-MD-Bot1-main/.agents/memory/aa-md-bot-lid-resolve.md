---
name: LID Resolve Strategy
description: How to resolve @lid JIDs to real phone numbers for outgoing DM replies
---

## Priority Order

1. **`msg.key.senderPn`** — Most reliable. WhatsApp embeds the sender's phone number directly in every incoming message key. Strip non-digits, validate length 7–15, use as `${phone}@s.whatsapp.net`. This works for strangers without any server query.

2. **`sock._resolveLidAsync(jid)`** — Queries WhatsApp server via USync (contact+LID protocol). For strangers the server returns `[{"contact":true,"id":"undefined"}]` — the `id` is literally `"undefined"` because WhatsApp intentionally doesn't expose LID→phone mapping for privacy. Only works for saved contacts.

3. **`contacts.upsert` / `contacts.update` events** — Only fires with full contact info (lid+phone) for contacts already in the owner's phone book during login sync. Never fires for strangers.

## Key Variables in messages.js

- `rawFrom` = `msg.key.remoteJid` (may be `@lid`)
- `resolvedFrom` = phone JID derived from senderPn or resolveLidAsync; used for ALL outgoing sends
- `ctx.from` = `resolvedFrom` — plugins always receive the resolved JID
- `from` = raw group JID (groups) or resolvedFrom (DMs via `isActuallyResolved` check) — used for group operations only

## AutoReact Bug (fixed)

`autoReact` was using raw `from` instead of `resolvedFrom` for the reaction target. Fix: use `const reactTarget = group ? from : resolvedFrom`.
