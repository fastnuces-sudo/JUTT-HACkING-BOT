---
name: LID Device Cache Fix
description: How to correctly handle @lid JID message delivery in Baileys — device cache + one-time session clear.
---

## The Rule

Two things BOTH need to be active for @lid delivery to work:

### 1. LID-SEND: one-time session clear (CRITICAL — but only ONCE per user)

Before the FIRST outgoing message to a @lid user, clear their Signal session files so
Baileys fetches fresh prekeys. After the first send, NEVER clear again — subsequent sends
must reuse the same session (Signal ratchet forward secrecy).

```js
const _lidSendDone = new Set();

sock.sendMessage = async (jid, content, options) => {
  if (jid.endsWith("@lid") && !jid.includes(":")) {
    const lidUser = jid.split("@")[0];
    if (!_lidSendDone.has(lidUser)) {
      // Clear stale session ONCE so Baileys fetches fresh prekeys
      const prefix = `session-${lidUser}.`;
      const sessionFiles = fs.readdirSync(sessionDir).filter(f => f.startsWith(prefix) && f.endsWith(".json"));
      if (sessionFiles.length > 0) {
        const sessionNulls = {};
        for (const file of sessionFiles) sessionNulls[file.slice("session-".length, -5)] = null;
        await sock.authState.keys.set({ session: sessionNulls });
      }
      _lidSendDone.add(lidUser); // mark done — do NOT clear again
    }
  }
  return _origSend(jid, content, options);
};
```

**Why once:** Clearing before EVERY send (welcome + autoReact + command reply) creates
multiple separate Signal prekey exchanges in rapid succession. Each exchange creates a
NEW session, making earlier messages undecryptable on the recipient's phone. Messages
arrive at WhatsApp's server (confirmed by append events) but vanish on screen.

**Symptom of clearing too often:** Blue tick + typing indicator appears, but no messages
arrive on the recipient's screen. `[SEND-OK]` logged but phone shows nothing.

### 2. userDevicesCache pre-population
Scan session files for the @lid user and inject `{ user, device }` objects.
Include device 0. Only set if `devices.length > 0`. Guard with `_lidCacheMap.has`.

### 3. @lid bypass in wrapSockWM (handler.js)
```js
if (jid?.endsWith("@lid")) return orig(jid, content, opts);
```
Prevents `forwardingScore: 999` / `isForwarded: true` from being injected.

## Diagnostic checklist
- `[SEND-OK]` logged but phone shows nothing → multiple prekey exchanges (fix: one-time clear)
- No `[DBG-handler]` after upsert → messages filtered as stale (>5 min) or dedup
- `[LID] Cached 0 device(s)` → no session files found yet (race condition, usually self-resolves)
- `USync: no @s.whatsapp.net JID` → expected for @lid strangers, NOT an error
