---
name: Workflow Restart Fix
description: restart_workflow tool consistently fails for AA MD Bot; use configureWorkflow() via code_execution instead
---

The `restart_workflow` tool always times out with "didn't open port 5000" for this project, even though the server runs fine manually (curl confirms HTTP responses, process stays alive 12+ seconds).

**Why:** Replit's port detection mechanism for this project doesn't reliably detect port 5000 via the restart_workflow tool. The server itself is working — it opens 0.0.0.0:5000 and responds to HTTP — but the tool's port polling fails.

**How to apply:** Always use `configureWorkflow()` in code_execution to restart:
```javascript
await configureWorkflow({
  name: "AA MD Bot",
  command: "cd AA-MD-Bot && node server.js",
  waitForPort: 5000,
  outputType: "webview",
  autoStart: true,
});
```

**Also fixed:** Server startup was using `async () => { await seedAdminCreds(); await restoreAllSessions(); }` inside listen callback. Changed to fire-and-forget (`.catch()` only) so the listen callback returns immediately and the port is instantly available to the runner.
