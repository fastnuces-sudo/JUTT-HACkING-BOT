---
name: LID Delivery Fix
description: Root cause and fix for @lid DM messages not being delivered to recipients
---

## Root Cause

WhatsApp's LID system assigns non-zero device IDs to users (e.g. device 99). When a stranger messages the bot, a Signal session is established at their real device (e.g. `session-74565564784701.99.json`).

When the bot replies, Baileys calls `getUSyncDevices(["botId", "74565564784701@lid"])` — a USync device query. The server returns a result with `id:"undefined"` and no `deviceList`. `extractDeviceJids` returns `[]`. So Baileys only adds device 0 (hardcoded fallback), encrypts for the stale device-0 session, and sends. The server ACKs (bot sees its own echo via `type=append fromMe=true`) but the stranger's real device (99) never receives the encrypted message.

## Fix Applied

**File:** `AA-MD-Bot/node_modules/@whiskeysockets/baileys/lib/Socket/messages-send.js`

After `devices.push(...additionalDevices)`, added:
```js
if (isLid && !additionalDevices.some(d => d.user === user)) {
    const scanKeys = [1..20, 50,51,52,99,100,101,102].map(i => `${user}.${i}`);
    const localSessions = await authState.keys.get('session', scanKeys);
    for (const [key, val] of Object.entries(localSessions)) {
        if (val) devices.push({ user, device: parseInt(key.split('.').pop()) });
    }
}
```

This scans the local Signal session store when USync fails. If device 99 is found locally (because the stranger messaged first), it's added to the device list and the message is encrypted for it.

**Log to confirm working:** `[LID-PATCH] found local session {user}.99 — encrypting for device 99`

## Why

- This is a node_modules patch — it will be lost if `npm install` is re-run
- If the session file for device 99 doesn't exist yet (first-ever message never arrived), delivery will still fail until the stranger messages first once
- Session files are named `session-{lidNum}.{device}.json` in the session directory
