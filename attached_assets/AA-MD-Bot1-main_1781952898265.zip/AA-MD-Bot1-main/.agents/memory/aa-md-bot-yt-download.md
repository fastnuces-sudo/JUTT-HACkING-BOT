---
name: YouTube Download Strategy
description: Which yt-dlp clients work for YouTube audio/video, and critical cookies behavior
---

## Rule
`tv_embedded` is the confirmed working client (June 2026). It MUST be used WITHOUT cookies — passing `--cookies` with `tv_embedded` causes yt-dlp to fall back to the web client internally, which requires a JS runtime and fails with "Requested format is not available".

**Why:** yt-dlp's cookie-aware path selects the `web` player client when cookies are present; `tv_embedded` only works cleanly without cookies. Verified by testing: `--list-formats` with `tv_embedded` shows m4a/mp4/webm formats, but actual download fails if cookies are passed.

**How to apply:**
- `BASE_FLAGS_NO_COOKIES` exists for this purpose (all BASE_FLAGS minus `--cookies`)
- `ytdlpAudioTry()` — when client is `tv_embedded` or no clientFlag, use `BASE_FLAGS_NO_COOKIES`
- `downloadVideo()` Step 1 — uses `tv_embedded` → `BASE_FLAGS_NO_COOKIES`
- `downloadVideo()` Step 2 alt clients — `tv_embedded` entry uses `BASE_FLAGS_NO_COOKIES`, others use `BASE_FLAGS`

## @lid public mode fix (June 2026)
WhatsApp new accounts use `@lid` JID format instead of `@s.whatsapp.net`. Responses sent to `@lid` addresses fail to deliver silently. Fix in `messages.js`: normalize `rawFrom = msg.key.remoteJid`, then `from = group ? rawFrom : senderJid` so DM replies always go to `@s.whatsapp.net`.

## Innertube (youtubei.js v17) on Replit
`decipher()` always fails with "No valid URL" — YouTube doesn't provide cipher data to Replit's IP. It's in the chain as Step 0 (fails fast ~2s) and falls through gracefully. Suppress parser warnings with `Log.setLevel(Log.Level.ERROR)`.

## Client status (June 2026 on Replit)
- `tv_embedded` ✅ — works without cookies; ~3.3 MB m4a audio, full mp4 video
- `android` + cookies ❌ — only returns storyboard images (no audio/video streams)
- `android` without cookies ❌ — no output
- `web` ❌ — needs JS runtime (Replit has no Node.js runtime for yt-dlp)
- `android_vr`, `ios` ❌ — JS runtime needed or failing

## External API status (June 2026 on Replit)
- Invidious: ALL instances dead — now fail fast in parallel (5s timeout)
- Piped: ALL instances dead — same parallel fast-fail
- davidcyriltech, y2mate, loader.to, vevioz: ENOTFOUND (DNS blocked or down)
- cobalt: resolves but returns 400
- RapidAPI: works when RAPIDAPI_KEY secret is set (first priority)

## Audio fallback order
1. Invidious (parallel, fast-fail)
2. yt-dlp `tv_embedded` (no cookies) ← **this is the one that works**
3. Piped (parallel, fast-fail)
4. Backup APIs
