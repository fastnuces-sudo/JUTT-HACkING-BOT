---
name: AA MD Bot Admin Auth
description: Firebase Auth replaces password-only admin login; dashboard tab structure
---

## Admin Login Flow
- Backend: POST `/api/admin/login` with `{email, password}` → calls Firebase Auth REST API
- Endpoint: `https://identitytoolkit.googleapis.com/v1/accounts:signInWithEmailAndPassword?key={FIREBASE_API_KEY}`
- Uses Node.js built-in `https` (no extra dependency) 
- On success: generates a 32-byte hex adminToken, stored in `adminTokens` Set, expires 24h
- Required secret: `FIREBASE_API_KEY` (Web API Key from Firebase Console → Project Settings)

## Dashboard Tab Structure
- Default tab: "🔐 Admin Login" → Firebase email+password form (`#fb-login-panel`)
- Second tab: "🤖 Connect Bot" → WhatsApp pairing/QR flow (`#c-s1` etc.)
- `switchTab('admin'|'bot')` toggles visibility
- After WhatsApp connect: goes straight to success (no admin password step in connect flow)
- Old elements removed: `c-direct-login`, `showDirectLogin()`, `doDirectAdminLogin()`

**Why:** User wanted no separate button and no WhatsApp linking required for admin access.
